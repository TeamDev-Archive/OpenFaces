/**
 * License Agreement.
 *
 * Rich Faces - Natural Ajax for Java Server Faces (JSF)
 *
 * Copyright (C) 2007 Exadel, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 2.1 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
 */

package org.richfaces.context;

import java.util.ArrayList;
import java.util.Collection;

import javax.faces.context.FacesContext;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.SystemEvent;
import javax.faces.event.SystemEventListener;

import org.ajax4jsf.component.AjaxOutput;

/**
 * @author Nick Belaevski
 * 
 */
public class PartialViewContextAjaxOutputTracker implements SystemEventListener {
	
	private static final String AJAX_OUTPUT_COMPONENTS_SET_ATTRIBUTE = 
		PartialViewContextAjaxOutputTracker.class + ":AjaxOutputComponentsSet";
	
	static Collection<AjaxOutput> getAjaxOutputComponentsSet(FacesContext context) {
		AttributesContext attributes = SingletonsContext.FACES_CONTEXT.get(context);
		Collection<AjaxOutput> components = (Collection<AjaxOutput>) attributes.getAttribute(AJAX_OUTPUT_COMPONENTS_SET_ATTRIBUTE);
		if (components == null) {
			components = new ArrayList<AjaxOutput>();
			attributes.setAttribute(AJAX_OUTPUT_COMPONENTS_SET_ATTRIBUTE, components);
		}
		
		return components;
	}

	/* (non-Javadoc)
	 * @see javax.faces.event.SystemEventListener#isListenerForSource(java.lang.Object)
	 */
	public boolean isListenerForSource(Object source) {
		return source instanceof AjaxOutput;
	}

	/* (non-Javadoc)
	 * @see javax.faces.event.SystemEventListener#processEvent(javax.faces.event.SystemEvent)
	 */
	public void processEvent(SystemEvent event) throws AbortProcessingException {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		getAjaxOutputComponentsSet(facesContext).add((AjaxOutput) event.getSource());
	}

}
