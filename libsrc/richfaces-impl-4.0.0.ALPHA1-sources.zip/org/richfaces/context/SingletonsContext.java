/**
 * License Agreement.
 *
 * Rich Faces - Natural Ajax for Java Server Faces (JSF)
 *
 * Copyright (C) 2007 Exadel, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 2.1 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
 */

package org.richfaces.context;

import java.util.Map;

import javax.faces.context.FacesContext;

/**
 * @author Nick Belaevski
 * @since 4.0
 */
public class SingletonsContext {
	
	public static abstract class ContextProvider {
		
		protected final String singletonContextAttributeName;

		protected ContextProvider(String attributeSuffixName) {
			this.singletonContextAttributeName = SingletonsContext.class.getName() + ":" + attributeSuffixName;
		}

		protected AttributesContext createContext() {
			return new AttributesContext();
		}

		protected abstract Map<? super String, Object> getContextMap(FacesContext facesContext);

		protected AttributesContext createAndStoreContext(FacesContext context) {
			AttributesContext instance = createContext();
			getContextMap(context).put(singletonContextAttributeName, instance);
			
			return instance;
		}
		
		public AttributesContext get(FacesContext context) {
			Map<? super String, Object> contextMap = getContextMap(context);
			
			AttributesContext instance = (AttributesContext) contextMap.get(singletonContextAttributeName);
			if (instance == null) {
				instance = createAndStoreContext(context);
			}
			
			return instance;
		}
	}
	
	public static final ContextProvider APPLICATION = new ContextProvider("Application") {

		@Override
		protected Map<String, Object> getContextMap(FacesContext facesContext) {
			return facesContext.getExternalContext().getApplicationMap();
		}
		
	};

	public static final ContextProvider FACES_CONTEXT = new ContextProvider("FacesContext") {

		@Override
		protected Map<? super String, Object> getContextMap(FacesContext facesContext) {
			return facesContext.getAttributes();
		}
		
	};

}
