/**
 * License Agreement.
 *
 * Rich Faces - Natural Ajax for Java Server Faces (JSF)
 *
 * Copyright (C) 2007 Exadel, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 2.1 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
 */

package org.richfaces.context;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

import javax.faces.component.UIComponent;
import javax.faces.component.behavior.ClientBehavior;
import javax.faces.component.behavior.ClientBehaviorHolder;
import javax.faces.component.visit.VisitCallback;
import javax.faces.component.visit.VisitContext;
import javax.faces.component.visit.VisitHint;
import javax.faces.component.visit.VisitResult;
import javax.faces.context.FacesContext;
import javax.faces.context.PartialViewContext;
import javax.faces.context.PartialViewContextWrapper;
import javax.faces.event.PhaseId;

import org.ajax4jsf.component.AjaxClientBehavior;
import org.ajax4jsf.component.AjaxOutput;
import org.ajax4jsf.renderkit.AjaxRendererUtils;
import org.ajax4jsf.renderkit.RendererUtils;

/**
 * @author Nick Belaevski
 * @since 4.0
 */
public class PartialViewContextImpl extends PartialViewContextWrapper {

    public static final String BEHAVIOR_EVENT_PARAMETER = "javax.faces.behavior.event";

    private final PartialViewContext wrappedContext;
	
	private final String activatorId;

	private boolean hasProcessedExecute = false;
	
	private boolean executeAll = true;
	
	private String behaviorEvent = null; 
	
	public PartialViewContextImpl(PartialViewContext wrappedContext, String activatorId) {
		super();
		
		this.wrappedContext = wrappedContext;
		this.activatorId = activatorId;
	}
	
	@Override
	public PartialViewContext getWrapped() {
		return wrappedContext;
	}

	private VisitContext createVisitContext(FacesContext facesContext) {
		return VisitContext.createVisitContext(facesContext, 
			Collections.singleton(activatorId), 
			Collections.singleton(VisitHint.SKIP_UNRENDERED)
		);
	}
	
	private abstract static class ComponentCallback implements VisitCallback {

		private final String behaviorEvent;
		
		private boolean handleAll;
		
		private boolean handleNone;
		
		private Collection<String> componentIds = new LinkedHashSet<String>();
		
		public ComponentCallback(String behaviorEvent, boolean handleNone,
				boolean handleAll) {
			super();
			this.behaviorEvent = behaviorEvent;
			this.handleNone = handleNone;
			this.handleAll = handleAll;
		}
		
		protected void addDefaultComponents(Collection<String> ids) {
			
		}

		private AjaxClientBehavior findBehavior(UIComponent target) {
			AjaxClientBehavior result = null;
			if (behaviorEvent != null) {
				if (target instanceof ClientBehaviorHolder) {
					ClientBehaviorHolder behaviorHolder = (ClientBehaviorHolder) target;
					List<ClientBehavior> behaviors = behaviorHolder.getClientBehaviors().get(behaviorEvent);
					if (behaviors != null) {
						for (ClientBehavior behavior : behaviors) {
							if (behavior instanceof AjaxClientBehavior) {
								AjaxClientBehavior ajaxBehavior = (AjaxClientBehavior) behavior;
								if (!ajaxBehavior.isDisabled()) {
									//TODO need more reliable algorithm
									result = (AjaxClientBehavior) behavior;
									break;
								}
							}
						}
					}
				}
			}
			
			if (result == null) {
				//TODO: log
			}

			return result;
		}
		
		protected abstract Object getBehaviorAttributeValue(AjaxClientBehavior behavior);

		protected abstract Object getAttributeValue(UIComponent component);
		
		protected void doVisit(FacesContext context, UIComponent target, AjaxClientBehavior behavior) {
			Object attributeObject = null;
			if (behavior != null) {
				attributeObject = getBehaviorAttributeValue(behavior);
			} else {
				attributeObject = getAttributeValue(target);
			}
			
			Collection<String> attributeIds = AjaxRendererUtils.asSet(attributeObject);
			if (attributeIds != null && !attributeIds.isEmpty()) {
				if (attributeIds.contains(AjaxRendererUtils.ALL)) {
					if (!AjaxRendererUtils.ALL_SET.equals(attributeIds)) {
						//TODO: log
					}
					
					handleAll = true;
				} else {
					handleAll = false;
					
					if (attributeIds.contains(AjaxRendererUtils.NONE)) {
						if (!AjaxRendererUtils.NONE_SET.equals(attributeIds)) {
							//TODO: log
						}
 						
						handleNone = true;
					} else {
						//asSet() returns copy of original set and we're free to modify it
						addDefaultComponents(attributeIds);
						
						componentIds.addAll(RendererUtils.getInstance().findComponentsFor(
							context, target, attributeIds));
					}
				}
			}
		}
		
		public final VisitResult visit(VisitContext visitContext, UIComponent target) {
			AjaxClientBehavior ajaxBehavior = null;
			if (behaviorEvent != null) {
				ajaxBehavior = findBehavior(target);
			}
			
			doVisit(visitContext.getFacesContext(), target, ajaxBehavior);
			
			return VisitResult.COMPLETE;
		}
		
		public Collection<String> getComponentIds() {
			return componentIds;
		}
		
		public boolean isHandleAll() {
			return handleAll;
		}
		
		public boolean isHandleNone() {
			return handleNone;
		}
	}
	
	private static class ExecuteComponentCallback extends ComponentCallback {

		public ExecuteComponentCallback(String behaviorEvent) {
			super(behaviorEvent, false, true);
		}

		@Override
		protected void addDefaultComponents(Collection<String> ids) {
			super.addDefaultComponents(ids);
			ids.add(AjaxRendererUtils.THIS);
		}

		@Override
		public Object getAttributeValue(UIComponent component) {
			return component.getAttributes().get("execute");
		}

		@Override
		protected Object getBehaviorAttributeValue(AjaxClientBehavior behavior) {
			return behavior.getExecute();
		}
	}

	private static class RenderComponentCallback extends ComponentCallback {
		
		public RenderComponentCallback(String behaviorEvent) {
			super(behaviorEvent, false, false);
		}

		private boolean limitRender = false;
		
		public boolean isLimitRender() {
			return limitRender;
		}

		@Override
		protected void doVisit(FacesContext context, UIComponent target,
				AjaxClientBehavior behavior) {
			
			super.doVisit(context, target, behavior);
			limitRender = AjaxRendererUtils.isAjaxLimitRender(target);
			if (behavior != null) {
				limitRender = behavior.isLimitRender();
			}
		}
		
		@Override
		public Object getAttributeValue(UIComponent component) {
			return component.getAttributes().get("render");
		}

		@Override
		protected Object getBehaviorAttributeValue(AjaxClientBehavior behavior) {
			return behavior.getRender();
		}
	}
	
	//TODO: data table support
	private Collection<String> getAjaxOutputComponentIds(FacesContext facesContext) {
		List<String> ids = new ArrayList<String>();
		Collection<AjaxOutput> ajaxOutputComponentsSet = PartialViewContextAjaxOutputTracker.getAjaxOutputComponentsSet(facesContext);
		for (AjaxOutput ajaxOutput : ajaxOutputComponentsSet) {
			if (ajaxOutput.isAjaxRendered()) {
				UIComponent ajaxOutputComponent = (UIComponent) ajaxOutput;
				ids.add(ajaxOutputComponent.getClientId(facesContext));
			}
		}
		
		return ids;
	}

	private void decodeBehaviorEvent(FacesContext context) {
		Map<String, String> requestParameterMap = context.getExternalContext().getRequestParameterMap();
		this.behaviorEvent = requestParameterMap.get(BEHAVIOR_EVENT_PARAMETER);
	}
	
	private void processExecute(PartialViewContext partialViewContext) {
		if (!hasProcessedExecute) {
			hasProcessedExecute = true;

			FacesContext facesContext = FacesContext.getCurrentInstance();
			
			decodeBehaviorEvent(facesContext);

			ExecuteComponentCallback executeCallback = new ExecuteComponentCallback(behaviorEvent);
			
			boolean visitResult = facesContext.getViewRoot().visitTree(
					createVisitContext(facesContext), 
					executeCallback);

			if (!visitResult) {
				//TODO:
			}

			executeAll = executeCallback.isHandleAll();
			if (!executeAll) {
				Collection<String> executeIds = partialViewContext.getExecuteIds();
				executeIds.clear();

				if (!executeCallback.isHandleNone()) {
					executeIds.addAll(executeCallback.getComponentIds());
					//TODO ids from wrapped object?
				}
			}
		}
	}
	
	private void processRender(PartialViewContext partialViewContext) {
		FacesContext facesContext = FacesContext.getCurrentInstance();

		if (!partialViewContext.isRenderAll()) {
			RenderComponentCallback renderCallback = new RenderComponentCallback(behaviorEvent);
			boolean visitResult = facesContext.getViewRoot().visitTree(
					createVisitContext(facesContext), 
					renderCallback);
	
			if (!visitResult) {
				//TODO:
			}

			boolean renderAll = renderCallback.isHandleAll();
			partialViewContext.setRenderAll(renderAll);
			if (!renderAll) {
				Collection<String> renderIds = partialViewContext.getRenderIds();
				renderIds.clear();

				if (!renderCallback.isHandleNone()) {
					renderIds.addAll(renderCallback.getComponentIds());

					if (!renderCallback.isLimitRender()) {
						Collection<String> ajaxOutputComponentIds = getAjaxOutputComponentIds(facesContext);
						renderIds.addAll(ajaxOutputComponentIds);
						//TODO ids from wrapped object?
					}
				}
			}
		}
	}
	
	@Override
	public void processPartial(PhaseId phaseId) {
		PartialViewContext wrapped = getWrapped();

		if (PhaseId.APPLY_REQUEST_VALUES.equals(phaseId)) {
			processExecute(wrapped);
		} else if (PhaseId.RENDER_RESPONSE.equals(phaseId)) {
			processRender(wrapped);
		}
		
		wrapped.processPartial(phaseId);
	}

	@Override
	public void setPartialRequest(boolean isPartialRequest) {
		getWrapped().setPartialRequest(isPartialRequest);
	}
	
	/* (non-Javadoc)
	 * @see javax.faces.context.PartialViewContextWrapper#getRenderIds()
	 */
	@Override
	public Collection<String> getRenderIds() {
		return getWrapped().getRenderIds();
	}
	
	/* (non-Javadoc)
	 * @see javax.faces.context.PartialViewContextWrapper#getExecuteIds()
	 */
	@Override
	public Collection<String> getExecuteIds() {
		return getWrapped().getExecuteIds();
	}
	
	/* (non-Javadoc)
	 * @see javax.faces.context.PartialViewContextWrapper#isExecuteAll()
	 */
	@Override
	public boolean isExecuteAll() {
		processExecute(getWrapped());
		return executeAll;
	}
	
	/* (non-Javadoc)
	 * @see javax.faces.context.PartialViewContextWrapper#isRenderAll()
	 */
	@Override
	public boolean isRenderAll() {
		return getWrapped().isRenderAll();
	}
}
