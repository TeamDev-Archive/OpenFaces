/**
 * Base RichFaces component events classes
 */
package org.richfaces.event;
