/**
 * Common utility classes
 */
package org.richfaces.component.util;
