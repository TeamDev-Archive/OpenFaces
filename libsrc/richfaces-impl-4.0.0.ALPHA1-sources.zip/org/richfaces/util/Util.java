/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 * 
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 * 
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 * 
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 * 
 * Contributor(s):
 * 
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 * 
 * Portions Copyrighted 2009 Exadel, Inc.
 * 
 * Exadel. Inc, elects to include this software in this distribution under the 
 * GPL Version 2 license.
 */

package org.richfaces.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.StreamCorruptedException;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

import javax.faces.FacesException;
import javax.faces.application.ViewHandler;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.ajax4jsf.Messages;
import org.ajax4jsf.util.base64.Codec;
import org.richfaces.log.RichfacesLogger;
import org.slf4j.Logger;

/**
 * @author Nick Belaevski
 * @since 4.0
 */
public class Util {

	private static final Logger resourceLogger = RichfacesLogger.RESOURCE.getLogger();
	
	private Util() {}

	/* HTTP Date format required by the HTTP/1.1 RFC */
    private static final String RFC1123_DATE_PATTERN = "EEE, dd MMM yyyy HH:mm:ss zzz";
	
    private static final SimpleDateFormat RFC1123_DATE_FORMATTER;
    
    static {
    	SimpleDateFormat format = new SimpleDateFormat(RFC1123_DATE_PATTERN, Locale.US);
    	format.setTimeZone(TimeZone.getTimeZone("GMT"));

    	RFC1123_DATE_FORMATTER = format;
    }
    
    public static String getMappingForRequest(FacesContext context) {
        ExternalContext externalContext = context.getExternalContext();
		
		String servletPath = externalContext.getRequestServletPath();

        if (servletPath == null) {
            return null;
        }

        if (servletPath.length() == 0) {
            return "/";
        }

        String pathInfo = externalContext.getRequestPathInfo();
        if (pathInfo != null) {
        	return servletPath;
        }
        
        int idx = servletPath.lastIndexOf('.');
        if (idx < 0) {
            return servletPath;
        } else {
            return servletPath.substring(idx);
        }
	}
	
    public static Date parseHttpDate(String s) {
    	Date result = null;
    	
    	if (s != null) {
    		try {
				result = (Date) ((Format) RFC1123_DATE_FORMATTER.clone()).parseObject(s);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	}
    	
    	return result;
    }
    
    public static String formatHttpDate(Object object) {
    	if (object != null) {
        	return ((Format) RFC1123_DATE_FORMATTER.clone()).format(object);
    	} else {
    		return null;
    	}
    }
    
    //TODO codec have settings
    private static final Codec CODEC = new Codec();
    
	private static final String DATA_SEPARATOR = "/DATA/";
	private static final String DATA_BYTES_SEPARATOR = "/DATB/";
	private static final String VERSION_SEPARATOR = "/VER";

	private static final Pattern DATA_SEPARATOR_PATTERN = Pattern
			.compile("/DAT(A|B)/([^/]*)");

	//index of capturing group denoting data type encoded
	private static final int DATA_SEPARATOR_TYPE_GROUP_INDEX = 1;

	//index of capturing group denoting version
	private static final int DATA_SEPARATOR_DATA_GROUP_INDEX = 2;
	
	protected static byte[] encrypt(byte[] src) {
		try {
			Deflater compressor = new Deflater(Deflater.BEST_SPEED);
			byte[] compressed = new byte[src.length + 100];
			compressor.setInput(src);
			compressor.finish();
			int totalOut = compressor.deflate(compressed);
			byte[] zipsrc = new byte[totalOut];
			System.arraycopy(compressed, 0, zipsrc, 0, totalOut);
			compressor.end();
			return CODEC.encode(zipsrc);
		} catch (Exception e) {
			throw new FacesException("Error encode resource data", e);
		}
	}

	protected static byte[] decrypt(byte[] src) {
		try {
			byte[] zipsrc = CODEC.decode(src);
			Inflater decompressor = new Inflater();
			byte[] uncompressed = new byte[zipsrc.length * 5];
			decompressor.setInput(zipsrc);
			int totalOut = decompressor.inflate(uncompressed);
			byte[] out = new byte[totalOut];
			System.arraycopy(uncompressed, 0, out, 0, totalOut);
			decompressor.end();
			return out;
		} catch (Exception e) {
			throw new FacesException("Error decode resource data", e);
		}
	}

    public static String encodeResourceData(String resourceName, Object storeData, 
    		String resourceVersion) {
		
    	StringBuffer uri = new StringBuffer();// ResourceServlet.DEFAULT_SERVLET_PATH).append("/");
		uri.append(resourceName);
		// append serialized data as Base-64 encoded request string.
		if (storeData != null) {
			try {
				byte[] objectData;
				if (storeData instanceof byte[]) {
					objectData = (byte[]) storeData;
					uri.append(DATA_BYTES_SEPARATOR);
				} else {
					ByteArrayOutputStream dataSteram = new ByteArrayOutputStream(
							1024);
					ObjectOutputStream objStream = new ObjectOutputStream(
							dataSteram);
					objStream.writeObject(storeData);
					objStream.flush();
					objStream.close();
					dataSteram.close();
					objectData = dataSteram.toByteArray();
					uri.append(DATA_SEPARATOR);
				}
				byte[] dataArray = encrypt(objectData);
				uri.append(new String(dataArray, "ISO-8859-1"));

				// / byte[] objectData = dataSteram.toByteArray();
				// / uri.append("?").append(new
				// String(Base64.encodeBase64(objectData),
				// / "ISO-8859-1"));
			} catch (Exception e) {
				resourceLogger.error(Messages.getMessage(Messages.QUERY_STRING_BUILDING_ERROR), e);
			}
		}
		
		if (resourceVersion != null && resourceVersion.length() != 0) {
			uri.append(VERSION_SEPARATOR);
			uri.append(resourceVersion);
		}
//boolean isGlobal = !resource.isSessionAware();
		
//		String resourceURL = getFacesResourceURL(context,
//				uri.toString(), false /*isGlobal*/);// context.getApplication().getViewHandler().getResourceURL(context,uri.toString());
		//if (!isGlobal) {
		//	resourceURL = context.getExternalContext().encodeResourceURL(
		//			resourceURL);
		//}
//		if (log.isDebugEnabled()) {
//			log.debug(Messages.getMessage(Messages.BUILD_RESOURCE_URI_INFO,
//					resource.getKey(), resourceURL));
//		}
		return uri.toString();// context.getExternalContext().encodeResourceURL(resourceURL);
    }
    
    public static String getResourceName(String resourceUri) {
    	String resourceName = resourceUri;
    	Matcher matcher = DATA_SEPARATOR_PATTERN.matcher(resourceName);
		if (matcher.find()) {
			int data = matcher.start();
			resourceName = resourceName.substring(0, data);
		} else {
			int idx = resourceName.indexOf(VERSION_SEPARATOR);
			if (idx > 0) {
				resourceName = resourceName.substring(0, idx);
			}
		}

		return resourceName;
    }
    
    public static String getResourceVersion(String resourceUri) {
		int idx = resourceUri.indexOf(VERSION_SEPARATOR);
		if (idx > 0) {
			return resourceUri.substring(idx + VERSION_SEPARATOR.length());
		}
		
		return null;
    }
    
    public static Object getResourceData(String resourceUri) {
		Object data = null;
		String dataString = null;
		Matcher matcher = DATA_SEPARATOR_PATTERN.matcher(resourceUri);
		if (matcher.find()) {
			if (resourceLogger.isDebugEnabled()) {
				resourceLogger.debug(Messages.getMessage(
						Messages.RESTORE_DATA_FROM_RESOURCE_URI_INFO, resourceUri,
						dataString));
			}
			dataString = matcher.group(DATA_SEPARATOR_DATA_GROUP_INDEX);
			byte[] objectArray = null;
			byte[] dataArray;
			try {
				dataArray = dataString.getBytes("ISO-8859-1");
				objectArray = decrypt(dataArray);
			} catch (UnsupportedEncodingException e1) {
				// default encoding always presented.
			}
			if ("B".equals(matcher.group(DATA_SEPARATOR_TYPE_GROUP_INDEX))) {
				data = objectArray;
			} else {
				try {
					ObjectInputStream in = new ObjectInputStream(
							new ByteArrayInputStream(objectArray));
					data = in.readObject();
				} catch (StreamCorruptedException e) {
					resourceLogger.error(Messages
							.getMessage(Messages.STREAM_CORRUPTED_ERROR), e);
				} catch (IOException e) {
					resourceLogger.error(Messages
							.getMessage(Messages.DESERIALIZE_DATA_INPUT_ERROR),
							e);
				} catch (ClassNotFoundException e) {
					resourceLogger.error(
									Messages
											.getMessage(Messages.DATA_CLASS_NOT_FOUND_ERROR),
									e);
				}
			}
		}

		return data;
    }
    
    public static String encodeResourceURL(FacesContext context, String url) {
		String mapping = Util.getMappingForRequest(context);

		String resourcePath = url;
		if (mapping.startsWith("/")) {
			if (mapping.length() != 1) {
				resourcePath = mapping + url;
			}
		} else {
			resourcePath += mapping;
		}

		ViewHandler viewHandler = context.getApplication().getViewHandler();
		return viewHandler.getResourceURL(context, resourcePath);
    }
    
    public static String decodeResourceURL(FacesContext context) {
		ExternalContext externalContext = context.getExternalContext();
		String resourceName = null;

		String facesMapping = Util.getMappingForRequest(context);
		if (facesMapping != null) {
			if (facesMapping.startsWith("/")) {
				//prefix mapping
				resourceName = externalContext.getRequestPathInfo();
			} else {
				String requestServletPath = externalContext.getRequestServletPath();
				resourceName = requestServletPath.substring(0, 
						requestServletPath.length() - facesMapping.length());
			}
		}
    	
    	return resourceName;
    }
    
    public static void copyStreamContent(InputStream is, OutputStream os) throws IOException {
    	ReadableByteChannel inChannel = Channels.newChannel(is);
    	WritableByteChannel outChannel = Channels.newChannel(os);
    	
    	//TODO make this configurable
    	ByteBuffer buffer = ByteBuffer.allocate(8192);
    	int read;
    	
    	while ((read = inChannel.read(buffer)) > 0) {
    		buffer.rewind();
    		buffer.limit(read);
    		
    		while (read > 0) {
    			read -= outChannel.write(buffer); 
    		}
    		
    		buffer.clear();
    	}
    }
}
