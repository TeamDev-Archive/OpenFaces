/**
 * Utility classes
 */
package org.richfaces.util;
