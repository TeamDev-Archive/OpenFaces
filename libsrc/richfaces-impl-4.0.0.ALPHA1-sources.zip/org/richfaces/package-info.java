/**
 * Base package for RichFaces classes
 */
package org.richfaces;
