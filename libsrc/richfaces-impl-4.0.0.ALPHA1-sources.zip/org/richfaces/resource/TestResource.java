/**
 * License Agreement.
 *
 * Rich Faces - Natural Ajax for Java Server Faces (JSF)
 *
 * Copyright (C) 2007 Exadel, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 2.1 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
 */

package org.richfaces.resource;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;

import javax.faces.FacesException;
import javax.faces.component.StateHolder;
import javax.faces.context.FacesContext;

import org.richfaces.VersionBean;
import org.richfaces.VersionBean.Version;

public class TestResource extends AbstractBaseResource implements StateHolder {

	private String filePath;
	
	@Override
	public String getContentType() {
		return "image/png";
	}

	@Override
	protected int getContentLength(FacesContext context) {
		return (int) new File(filePath).length();
	}
	
	@Override
	public InputStream getInputStream() {
		try {
			return new FileInputStream(filePath);
		} catch (FileNotFoundException e) {
			throw new FacesException(e.getLocalizedMessage(), e);
		}
	}

	@Override
	public String getVersion() {
		Version version = new VersionBean().getVersion();
		return version.getMajor() + "." + version.getMinor() + "." + version.getRevision();
	}
	
	protected void writeState(ByteArrayOutputStream baos) {
		try {
			baos.write("c:\\tmp\\test.png".getBytes("US-ASCII"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	protected void readState(ByteArrayInputStream bais) {
		int available = bais.available();
		byte[] bs = new byte[available];
		try {
			bais.read(bs);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			filePath = new String(bs, "US-ASCII");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public Object saveState(FacesContext context) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		writeState(baos);
		return baos.toByteArray();
	}
	
	public void restoreState(FacesContext context, Object state) {
		ByteArrayInputStream bais = new ByteArrayInputStream((byte[]) state);
		readState(bais);
	}

	public boolean isTransient() {
		return false;
	}

	public void setTransient(boolean newTransientValue) {
	}
}
