/**
 * License Agreement.
 *
 * Rich Faces - Natural Ajax for Java Server Faces (JSF)
 *
 * Copyright (C) 2007 Exadel, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 2.1 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
 */

package org.richfaces.resource;

import org.richfaces.util.Util;

class DefaultResourceCodec implements ResourceCodec {

	private static final ResourceCodec CODEC = new DefaultResourceCodec();

	private DefaultResourceCodec() {
		
	}
	
	public String decodeResourceName(String resourceKey) {
		return Util.getResourceName(resourceKey);
	}

	public Object decodeResourceData(String resourceKey) {
		return Util.getResourceData(resourceKey);
	}

	public static ResourceCodec getInstance() {
		return CODEC;
	}

	public String decodeResourceVersion(String resourceKey) {
		return Util.getResourceVersion(resourceKey);
	}

	public String encodeResource(String resourceName, Object resourceData,
			String resourceVersion) {
		return Util.encodeResourceData(resourceName, resourceData, resourceVersion);
	}

}