/**
 * License Agreement.
 *
 *  JBoss RichFaces - Ajax4jsf Component Library
 *
 * Copyright (C) 2009 Exadel, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 2.1 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
 */

package org.richfaces.resource;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.text.MessageFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

import javax.faces.application.ProjectStage;
import javax.faces.application.Resource;
import javax.faces.application.ResourceHandler;
import javax.faces.component.StateHolder;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.ajax4jsf.cache.Cache;
import org.ajax4jsf.cache.CacheManager;
import org.richfaces.context.AttributesContext;
import org.richfaces.context.SingletonsContext;
import org.richfaces.log.RichfacesLogger;
import org.richfaces.util.Util;
import org.richfaces.util.RequestStateManager.BooleanRequestStateVariable;
import org.slf4j.Logger;

/**
 * @author Nick Belaevski
 * @since 4.0
 */
public class ResourceHandlerImpl extends ResourceHandler {

	public static final String RICHFACES_RESOURCE_IDENTIFIER = "/rfRes/";

	public static final String HANDLER_START_TIME_ATTRIBUTE = ResourceHandlerImpl.class.getName() + 
		":StartTime";
	
	public static final String RESOURCE_CACHE_NAME = ResourceHandlerImpl.class.getName() + ":CACHE";
	
	private static final Logger LOGGER = RichfacesLogger.RESOURCE.getLogger();

	//TODO - review - do we need this?
	static {
		// set in-memory caching ImageIO
		Thread thread = Thread.currentThread();
		ClassLoader initialTCCL = thread.getContextClassLoader();
		
		try {
			ClassLoader systemCL = ClassLoader.getSystemClassLoader();
			thread.setContextClassLoader(systemCL);
			ImageIO.setUseCache(false);
		} finally {
			thread.setContextClassLoader(initialTCCL);
		}
	}

	
	private ResourceHandler defaultHandler;

	private Cache cache;
	
	public ResourceHandlerImpl(ResourceHandler defaultHandler) {
		this.defaultHandler = defaultHandler;

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(MessageFormat.format("Instance of {0} resource handler created", 
				getClass().getName()));
		}
		
		FacesContext facesContext = FacesContext.getCurrentInstance();
		initializeCache(facesContext);
		markStartTime(facesContext);
	}

	private void initializeCache(FacesContext facesContext) {
		CacheManager cacheManager = CacheManager.getInstance();
		Map<?,?> envMap = facesContext.getExternalContext().getInitParameterMap();
		cacheManager.createCache(RESOURCE_CACHE_NAME, envMap);
		cache = cacheManager.getCache(RESOURCE_CACHE_NAME);
	}

	private void markStartTime(FacesContext facesContext) {
		AttributesContext applicationContext = SingletonsContext.APPLICATION.get(facesContext);
		applicationContext.setAttribute(HANDLER_START_TIME_ATTRIBUTE, new Date());
	}
	
	private static final String RESOURCE_CODEC_ATTRIBUTE_NAME = 
		ResourceHandlerImpl.class.getName() + ":ResourceCodec";
	
	protected static void setResourceCodec(ResourceCodec codec) {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		Map<String, Object> applicationMap = facesContext.getExternalContext().getApplicationMap();
		Object oldCodec = applicationMap.put(RESOURCE_CODEC_ATTRIBUTE_NAME, codec);
	
		if (oldCodec != null && codec != null && !oldCodec.equals(codec) &&
				facesContext.isProjectStage(ProjectStage.Development)) {
			
			LOGGER.warn("Resource codec should be typically set once per application lifetime");
		}
	}

	public static ResourceCodec getResourceCodec(FacesContext context) {
		Map<String, Object> applicationMap = context.getExternalContext().getApplicationMap();
		ResourceCodec resourceCodec = (ResourceCodec) applicationMap.get(RESOURCE_CODEC_ATTRIBUTE_NAME);
		if (resourceCodec == null) {
			resourceCodec = DefaultResourceCodec.getInstance();
		}
		return resourceCodec;
	}
	
	protected String getResourceKey(FacesContext context) {
		String resourceName = Util.decodeResourceURL(context);
		if (resourceName != null) {
			if (resourceName.startsWith(RICHFACES_RESOURCE_IDENTIFIER)) {
				return resourceName.substring(RICHFACES_RESOURCE_IDENTIFIER.length());
			} else {
				return null;
			}
		} else {
			//TODO log
			return null;
		}
	}

	protected boolean isThisHandlerResourceRequest(FacesContext context) {
		Boolean resourceRequest = BooleanRequestStateVariable.RESOURCE_REQUEST.get(context);
		if (resourceRequest == null) {
			String resourceKey = getResourceKey(context);
			//TODO handle exclusions
			resourceRequest = (resourceKey != null && resourceKey.length() > 0) ? Boolean.TRUE : Boolean.FALSE;
			BooleanRequestStateVariable.RESOURCE_REQUEST.set(context, resourceRequest);

			if (LOGGER.isDebugEnabled()) {
				if (Boolean.TRUE.equals(resourceRequest)) {
					LOGGER.debug(MessageFormat.format("Resource request detected: {0}", resourceKey));
				}
			}
		}

		return resourceRequest.booleanValue();	
	}
	
	public boolean isResourceRequest(FacesContext context) {
		return isThisHandlerResourceRequest(context) || defaultHandler.isResourceRequest(context);
	}

	private Resource lookupInCache(FacesContext context, String resourceKey) {
		Resource resource = (Resource) cache.get(resourceKey);

		if (LOGGER.isDebugEnabled()) {
			if (resource == null) {
				LOGGER.debug("Resource was not located in cache");
			} else {
				LOGGER.debug("Resource was located in cache");
			}
		}

		return resource;
	}
	
	private void sendNotModified(FacesContext context) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("User agent has actual resource copy - sending 304 status code");
		}
		
		//TODO send cacheable resource headers (ETag + LastModified)?
		context.getExternalContext().setResponseStatus(HttpServletResponse.SC_NOT_MODIFIED);
	}

	private void logResourceProblem(FacesContext context, Throwable throwable, String messagePattern, Object... arguments) {
		boolean isProductionStage = context.isProjectStage(ProjectStage.Production); 
		if (LOGGER.isWarnEnabled() || (!isProductionStage && LOGGER.isInfoEnabled())) {
			String formattedMessage = MessageFormat.format(messagePattern, arguments);

			if (throwable != null) {
				LOGGER.warn(formattedMessage, throwable);
			} else {
				if (isProductionStage) {
					LOGGER.info(formattedMessage);
				} else {
					LOGGER.warn(formattedMessage);
				}
			}
		}
	}
	
	private void logMissingResource(FacesContext context, String resourceData) {
		logResourceProblem(context, null, "Resource {0} was not found", resourceData);
	}
	
	private void sendResourceNotFound(FacesContext context) {
		context.getExternalContext().setResponseStatus(HttpServletResponse.SC_NOT_FOUND);
	}
	
	public void handleResourceRequest(FacesContext context) throws IOException {
		if (isThisHandlerResourceRequest(context)) {
			String resourceKey = getResourceKey(context);
			
			assert (resourceKey != null && resourceKey.length() != 0);
			
			Resource resource = lookupInCache(context, resourceKey);
			if (resource == null) {
				ResourceCodec resourceCodec = ResourceHandlerImpl.getResourceCodec(context);
				String resourceName = resourceCodec.decodeResourceName(resourceKey);
				if (resourceName == null || resourceName.length() == 0) {
					logMissingResource(context, resourceKey);
					sendResourceNotFound(context);
					return;
				}
				
				if (isResourceExists(resourceName)) {
					resource = createHandlerDependentResource(resourceName);
				}

				if (resource == null) {
					logMissingResource(context, resourceName);
					sendResourceNotFound(context);
					return;
				}
				
				if (resource instanceof VersionedResource) {
					VersionedResource versionedResource = (VersionedResource) resource;
					String existingVersion = versionedResource.getVersion();
					String requestedVersion = resourceCodec.decodeResourceVersion(resourceKey);
					
					if (LOGGER.isDebugEnabled()) {
						LOGGER.debug(MessageFormat.format("Client requested {0} version of resource, server has {1} version", 
							String.valueOf(requestedVersion), String.valueOf(existingVersion)));
					}
					
					if (existingVersion != null && requestedVersion != null && 
							!existingVersion.equals(requestedVersion)) {
						
						logResourceProblem(context, null, "Resource {0} of version {1} was not found", 
							resourceName, requestedVersion);
						
						sendResourceNotFound(context);
						return;
					}
				}
				
				if (resource instanceof StateHolder) {
					StateHolder stateHolder = (StateHolder) resource;
					Object decodedData = resourceCodec.decodeResourceData(resourceKey);

					if (LOGGER.isDebugEnabled()) {
						if (decodedData != null) {
							LOGGER.debug("Resource state data succesfully decoded");
						} else {
							LOGGER.debug("Resource state data decoded as null");
						}
					}
					
					if (decodedData != null) {
						stateHolder.restoreState(context, decodedData);
					} else {
						//resource was transient and didn't store data
					}
				}
				
				if (resource instanceof AbstractCacheableResource) {
					AbstractCacheableResource cacheableResource = (AbstractCacheableResource) resource;
					
					if (cacheableResource.isCacheable(context)) {
						//TODO - we could move this part of code to ConcurrentMap so that 
						//only single thread does resource put
						CachedResourceImpl cachedResource = new CachedResourceImpl();
						cachedResource.initialize(resource);

						//someone may provided this resource for us
						//while we were reading it, check once again
						resource = lookupInCache(context, resourceKey);
						if (resource == null) {
							Date cacheExpirationDate = cachedResource.getExpired(context);
							
							if (LOGGER.isDebugEnabled()) {
								LOGGER.debug(new MessageFormat("Storing {0} resource in cache until {1,date,dd MMM yyyy HH:mm:ss zzz}", 
									Locale.US).format(new Object[]{resourceKey, cacheExpirationDate}));
							}
							
							cache.put(resourceKey, cachedResource, cacheExpirationDate);
							resource = cachedResource;
						}
					}
				}
			}
			
			if (resource.userAgentNeedsUpdate(context)) {
				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug("User agent needs resource update, encoding resource");
				}
				
				ExternalContext externalContext = context.getExternalContext();
				Map<String, String> headers = resource.getResponseHeaders();
				for (Entry<String, String> headerEntry : headers.entrySet()) {
					String headerName = headerEntry.getKey();
					String headerValue = headerEntry.getValue();
					
					//TODO should external context handles this itself?
					if ("content-length".equals(headerName.toLowerCase(Locale.US))) {
						try {
							externalContext.setResponseContentLength(Integer.parseInt(headerValue));
						} catch (NumberFormatException e) {
							// TODO: handle exception
						}
					}/* else if ("content-type".equals(headerName.toLowerCase(Locale.US))) {
						externalContext.setResponseContentType(headerValue);
					}*/ else {
						externalContext.setResponseHeader(headerName, headerValue);
					}
				}

				//TODO null content type?
				String contentType = resource.getContentType();
				if (contentType != null) {
					externalContext.setResponseContentType(contentType);
				}
			
				//TODO - portlets
				HttpServletRequest httpServletRequest = (HttpServletRequest) externalContext.getRequest();
				if (!"HEAD".equals(httpServletRequest.getMethod())) {
					//TODO 'HEAD' HTTP method resources - ?
					//TODO setup output buffer size according to configuration parameter
					InputStream is = resource.getInputStream();
					OutputStream os = externalContext.getResponseOutputStream();

					try {
						Util.copyStreamContent(is, os);
					} finally {
						if (is != null) {
							try {
								is.close();
							} catch (IOException e) {
								if (LOGGER.isDebugEnabled()) {
									LOGGER.debug(e.getMessage(), e);
								}
							}
						}
						//TODO flush resource
						//TODO dispose resource
					}
				}

				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug("Resource succesfully encoded");
				}
				
			} else {
				sendNotModified(context);
			}
		} else {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("Passing request to the next resource handler in chain");
			}
			defaultHandler.handleResourceRequest(context);
		}
	}

	protected boolean isResourceExists(String resourceName) {
		boolean result = false;
		ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
		if (contextClassLoader != null) {
			//TODO resource marker extension name?
			URL resourceMarkerUrl = contextClassLoader.getResource("META-INF/" + resourceName + ".resource.properties");
			result = (resourceMarkerUrl != null);
			
			if (LOGGER.isDebugEnabled()) {
				if (result) {
					LOGGER.debug(MessageFormat.format("Marker file for {0} resource found in classpath", resourceName));
				} else {
					LOGGER.debug(MessageFormat.format("Marker file for {0} resource does not exist", resourceName));
				}
			}
		}
		
		return result;
	}
	
	/**
	 * Should be called only if {@link #isResourceExists(String)} returns <code>true</code>
	 * @param resourceName
	 * @return
	 */
	protected Resource createHandlerDependentResource(String resourceName) {
		
		Resource resource = null;
		
		ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
		if (contextClassLoader != null) {
			try {
				Class<?> resourceClass = Class.forName(resourceName, false, contextClassLoader);
				if (Resource.class.isAssignableFrom(resourceClass)) {
					resource = (Resource) resourceClass.newInstance();
					resource.setResourceName(resourceName);
				
					if (LOGGER.isDebugEnabled()) {
						LOGGER.debug(MessageFormat.format(
							"Successfully created instance of {0} resource", resourceName));
					}
				} else {
					throw new ClassCastException(resourceClass.getName());
				}
			} catch (Throwable t) {
				logResourceProblem(FacesContext.getCurrentInstance(), t, 
					"Error creating resource {0}", resourceName);
			}
		}
		
		return resource;
	}
	
	public Resource createResource(String resourceName, String libraryName,
			String contentType) {

		Resource result = null;
		
		if (resourceName != null && (libraryName == null || libraryName.length() == 0)
				&& isResourceExists(resourceName)) {
			
			result = createHandlerDependentResource(resourceName);
		} else {
			result = defaultHandler.createResource(resourceName, libraryName, contentType);
		}
		
		return result;
	}

	public Resource createResource(String resourceName, String libraryName) {
		return createResource(resourceName, libraryName, null);
	}

	public Resource createResource(String resourceName) {
		return createResource(resourceName, null, null);
	}

	public String getRendererTypeForResourceName(String resourceName) {
		//TODO add support for dynamic resources
		return defaultHandler.getRendererTypeForResourceName(resourceName);
	}

	public boolean libraryExists(String libraryName) {
		return defaultHandler.libraryExists(libraryName);
	}
}
