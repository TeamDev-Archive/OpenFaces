/**
 * 
 */
package org.richfaces.resource;

/**
 * @author Nick Belaevski
 * @since 4.0
 */
public interface ResourceCodec {

	public String encodeResource(String resourceName, Object resourceData, String resourceVersion);
	
	public String decodeResourceName(String resourceKey);

	public Object decodeResourceData(String resourceKey);

	public String decodeResourceVersion(String resourceKey);
}
