/**
 * License Agreement.
 *
 * Rich Faces - Natural Ajax for Java Server Faces (JSF)
 *
 * Copyright (C) 2007 Exadel, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 2.1 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
 */
package org.richfaces.resource;

import java.util.Date;
import java.util.Map;

import javax.faces.application.Resource;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.richfaces.log.RichfacesLogger;
import org.richfaces.util.Util;
import org.slf4j.Logger;

/**
 * @author Nick Belaevski
 * @since 4.0
 */
public abstract class AbstractCacheableResource extends Resource {

	private static final Logger LOGGER = RichfacesLogger.RESOURCE.getLogger();

	protected abstract Date getLastModified(FacesContext context);

	public abstract boolean isCacheable(FacesContext context);
	
	protected abstract String getEntityTag(FacesContext context);
	
	//TODO add getExpired(FacesContext) for HTTP matching headers?
	
	private Boolean userCopyIsActual(Date lastModified, Date modifiedCondition) {
		if (modifiedCondition == null) {
			return null;
		}
		
		if (lastModified == null) {
			return Boolean.FALSE;
		}
		
		// 1000 ms due to round
		// modification
		// time to seconds.
		return Boolean.valueOf((lastModified.getTime() - modifiedCondition.getTime()) <= 1000);
	}
	
	protected Boolean matchesLastModified(FacesContext context) {
		ExternalContext externalContext = context.getExternalContext();
		Map<String, String> requestHeaderMap = externalContext.getRequestHeaderMap();

		String modifiedCondition = requestHeaderMap.get("If-Modified-Since");
		return userCopyIsActual(getLastModified(context), Util.parseHttpDate(modifiedCondition));
	}
	
	protected Boolean matchesEntityTag(FacesContext context) {
		ExternalContext externalContext = context.getExternalContext();
		Map<String, String> requestHeaderMap = externalContext.getRequestHeaderMap();
		String matchHeaderValue = requestHeaderMap.get("If-None-Match");

		if (matchHeaderValue == null) {
			//no need to check
			return null;
		} else {
			String resourceEntityTag = getEntityTag(context);
			if (resourceEntityTag != null) {
				return ResourceUtils.matchTag(resourceEntityTag, matchHeaderValue);
			} else {
				return Boolean.FALSE;
			}
		}
	}
	
	@Override
	public boolean userAgentNeedsUpdate(FacesContext context) {
		if (!isCacheable(context)) {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("User agent cache check: resource is not cacheable");
			}
			
			return true;
		}

		Boolean matchesEntityTag = matchesEntityTag(context);
		if (Boolean.FALSE.equals(matchesEntityTag)) {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("User agent cache check: entity tags don't match");
			}

			return true;
		}

		Boolean matchesLastModified = matchesLastModified(context);
		if (Boolean.FALSE.equals(matchesLastModified)) {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("User agent cache check: resource was modified since the last request");
			}
			return true;
		}
		
		if (matchesLastModified == null && matchesEntityTag == null) {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("User agent cache check: no cache information was provided in request");
			}
			return true;
		}
		
		return false;
	}
	
}
