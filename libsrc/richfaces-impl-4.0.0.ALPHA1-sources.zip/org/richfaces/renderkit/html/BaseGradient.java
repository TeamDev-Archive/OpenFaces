/**
 * License Agreement.
 *
 *  JBoss RichFaces - Ajax4jsf Component Library
 *
 * Copyright (C) 2007  Exadel, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 2.1 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
 */

package org.richfaces.renderkit.html;

import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;

import javax.faces.context.FacesContext;

import org.ajax4jsf.resource.Java2Dresource;
import org.ajax4jsf.util.HtmlColor;
import org.ajax4jsf.util.HtmlDimensions;
import org.ajax4jsf.util.NumericDataInputStream;
import org.ajax4jsf.util.NumericDataOutputStream;
import org.richfaces.renderkit.html.images.GradientType;
import org.richfaces.renderkit.html.images.GradientType.BiColor;
import org.richfaces.skin.Skin;
import org.richfaces.skin.SkinFactory;

/**
 * @author Nick Belaevski - nbelaevski@exadel.com
 * created 02.02.2007
 * 
 */
public class BaseGradient extends Java2Dresource {

	private final int width;
	private final int height;
	private final int gradientHeight;
	private final String baseColor;
	private final String gradientColor;
	private final boolean horizontal;

	protected Integer headerBackgroundColor;
	protected Integer headerGradientColor;
	protected GradientType gradientType;

	private void initialize() {
		FacesContext context = FacesContext.getCurrentInstance();
		
		Integer baseIntColor = null;
		Integer headerIntColor = null;
		String gradientTypeString = null;

		if (baseIntColor == null) {
			baseIntColor = getColorValueParameter(context, baseColor, false);
		}

		if (headerIntColor == null) {
			headerIntColor = getColorValueParameter(context, gradientColor, false);
		}

		if (!(baseIntColor == null && headerIntColor == null)) {
			if (baseIntColor == null) {
				baseIntColor = getColorValueParameter(context, baseColor, true);
			}

			if (headerIntColor == null) {
				headerIntColor = getColorValueParameter(context, gradientColor, true);
			}
		}

		this.headerBackgroundColor = baseIntColor;
		this.headerGradientColor = headerIntColor;

		if (gradientTypeString == null || gradientTypeString.length() == 0) {
			gradientTypeString = getValueParameter(context, Skin.gradientType);
		}

		this.gradientType = GradientType.getByParameter(gradientTypeString);
	}
	
	public BaseGradient(int width, int height, int gradientHeight, String baseColor, String gradientColor, boolean horizontal) {
		super(ImageType.PNG);
		this.width = width;
		this.height = height;
		this.gradientHeight = gradientHeight;
		this.baseColor = baseColor != null ? baseColor : Skin.headerBackgroundColor;
		this.gradientColor = gradientColor != null ? gradientColor : Skin.headerGradientColor;
		this.horizontal = horizontal;

		initialize();
	}

	public BaseGradient(int width, int height, int gradientHeight) {
		this(width, height, gradientHeight, null, null, false);
	}

	public BaseGradient(int width, int height, int gradientHeight, String baseColor, String gradientColor) {
		this(width, height, gradientHeight, baseColor, gradientColor, false);
	}

	public BaseGradient(int width, int height) {
		this(width, height, height);
	}

	public BaseGradient(int width, int height, String baseColor, String gradientColor) {
		this(width, height, height, baseColor, gradientColor);
	}

	public BaseGradient() {
		this(30, 50, 20);
	}

	public BaseGradient(String baseColor, String gradientColor) {
		this(30, 50, 20, baseColor, gradientColor);
	}

	public BaseGradient(int width, int height, int gradientHeight, boolean horizontal) {
		this(width, height, gradientHeight, null, null, horizontal);
	}

	public BaseGradient(int width, int height, boolean horizontal) {
		this(width, height, horizontal ? width : height, null, null, horizontal);
	}

	public BaseGradient(int width, int height, String baseColor, String gradientColor, boolean horizontal) {
		this(width, height, horizontal ? width : height, baseColor, gradientColor, horizontal);
	}

	public BaseGradient(boolean horizontal) {
		this(30, 50, 20, null, null, horizontal);
	}

	public BaseGradient(String baseColor, String gradientColor, boolean horizontal) {
		this(30, 50, 20, baseColor, gradientColor, horizontal);
	}

	public Dimension getDimension() {
		return new Dimension(width, height);
	}

	/**
	 * @return the gradientHeight
	 */
	protected int getGradientHeight() {
		return gradientHeight;
	}

	/**
	 * @return the baseColor
	 */
	protected String getBaseColor() {
		return baseColor;
	}

	/**
	 * @return the gradientColor
	 */
	protected String getGradientColor() {
		return gradientColor;
	}

	/**
	 * @return the horizontal
	 */
	protected boolean isHorizontal() {
		return horizontal;
	}

	protected void drawGradient(Graphics2D g2d, Shape shape, BiColor colors, int height) {
		if (colors != null) {
			GradientPaint gragient = new GradientPaint(0, 0, colors.getTopColor(), 0, height, colors.getBottomColor());
			g2d.setPaint(gragient);
			g2d.fill(shape);
		}
	}

	@Override
	protected void paint(Graphics2D graphics2d, Dimension dimension) {
		super.paint(graphics2d, dimension);

		graphics2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		graphics2d.setRenderingHint(RenderingHints.KEY_DITHERING, RenderingHints.VALUE_DITHER_ENABLE);

		graphics2d.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION, RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
		graphics2d.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING, RenderingHints.VALUE_COLOR_RENDER_QUALITY);
		graphics2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

		paintGradient(graphics2d, dimension);
	}
	
	/**
	 * @param g2d
	 * @param data
	 */
	protected void paintGradient(Graphics2D g2d, Dimension dim) {
		if ((headerBackgroundColor != null || headerGradientColor != null) && gradientType != null) {
			BiColor biColor = new GradientType.BiColor(headerBackgroundColor, headerGradientColor);

			BiColor firstLayer = gradientType.getFirstLayerColors(biColor);
			BiColor secondLayer = gradientType.getSecondLayerColors(biColor);

			if (horizontal) {
				//x -> y, y -> x
				g2d.transform(new AffineTransform(0, 1, 1, 0, 0, 0));
				dim.setSize(dim.height, dim.width);
			}

			int localGradientHeight = this.gradientHeight;
			if (localGradientHeight < 0) {
				localGradientHeight = dim.height;
			}

			Rectangle2D rect = new Rectangle2D.Float(
					0, 
					0, 
					dim.width, 
					dim.height);

			drawGradient(g2d, rect, firstLayer, localGradientHeight);

			int smallGradientHeight = localGradientHeight / 2;

			rect = new Rectangle2D.Float(
					0, 
					0, 
					dim.width, 
					smallGradientHeight);

			drawGradient(g2d, rect, secondLayer, smallGradientHeight);
		}
	}

	@Override
	protected void readState(FacesContext context, NumericDataInputStream stream) {
		super.readState(context, stream);

		this.headerBackgroundColor = stream.readInt();
		this.headerGradientColor = stream.readInt();
		this.gradientType = GradientType.values()[stream.readByte()];
	}

	@Override
	protected void writeState(FacesContext context,
			NumericDataOutputStream stream) {
		super.writeState(context, stream);

		stream.writeInt(this.headerBackgroundColor);
		stream.writeInt(this.headerGradientColor);
		stream.writeByte((byte) this.gradientType.ordinal());
	}
	
	private Integer decodeColor(String value) {
		if (value !=null && value.length() != 0) {
			return Integer.valueOf(HtmlColor.decode(value).getRGB());
		} else {
			return null;
		}
	}

	public boolean isCacheable() {
		return true;
	}

	protected String getValueParameter(FacesContext context, String name) {
		SkinFactory skinFactory = SkinFactory.getInstance();

		Skin skin = skinFactory.getSkin(context);
		String value = (String) skin.getParameter(context, name);

		if (value == null || value.length() == 0) {
			skin = skinFactory.getDefaultSkin(context);
			value = (String) skin.getParameter(context, name);
		}

		return value;
	}

	protected Integer getColorValueParameter(FacesContext context, String name, boolean useDefault) {
		Skin skin;
		if (useDefault) {
			skin = SkinFactory.getInstance().getDefaultSkin(context);
		} else {
			skin = SkinFactory.getInstance().getSkin(context);
		}

		return decodeColor((String) skin.getParameter(context,name)); 
	}

    protected Integer getHeight(FacesContext context, String heightParamName) {
        SkinFactory skinFactory = SkinFactory.getInstance();
        Skin skin = skinFactory.getSkin(context);

        String height = (String) skin.getParameter(context, heightParamName);
        if (height == null || height.length() == 0) {
            skin = skinFactory.getDefaultSkin(context);
            height = (String) skin.getParameter(context, heightParamName);
        }

        if (height != null && height.length() != 0) {
            return Integer.valueOf(HtmlDimensions.decode(height).intValue());
        } else {
            return Integer.valueOf(16);
        }
    }
}
