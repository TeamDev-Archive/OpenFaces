/**
 * Exception classes of RichFaces components
 */
package org.ajax4jsf.exception;
