/**
 * Classes implementing event-handling logic of JSF framework
 */
package org.ajax4jsf.event;
