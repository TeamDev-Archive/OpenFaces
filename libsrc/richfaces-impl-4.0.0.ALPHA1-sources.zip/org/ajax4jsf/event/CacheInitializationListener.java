package org.ajax4jsf.event;

import java.util.Map;
import java.util.Set;

import javax.faces.event.SystemEvent;

import org.ajax4jsf.cache.Cache;
import org.ajax4jsf.cache.CacheManager;

/**
 * @author Anton Belevich
 *
 */
public class CacheInitializationListener extends InitializationListener {
	
	@Override
	public void init(SystemEvent event) {
		//TODO read configuration ??
	}
	
	
	@Override
	public void destroy(SystemEvent event) {
		CacheManager cacheManager = CacheManager.getInstance();
		Map <String, Cache> caches = cacheManager.getCaches();
		if(!caches.isEmpty()) {
			Set <String> cacheNames = caches.keySet();
			for(String cacheName: cacheNames) {
				try {
					cacheManager.destroyCache(cacheName);
				} catch (Exception e) {
					looger.error("Error during stop cache " + cacheName, e);
				}
			}
		}
	}
}
