package org.ajax4jsf.event;

import javax.faces.application.Application;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.PostConstructApplicationEvent;
import javax.faces.event.PreDestroyApplicationEvent;
import javax.faces.event.SystemEvent;
import javax.faces.event.SystemEventListener;

import org.richfaces.log.RichfacesLogger;
import org.slf4j.Logger;

/**
 * framework initialization listener
 * @author Anton Belevich
 *
 */
public abstract class InitializationListener implements SystemEventListener {
	
	protected static final Logger looger = RichfacesLogger.CACHE.getLogger();
	
	public boolean isListenerForSource(Object source) {
		return source instanceof Application ? true : false;
	}

	public void processEvent(SystemEvent event) throws AbortProcessingException {
		if(event instanceof PostConstructApplicationEvent) {
			init(event);	
		} else if(event instanceof PreDestroyApplicationEvent) {
			destroy(event);
		}
	}
	
	public abstract void init(SystemEvent event);
	
	public abstract void destroy(SystemEvent event);
	
}
