/**
 * Implementation of I/O streams based on buffers 
 */
package org.ajax4jsf.io;
