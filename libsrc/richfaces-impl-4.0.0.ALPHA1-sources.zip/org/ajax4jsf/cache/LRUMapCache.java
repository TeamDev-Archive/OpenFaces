/**
 * License Agreement.
 *
 * Rich Faces - Natural Ajax for Java Server Faces (JSF)
 *
 * Copyright (C) 2007 Exadel, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 2.1 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
 */

package org.ajax4jsf.cache;

import java.util.Date;
import java.util.PriorityQueue;

import org.ajax4jsf.util.LRUMap;

/**
 * @author Nick - mailto:nbelaevski@exadel.com
 * @since 3.1
 */
public class LRUMapCache implements Cache {

	protected static final class CacheMap extends LRUMap<Object, CacheEntry> {
		/**
		 * 
		 */
		private static final long serialVersionUID = -5422668357346537621L;

		public CacheMap() {
			super();
		}

		public CacheMap(int capacity) {
			super(capacity);
		}

		protected PriorityQueue<CacheEntry> expirationQueue = new PriorityQueue<CacheEntry>();

		public CacheEntry put(Object key, CacheEntry value) {
			CacheEntry entry = super.put(key, value);
			if (entry != null) {
				//prolong
				expirationQueue.remove(entry);
			}
		
			if (value.expired != null) {
				expirationQueue.add(value);
			}
			
			return entry;
		}

		public CacheEntry remove(Object key) {
			CacheEntry entry = super.remove(key);
			if (entry != null) {
				expirationQueue.remove(entry);
			}
			
			return entry;
		}

		public void clear() {
			super.clear();
			expirationQueue.clear();
		}

		public void purge() {
			CacheEntry queueEntry = null;

			while ((queueEntry = expirationQueue.peek()) != null && 
					queueEntry.isExpired()) {
				
				super.remove(queueEntry.getKey());
				expirationQueue.remove();
			}
		}
	}

	protected static final class CacheEntry implements Comparable<CacheEntry> {

		private Object key;
		
		private Object value;
		
		private Date expired;

		public CacheEntry(Object key, Object value, Date expired) {
			super();
			
			this.key  = key;
			this.value = value;
			this.expired = expired;
		}

		public Object getKey() {
			return key;
		}
		
		public Object getValue() {
			return value;
		}

		public boolean isExpired() {
			if (expired != null) {
				return System.currentTimeMillis() >= expired.getTime();
			} else {
				return false;
			}
		}
		
		//due to PriorityQueue bug in JDK 1.5 comparator should return 0 ONLY if entries are equal
		public int compareTo(CacheEntry o) {
			//reverse sort order
			int result = expired.compareTo(o.expired);
			if (result == 0) {
				result = key.toString().compareTo(o.key.toString());
			}
			
			return result;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((key == null) ? 0 : key.hashCode());
			return result;
		}

		//see compareTo()
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			CacheEntry other = (CacheEntry) obj;
			if (key == null) {
				if (other.key != null)
					return false;
			} else if (!key.equals(other.key))
				return false;
			return true;
		}
		
		@Override
		public String toString() {
			if (expired == null) {
				return key.toString();
			} else {
				return key + ": " + expired;
			}
		}
	}
	
	private CacheMap map;
	
	public LRUMapCache() {
		this.map = new CacheMap();
	}
	
	public LRUMapCache(int capacity) {
		this.map = new CacheMap(capacity);
	}
	
	public synchronized Object get(Object key) {
		this.map.purge();

		CacheEntry entry = this.map.get(key);
		if (entry != null) {
			return entry.getValue();
		}
		
		return null;
	}

	public synchronized void put(Object key, Object value, Date expired) {
		this.map.purge();

		CacheEntry cacheEntry = new CacheEntry(key, value, expired);
		this.map.put(key, cacheEntry);
	}

	public void start() {
	}

	public void stop() {
		this.map.clear();
	}
}
