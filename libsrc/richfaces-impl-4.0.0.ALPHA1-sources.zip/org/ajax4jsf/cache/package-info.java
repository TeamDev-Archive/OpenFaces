/**
 * Cache implementations
 */
package org.ajax4jsf.cache;
