/**
 * 
 */
package org.ajax4jsf.cache;

import java.util.Map;

import org.richfaces.log.RichfacesLogger;
import org.slf4j.Logger;

/**
 * @author Nick Belaevski
 * @since 4.0
 */
public class EhCacheCacheFactory implements CacheFactory {

    private static final Logger log = RichfacesLogger.CACHE.getLogger();

    public Cache createCache(Map<?, ?> env) {
	    log.info("Creating EhCache cache instance");	    

	    net.sf.ehcache.Ehcache cache = new net.sf.ehcache.Cache("org.richfaces", 256, false, true, 0, 0);
		return new EhCacheCache(cache);
	}

}
