/**
 * Implementation of cached resources
 */
package org.ajax4jsf.resource.cached;
