/**
 * Image resources support classes
 */
package org.ajax4jsf.resource.image;
