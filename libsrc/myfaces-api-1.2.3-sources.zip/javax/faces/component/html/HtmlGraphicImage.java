// WARNING: This file was automatically generated. Do not edit it directly,
//          or you will lose your changes.

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
*/
package javax.faces.component.html;

import javax.el.ValueExpression;
import javax.faces.component.UIGraphic;
import javax.faces.context.FacesContext;

/**
 */
public class HtmlGraphicImage extends UIGraphic
{

  static public final String COMPONENT_FAMILY =
    "javax.faces.Graphic";
  static public final String COMPONENT_TYPE =
    "javax.faces.HtmlGraphicImage";

  /**
   * Construct an instance of the HtmlGraphicImage.
   */
  public HtmlGraphicImage()
  {
    setRendererType("javax.faces.Image");
  }

  // Property: style
  private String _style;

  /**
   * Gets CSS styling instructions.
   *
   * @return  the new style value
   */
  public String getStyle()
  {
    if (_style != null)
    {
      return _style;
    }
    ValueExpression expression = getValueExpression("style");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets CSS styling instructions.
   * 
   * @param style  the new style value
   */
  public void setStyle(String style)
  {
    this._style = style;
  }

  // Property: styleClass
  private String _styleClass;

  /**
   * Gets The CSS class for this element. Corresponds to the HTML 'class' attribute.
   *
   * @return  the new styleClass value
   */
  public String getStyleClass()
  {
    if (_styleClass != null)
    {
      return _styleClass;
    }
    ValueExpression expression = getValueExpression("styleClass");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets The CSS class for this element. Corresponds to the HTML 'class' attribute.
   * 
   * @param styleClass  the new styleClass value
   */
  public void setStyleClass(String styleClass)
  {
    this._styleClass = styleClass;
  }

  // Property: dir
  private String _dir;

  /**
   * Gets The direction of text display, either 'ltr' (left-to-right) or 'rtl' (right-to-left).
   *
   * @return  the new dir value
   */
  public String getDir()
  {
    if (_dir != null)
    {
      return _dir;
    }
    ValueExpression expression = getValueExpression("dir");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets The direction of text display, either 'ltr' (left-to-right) or 'rtl' (right-to-left).
   * 
   * @param dir  the new dir value
   */
  public void setDir(String dir)
  {
    this._dir = dir;
  }

  // Property: lang
  private String _lang;

  /**
   * Gets The base language of this document.
   *
   * @return  the new lang value
   */
  public String getLang()
  {
    if (_lang != null)
    {
      return _lang;
    }
    ValueExpression expression = getValueExpression("lang");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets The base language of this document.
   * 
   * @param lang  the new lang value
   */
  public void setLang(String lang)
  {
    this._lang = lang;
  }

  // Property: title
  private String _title;

  /**
   * Gets An advisory title for this element. Often used by the user agent as a tooltip.
   *
   * @return  the new title value
   */
  public String getTitle()
  {
    if (_title != null)
    {
      return _title;
    }
    ValueExpression expression = getValueExpression("title");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets An advisory title for this element. Often used by the user agent as a tooltip.
   * 
   * @param title  the new title value
   */
  public void setTitle(String title)
  {
    this._title = title;
  }

  // Property: onclick
  private String _onclick;

  /**
   * Gets Script to be invoked when the element is clicked.
   *
   * @return  the new onclick value
   */
  public String getOnclick()
  {
    if (_onclick != null)
    {
      return _onclick;
    }
    ValueExpression expression = getValueExpression("onclick");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the element is clicked.
   * 
   * @param onclick  the new onclick value
   */
  public void setOnclick(String onclick)
  {
    this._onclick = onclick;
  }

  // Property: ondblclick
  private String _ondblclick;

  /**
   * Gets Script to be invoked when the element is double-clicked.
   *
   * @return  the new ondblclick value
   */
  public String getOndblclick()
  {
    if (_ondblclick != null)
    {
      return _ondblclick;
    }
    ValueExpression expression = getValueExpression("ondblclick");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the element is double-clicked.
   * 
   * @param ondblclick  the new ondblclick value
   */
  public void setOndblclick(String ondblclick)
  {
    this._ondblclick = ondblclick;
  }

  // Property: onmousedown
  private String _onmousedown;

  /**
   * Gets Script to be invoked when the pointing device is pressed over this element.
   *
   * @return  the new onmousedown value
   */
  public String getOnmousedown()
  {
    if (_onmousedown != null)
    {
      return _onmousedown;
    }
    ValueExpression expression = getValueExpression("onmousedown");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the pointing device is pressed over this element.
   * 
   * @param onmousedown  the new onmousedown value
   */
  public void setOnmousedown(String onmousedown)
  {
    this._onmousedown = onmousedown;
  }

  // Property: onmouseup
  private String _onmouseup;

  /**
   * Gets Script to be invoked when the pointing device is released over this element.
   *
   * @return  the new onmouseup value
   */
  public String getOnmouseup()
  {
    if (_onmouseup != null)
    {
      return _onmouseup;
    }
    ValueExpression expression = getValueExpression("onmouseup");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the pointing device is released over this element.
   * 
   * @param onmouseup  the new onmouseup value
   */
  public void setOnmouseup(String onmouseup)
  {
    this._onmouseup = onmouseup;
  }

  // Property: onmouseover
  private String _onmouseover;

  /**
   * Gets Script to be invoked when the pointing device is moved into this element.
   *
   * @return  the new onmouseover value
   */
  public String getOnmouseover()
  {
    if (_onmouseover != null)
    {
      return _onmouseover;
    }
    ValueExpression expression = getValueExpression("onmouseover");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the pointing device is moved into this element.
   * 
   * @param onmouseover  the new onmouseover value
   */
  public void setOnmouseover(String onmouseover)
  {
    this._onmouseover = onmouseover;
  }

  // Property: onmousemove
  private String _onmousemove;

  /**
   * Gets Script to be invoked when the pointing device is moved while it is in this element.
   *
   * @return  the new onmousemove value
   */
  public String getOnmousemove()
  {
    if (_onmousemove != null)
    {
      return _onmousemove;
    }
    ValueExpression expression = getValueExpression("onmousemove");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the pointing device is moved while it is in this element.
   * 
   * @param onmousemove  the new onmousemove value
   */
  public void setOnmousemove(String onmousemove)
  {
    this._onmousemove = onmousemove;
  }

  // Property: onmouseout
  private String _onmouseout;

  /**
   * Gets Script to be invoked when the pointing device is moves out of this element.
   *
   * @return  the new onmouseout value
   */
  public String getOnmouseout()
  {
    if (_onmouseout != null)
    {
      return _onmouseout;
    }
    ValueExpression expression = getValueExpression("onmouseout");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the pointing device is moves out of this element.
   * 
   * @param onmouseout  the new onmouseout value
   */
  public void setOnmouseout(String onmouseout)
  {
    this._onmouseout = onmouseout;
  }

  // Property: onkeypress
  private String _onkeypress;

  /**
   * Gets Script to be invoked when a key is pressed over this element.
   *
   * @return  the new onkeypress value
   */
  public String getOnkeypress()
  {
    if (_onkeypress != null)
    {
      return _onkeypress;
    }
    ValueExpression expression = getValueExpression("onkeypress");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when a key is pressed over this element.
   * 
   * @param onkeypress  the new onkeypress value
   */
  public void setOnkeypress(String onkeypress)
  {
    this._onkeypress = onkeypress;
  }

  // Property: onkeydown
  private String _onkeydown;

  /**
   * Gets Script to be invoked when a key is pressed down over this element.
   *
   * @return  the new onkeydown value
   */
  public String getOnkeydown()
  {
    if (_onkeydown != null)
    {
      return _onkeydown;
    }
    ValueExpression expression = getValueExpression("onkeydown");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when a key is pressed down over this element.
   * 
   * @param onkeydown  the new onkeydown value
   */
  public void setOnkeydown(String onkeydown)
  {
    this._onkeydown = onkeydown;
  }

  // Property: onkeyup
  private String _onkeyup;

  /**
   * Gets Script to be invoked when a key is released over this element.
   *
   * @return  the new onkeyup value
   */
  public String getOnkeyup()
  {
    if (_onkeyup != null)
    {
      return _onkeyup;
    }
    ValueExpression expression = getValueExpression("onkeyup");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when a key is released over this element.
   * 
   * @param onkeyup  the new onkeyup value
   */
  public void setOnkeyup(String onkeyup)
  {
    this._onkeyup = onkeyup;
  }

  // Property: alt
  private String _alt;

  /**
   * Gets Specifies alternative text that can be used by a browser that can't show this element.
   *
   * @return  the new alt value
   */
  public String getAlt()
  {
    if (_alt != null)
    {
      return _alt;
    }
    ValueExpression expression = getValueExpression("alt");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Specifies alternative text that can be used by a browser that can't show this element.
   * 
   * @param alt  the new alt value
   */
  public void setAlt(String alt)
  {
    this._alt = alt;
  }

  // Property: height
  private String _height;

  /**
   * Gets Overrides the natural height of this image, by specifying height in pixels.
   *
   * @return  the new height value
   */
  public String getHeight()
  {
    if (_height != null)
    {
      return _height;
    }
    ValueExpression expression = getValueExpression("height");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Overrides the natural height of this image, by specifying height in pixels.
   * 
   * @param height  the new height value
   */
  public void setHeight(String height)
  {
    this._height = height;
  }

  // Property: width
  private String _width;

  /**
   * Gets Overrides the natural width of this image, by specifying width in pixels.
   *
   * @return  the new width value
   */
  public String getWidth()
  {
    if (_width != null)
    {
      return _width;
    }
    ValueExpression expression = getValueExpression("width");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Overrides the natural width of this image, by specifying width in pixels.
   * 
   * @param width  the new width value
   */
  public void setWidth(String width)
  {
    this._width = width;
  }

  // Property: longdesc
  private String _longdesc;

  /**
   * Gets A link to a long description of the image.
   *
   * @return  the new longdesc value
   */
  public String getLongdesc()
  {
    if (_longdesc != null)
    {
      return _longdesc;
    }
    ValueExpression expression = getValueExpression("longdesc");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets A link to a long description of the image.
   * 
   * @param longdesc  the new longdesc value
   */
  public void setLongdesc(String longdesc)
  {
    this._longdesc = longdesc;
  }

  // Property: usemap
  private String _usemap;

  /**
   * Gets Specifies an image map to use with this image.
   *
   * @return  the new usemap value
   */
  public String getUsemap()
  {
    if (_usemap != null)
    {
      return _usemap;
    }
    ValueExpression expression = getValueExpression("usemap");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Specifies an image map to use with this image.
   * 
   * @param usemap  the new usemap value
   */
  public void setUsemap(String usemap)
  {
    this._usemap = usemap;
  }

  // Property: ismap
  private boolean _ismap;
  private boolean _ismapSet;

  /**
   * Gets Specifies server-side image map handling for this image.
   *
   * @return  the new ismap value
   */
  public boolean isIsmap()
  {
    if (_ismapSet)
    {
      return _ismap;
    }
    ValueExpression expression = getValueExpression("ismap");
    if (expression != null)
    {
      return (Boolean)expression.getValue(getFacesContext().getELContext());
    }
    return false;
  }

  /**
   * Sets Specifies server-side image map handling for this image.
   * 
   * @param ismap  the new ismap value
   */
  public void setIsmap(boolean ismap)
  {
    this._ismap = ismap;
    this._ismapSet = true;
  }

  @Override
  public Object saveState(FacesContext facesContext)
  {
    Object[] values = new Object[23];
    values[0] = super.saveState(facesContext);
    values[1] = _style;
    values[2] = _styleClass;
    values[3] = _dir;
    values[4] = _lang;
    values[5] = _title;
    values[6] = _onclick;
    values[7] = _ondblclick;
    values[8] = _onmousedown;
    values[9] = _onmouseup;
    values[10] = _onmouseover;
    values[11] = _onmousemove;
    values[12] = _onmouseout;
    values[13] = _onkeypress;
    values[14] = _onkeydown;
    values[15] = _onkeyup;
    values[16] = _alt;
    values[17] = _height;
    values[18] = _width;
    values[19] = _longdesc;
    values[20] = _usemap;
    values[21] = _ismap;
    values[22] = _ismapSet;

    return values;
  }

  @Override
  public void restoreState(FacesContext facesContext, Object state)
  {
    Object[] values = (Object[])state;
    super.restoreState(facesContext,values[0]);
    _style = (String)values[1];
    _styleClass = (String)values[2];
    _dir = (String)values[3];
    _lang = (String)values[4];
    _title = (String)values[5];
    _onclick = (String)values[6];
    _ondblclick = (String)values[7];
    _onmousedown = (String)values[8];
    _onmouseup = (String)values[9];
    _onmouseover = (String)values[10];
    _onmousemove = (String)values[11];
    _onmouseout = (String)values[12];
    _onkeypress = (String)values[13];
    _onkeydown = (String)values[14];
    _onkeyup = (String)values[15];
    _alt = (String)values[16];
    _height = (String)values[17];
    _width = (String)values[18];
    _longdesc = (String)values[19];
    _usemap = (String)values[20];
    _ismap = (Boolean)values[21];
    _ismapSet = (Boolean)values[22];
  }

  @Override
  public String getFamily()
  {
    return COMPONENT_FAMILY;
  }
}
