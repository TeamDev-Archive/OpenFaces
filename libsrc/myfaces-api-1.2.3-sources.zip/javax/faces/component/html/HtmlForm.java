// WARNING: This file was automatically generated. Do not edit it directly,
//          or you will lose your changes.

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
*/
package javax.faces.component.html;

import javax.el.ValueExpression;
import javax.faces.component.UIForm;
import javax.faces.context.FacesContext;

/**
 */
public class HtmlForm extends UIForm
{

  static public final String COMPONENT_FAMILY =
    "javax.faces.Form";
  static public final String COMPONENT_TYPE =
    "javax.faces.HtmlForm";

  /**
   * Construct an instance of the HtmlForm.
   */
  public HtmlForm()
  {
    setRendererType("javax.faces.Form");
  }

  // Property: style
  private String _style;

  /**
   * Gets CSS styling instructions.
   *
   * @return  the new style value
   */
  public String getStyle()
  {
    if (_style != null)
    {
      return _style;
    }
    ValueExpression expression = getValueExpression("style");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets CSS styling instructions.
   * 
   * @param style  the new style value
   */
  public void setStyle(String style)
  {
    this._style = style;
  }

  // Property: styleClass
  private String _styleClass;

  /**
   * Gets The CSS class for this element. Corresponds to the HTML 'class' attribute.
   *
   * @return  the new styleClass value
   */
  public String getStyleClass()
  {
    if (_styleClass != null)
    {
      return _styleClass;
    }
    ValueExpression expression = getValueExpression("styleClass");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets The CSS class for this element. Corresponds to the HTML 'class' attribute.
   * 
   * @param styleClass  the new styleClass value
   */
  public void setStyleClass(String styleClass)
  {
    this._styleClass = styleClass;
  }

  // Property: dir
  private String _dir;

  /**
   * Gets The direction of text display, either 'ltr' (left-to-right) or 'rtl' (right-to-left).
   *
   * @return  the new dir value
   */
  public String getDir()
  {
    if (_dir != null)
    {
      return _dir;
    }
    ValueExpression expression = getValueExpression("dir");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets The direction of text display, either 'ltr' (left-to-right) or 'rtl' (right-to-left).
   * 
   * @param dir  the new dir value
   */
  public void setDir(String dir)
  {
    this._dir = dir;
  }

  // Property: lang
  private String _lang;

  /**
   * Gets The base language of this document.
   *
   * @return  the new lang value
   */
  public String getLang()
  {
    if (_lang != null)
    {
      return _lang;
    }
    ValueExpression expression = getValueExpression("lang");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets The base language of this document.
   * 
   * @param lang  the new lang value
   */
  public void setLang(String lang)
  {
    this._lang = lang;
  }

  // Property: title
  private String _title;

  /**
   * Gets An advisory title for this element. Often used by the user agent as a tooltip.
   *
   * @return  the new title value
   */
  public String getTitle()
  {
    if (_title != null)
    {
      return _title;
    }
    ValueExpression expression = getValueExpression("title");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets An advisory title for this element. Often used by the user agent as a tooltip.
   * 
   * @param title  the new title value
   */
  public void setTitle(String title)
  {
    this._title = title;
  }

  // Property: onclick
  private String _onclick;

  /**
   * Gets Script to be invoked when the element is clicked.
   *
   * @return  the new onclick value
   */
  public String getOnclick()
  {
    if (_onclick != null)
    {
      return _onclick;
    }
    ValueExpression expression = getValueExpression("onclick");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the element is clicked.
   * 
   * @param onclick  the new onclick value
   */
  public void setOnclick(String onclick)
  {
    this._onclick = onclick;
  }

  // Property: ondblclick
  private String _ondblclick;

  /**
   * Gets Script to be invoked when the element is double-clicked.
   *
   * @return  the new ondblclick value
   */
  public String getOndblclick()
  {
    if (_ondblclick != null)
    {
      return _ondblclick;
    }
    ValueExpression expression = getValueExpression("ondblclick");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the element is double-clicked.
   * 
   * @param ondblclick  the new ondblclick value
   */
  public void setOndblclick(String ondblclick)
  {
    this._ondblclick = ondblclick;
  }

  // Property: onmousedown
  private String _onmousedown;

  /**
   * Gets Script to be invoked when the pointing device is pressed over this element.
   *
   * @return  the new onmousedown value
   */
  public String getOnmousedown()
  {
    if (_onmousedown != null)
    {
      return _onmousedown;
    }
    ValueExpression expression = getValueExpression("onmousedown");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the pointing device is pressed over this element.
   * 
   * @param onmousedown  the new onmousedown value
   */
  public void setOnmousedown(String onmousedown)
  {
    this._onmousedown = onmousedown;
  }

  // Property: onmouseup
  private String _onmouseup;

  /**
   * Gets Script to be invoked when the pointing device is released over this element.
   *
   * @return  the new onmouseup value
   */
  public String getOnmouseup()
  {
    if (_onmouseup != null)
    {
      return _onmouseup;
    }
    ValueExpression expression = getValueExpression("onmouseup");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the pointing device is released over this element.
   * 
   * @param onmouseup  the new onmouseup value
   */
  public void setOnmouseup(String onmouseup)
  {
    this._onmouseup = onmouseup;
  }

  // Property: onmouseover
  private String _onmouseover;

  /**
   * Gets Script to be invoked when the pointing device is moved into this element.
   *
   * @return  the new onmouseover value
   */
  public String getOnmouseover()
  {
    if (_onmouseover != null)
    {
      return _onmouseover;
    }
    ValueExpression expression = getValueExpression("onmouseover");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the pointing device is moved into this element.
   * 
   * @param onmouseover  the new onmouseover value
   */
  public void setOnmouseover(String onmouseover)
  {
    this._onmouseover = onmouseover;
  }

  // Property: onmousemove
  private String _onmousemove;

  /**
   * Gets Script to be invoked when the pointing device is moved while it is in this element.
   *
   * @return  the new onmousemove value
   */
  public String getOnmousemove()
  {
    if (_onmousemove != null)
    {
      return _onmousemove;
    }
    ValueExpression expression = getValueExpression("onmousemove");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the pointing device is moved while it is in this element.
   * 
   * @param onmousemove  the new onmousemove value
   */
  public void setOnmousemove(String onmousemove)
  {
    this._onmousemove = onmousemove;
  }

  // Property: onmouseout
  private String _onmouseout;

  /**
   * Gets Script to be invoked when the pointing device is moves out of this element.
   *
   * @return  the new onmouseout value
   */
  public String getOnmouseout()
  {
    if (_onmouseout != null)
    {
      return _onmouseout;
    }
    ValueExpression expression = getValueExpression("onmouseout");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the pointing device is moves out of this element.
   * 
   * @param onmouseout  the new onmouseout value
   */
  public void setOnmouseout(String onmouseout)
  {
    this._onmouseout = onmouseout;
  }

  // Property: onkeypress
  private String _onkeypress;

  /**
   * Gets Script to be invoked when a key is pressed over this element.
   *
   * @return  the new onkeypress value
   */
  public String getOnkeypress()
  {
    if (_onkeypress != null)
    {
      return _onkeypress;
    }
    ValueExpression expression = getValueExpression("onkeypress");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when a key is pressed over this element.
   * 
   * @param onkeypress  the new onkeypress value
   */
  public void setOnkeypress(String onkeypress)
  {
    this._onkeypress = onkeypress;
  }

  // Property: onkeydown
  private String _onkeydown;

  /**
   * Gets Script to be invoked when a key is pressed down over this element.
   *
   * @return  the new onkeydown value
   */
  public String getOnkeydown()
  {
    if (_onkeydown != null)
    {
      return _onkeydown;
    }
    ValueExpression expression = getValueExpression("onkeydown");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when a key is pressed down over this element.
   * 
   * @param onkeydown  the new onkeydown value
   */
  public void setOnkeydown(String onkeydown)
  {
    this._onkeydown = onkeydown;
  }

  // Property: onkeyup
  private String _onkeyup;

  /**
   * Gets Script to be invoked when a key is released over this element.
   *
   * @return  the new onkeyup value
   */
  public String getOnkeyup()
  {
    if (_onkeyup != null)
    {
      return _onkeyup;
    }
    ValueExpression expression = getValueExpression("onkeyup");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when a key is released over this element.
   * 
   * @param onkeyup  the new onkeyup value
   */
  public void setOnkeyup(String onkeyup)
  {
    this._onkeyup = onkeyup;
  }

  // Property: target
  private String _target;

  /**
   * Gets Names the frame that should display content generated by invoking this action.
   *
   * @return  the new target value
   */
  public String getTarget()
  {
    if (_target != null)
    {
      return _target;
    }
    ValueExpression expression = getValueExpression("target");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Names the frame that should display content generated by invoking this action.
   * 
   * @param target  the new target value
   */
  public void setTarget(String target)
  {
    this._target = target;
  }

  // Property: accept
  private String _accept;

  /**
   * Gets Provides a comma-separated list of content types that the
   * server processing this form can handle.
   *
   * @return  the new accept value
   */
  public String getAccept()
  {
    if (_accept != null)
    {
      return _accept;
    }
    ValueExpression expression = getValueExpression("accept");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Provides a comma-separated list of content types that the
   * server processing this form can handle.
   * 
   * @param accept  the new accept value
   */
  public void setAccept(String accept)
  {
    this._accept = accept;
  }

  // Property: acceptcharset
  private String _acceptcharset;

  /**
   * Gets The list of character encodings accepted by the server for this form.
   *
   * @return  the new acceptcharset value
   */
  public String getAcceptcharset()
  {
    if (_acceptcharset != null)
    {
      return _acceptcharset;
    }
    ValueExpression expression = getValueExpression("acceptcharset");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets The list of character encodings accepted by the server for this form.
   * 
   * @param acceptcharset  the new acceptcharset value
   */
  public void setAcceptcharset(String acceptcharset)
  {
    this._acceptcharset = acceptcharset;
  }

  // Property: enctype
  private String _enctype;

  /**
   * Gets The content type used to submit this form to the server.
   *
   * @return  the new enctype value
   */
  public String getEnctype()
  {
    if (_enctype != null)
    {
      return _enctype;
    }
    ValueExpression expression = getValueExpression("enctype");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return "application/x-www-form-urlencoded";
  }

  /**
   * Sets The content type used to submit this form to the server.
   * 
   * @param enctype  the new enctype value
   */
  public void setEnctype(String enctype)
  {
    this._enctype = enctype;
  }

  // Property: onreset
  private String _onreset;

  /**
   * Gets Script to be invoked when this form is reset.
   *
   * @return  the new onreset value
   */
  public String getOnreset()
  {
    if (_onreset != null)
    {
      return _onreset;
    }
    ValueExpression expression = getValueExpression("onreset");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when this form is reset.
   * 
   * @param onreset  the new onreset value
   */
  public void setOnreset(String onreset)
  {
    this._onreset = onreset;
  }

  // Property: onsubmit
  private String _onsubmit;

  /**
   * Gets Script to be invoked when this form is submitted.
   *
   * @return  the new onsubmit value
   */
  public String getOnsubmit()
  {
    if (_onsubmit != null)
    {
      return _onsubmit;
    }
    ValueExpression expression = getValueExpression("onsubmit");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when this form is submitted.
   * 
   * @param onsubmit  the new onsubmit value
   */
  public void setOnsubmit(String onsubmit)
  {
    this._onsubmit = onsubmit;
  }

  @Override
  public Object saveState(FacesContext facesContext)
  {
    Object[] values = new Object[22];
    values[0] = super.saveState(facesContext);
    values[1] = _style;
    values[2] = _styleClass;
    values[3] = _dir;
    values[4] = _lang;
    values[5] = _title;
    values[6] = _onclick;
    values[7] = _ondblclick;
    values[8] = _onmousedown;
    values[9] = _onmouseup;
    values[10] = _onmouseover;
    values[11] = _onmousemove;
    values[12] = _onmouseout;
    values[13] = _onkeypress;
    values[14] = _onkeydown;
    values[15] = _onkeyup;
    values[16] = _target;
    values[17] = _accept;
    values[18] = _acceptcharset;
    values[19] = _enctype;
    values[20] = _onreset;
    values[21] = _onsubmit;

    return values;
  }

  @Override
  public void restoreState(FacesContext facesContext, Object state)
  {
    Object[] values = (Object[])state;
    super.restoreState(facesContext,values[0]);
    _style = (String)values[1];
    _styleClass = (String)values[2];
    _dir = (String)values[3];
    _lang = (String)values[4];
    _title = (String)values[5];
    _onclick = (String)values[6];
    _ondblclick = (String)values[7];
    _onmousedown = (String)values[8];
    _onmouseup = (String)values[9];
    _onmouseover = (String)values[10];
    _onmousemove = (String)values[11];
    _onmouseout = (String)values[12];
    _onkeypress = (String)values[13];
    _onkeydown = (String)values[14];
    _onkeyup = (String)values[15];
    _target = (String)values[16];
    _accept = (String)values[17];
    _acceptcharset = (String)values[18];
    _enctype = (String)values[19];
    _onreset = (String)values[20];
    _onsubmit = (String)values[21];
  }

  @Override
  public String getFamily()
  {
    return COMPONENT_FAMILY;
  }
}
