// WARNING: This file was automatically generated. Do not edit it directly,
//          or you will lose your changes.

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
*/
package javax.faces.component.html;

import javax.el.ValueExpression;
import javax.faces.component.UIMessage;
import javax.faces.context.FacesContext;

/**
 */
public class HtmlMessage extends UIMessage
{

  static public final String COMPONENT_FAMILY =
    "javax.faces.Message";
  static public final String COMPONENT_TYPE =
    "javax.faces.HtmlMessage";

  /**
   * Construct an instance of the HtmlMessage.
   */
  public HtmlMessage()
  {
    setRendererType("javax.faces.Message");
  }

  // Property: style
  private String _style;

  /**
   * Gets CSS styling instructions.
   *
   * @return  the new style value
   */
  public String getStyle()
  {
    if (_style != null)
    {
      return _style;
    }
    ValueExpression expression = getValueExpression("style");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets CSS styling instructions.
   * 
   * @param style  the new style value
   */
  public void setStyle(String style)
  {
    this._style = style;
  }

  // Property: styleClass
  private String _styleClass;

  /**
   * Gets The CSS class for this element. Corresponds to the HTML 'class' attribute.
   *
   * @return  the new styleClass value
   */
  public String getStyleClass()
  {
    if (_styleClass != null)
    {
      return _styleClass;
    }
    ValueExpression expression = getValueExpression("styleClass");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets The CSS class for this element. Corresponds to the HTML 'class' attribute.
   * 
   * @param styleClass  the new styleClass value
   */
  public void setStyleClass(String styleClass)
  {
    this._styleClass = styleClass;
  }

  // Property: dir
  private String _dir;

  /**
   * Gets The direction of text display, either 'ltr' (left-to-right) or 'rtl' (right-to-left).
   *
   * @return  the new dir value
   */
  public String getDir()
  {
    if (_dir != null)
    {
      return _dir;
    }
    ValueExpression expression = getValueExpression("dir");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets The direction of text display, either 'ltr' (left-to-right) or 'rtl' (right-to-left).
   * 
   * @param dir  the new dir value
   */
  public void setDir(String dir)
  {
    this._dir = dir;
  }

  // Property: lang
  private String _lang;

  /**
   * Gets The base language of this document.
   *
   * @return  the new lang value
   */
  public String getLang()
  {
    if (_lang != null)
    {
      return _lang;
    }
    ValueExpression expression = getValueExpression("lang");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets The base language of this document.
   * 
   * @param lang  the new lang value
   */
  public void setLang(String lang)
  {
    this._lang = lang;
  }

  // Property: title
  private String _title;

  /**
   * Gets An advisory title for this element. Often used by the user agent as a tooltip.
   *
   * @return  the new title value
   */
  public String getTitle()
  {
    if (_title != null)
    {
      return _title;
    }
    ValueExpression expression = getValueExpression("title");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets An advisory title for this element. Often used by the user agent as a tooltip.
   * 
   * @param title  the new title value
   */
  public void setTitle(String title)
  {
    this._title = title;
  }

  // Property: infoClass
  private String _infoClass;

  /**
   * Gets CSS class to be used for messages with severity "INFO".
   *
   * @return  the new infoClass value
   */
  public String getInfoClass()
  {
    if (_infoClass != null)
    {
      return _infoClass;
    }
    ValueExpression expression = getValueExpression("infoClass");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets CSS class to be used for messages with severity "INFO".
   * 
   * @param infoClass  the new infoClass value
   */
  public void setInfoClass(String infoClass)
  {
    this._infoClass = infoClass;
  }

  // Property: infoStyle
  private String _infoStyle;

  /**
   * Gets CSS style to be used for messages with severity "INFO".
   *
   * @return  the new infoStyle value
   */
  public String getInfoStyle()
  {
    if (_infoStyle != null)
    {
      return _infoStyle;
    }
    ValueExpression expression = getValueExpression("infoStyle");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets CSS style to be used for messages with severity "INFO".
   * 
   * @param infoStyle  the new infoStyle value
   */
  public void setInfoStyle(String infoStyle)
  {
    this._infoStyle = infoStyle;
  }

  // Property: warnClass
  private String _warnClass;

  /**
   * Gets CSS class to be used for messages with severity "WARN".
   *
   * @return  the new warnClass value
   */
  public String getWarnClass()
  {
    if (_warnClass != null)
    {
      return _warnClass;
    }
    ValueExpression expression = getValueExpression("warnClass");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets CSS class to be used for messages with severity "WARN".
   * 
   * @param warnClass  the new warnClass value
   */
  public void setWarnClass(String warnClass)
  {
    this._warnClass = warnClass;
  }

  // Property: warnStyle
  private String _warnStyle;

  /**
   * Gets CSS style to be used for messages with severity "WARN".
   *
   * @return  the new warnStyle value
   */
  public String getWarnStyle()
  {
    if (_warnStyle != null)
    {
      return _warnStyle;
    }
    ValueExpression expression = getValueExpression("warnStyle");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets CSS style to be used for messages with severity "WARN".
   * 
   * @param warnStyle  the new warnStyle value
   */
  public void setWarnStyle(String warnStyle)
  {
    this._warnStyle = warnStyle;
  }

  // Property: errorClass
  private String _errorClass;

  /**
   * Gets CSS class to be used for messages with severity "ERROR".
   *
   * @return  the new errorClass value
   */
  public String getErrorClass()
  {
    if (_errorClass != null)
    {
      return _errorClass;
    }
    ValueExpression expression = getValueExpression("errorClass");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets CSS class to be used for messages with severity "ERROR".
   * 
   * @param errorClass  the new errorClass value
   */
  public void setErrorClass(String errorClass)
  {
    this._errorClass = errorClass;
  }

  // Property: errorStyle
  private String _errorStyle;

  /**
   * Gets CSS style to be used for messages with severity "ERROR".
   *
   * @return  the new errorStyle value
   */
  public String getErrorStyle()
  {
    if (_errorStyle != null)
    {
      return _errorStyle;
    }
    ValueExpression expression = getValueExpression("errorStyle");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets CSS style to be used for messages with severity "ERROR".
   * 
   * @param errorStyle  the new errorStyle value
   */
  public void setErrorStyle(String errorStyle)
  {
    this._errorStyle = errorStyle;
  }

  // Property: fatalClass
  private String _fatalClass;

  /**
   * Gets CSS class to be used for messages with severity "FATAL".
   *
   * @return  the new fatalClass value
   */
  public String getFatalClass()
  {
    if (_fatalClass != null)
    {
      return _fatalClass;
    }
    ValueExpression expression = getValueExpression("fatalClass");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets CSS class to be used for messages with severity "FATAL".
   * 
   * @param fatalClass  the new fatalClass value
   */
  public void setFatalClass(String fatalClass)
  {
    this._fatalClass = fatalClass;
  }

  // Property: fatalStyle
  private String _fatalStyle;

  /**
   * Gets CSS style to be used for messages with severity "FATAL".
   *
   * @return  the new fatalStyle value
   */
  public String getFatalStyle()
  {
    if (_fatalStyle != null)
    {
      return _fatalStyle;
    }
    ValueExpression expression = getValueExpression("fatalStyle");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets CSS style to be used for messages with severity "FATAL".
   * 
   * @param fatalStyle  the new fatalStyle value
   */
  public void setFatalStyle(String fatalStyle)
  {
    this._fatalStyle = fatalStyle;
  }

  // Property: tooltip
  private boolean _tooltip;
  private boolean _tooltipSet;

  /**
   * Gets If true, the message summary will be rendered as a tooltip (i.e. HTML title attribute).
   *
   * @return  the new tooltip value
   */
  public boolean isTooltip()
  {
    if (_tooltipSet)
    {
      return _tooltip;
    }
    ValueExpression expression = getValueExpression("tooltip");
    if (expression != null)
    {
      return (Boolean)expression.getValue(getFacesContext().getELContext());
    }
    return false;
  }

  /**
   * Sets If true, the message summary will be rendered as a tooltip (i.e. HTML title attribute).
   * 
   * @param tooltip  the new tooltip value
   */
  public void setTooltip(boolean tooltip)
  {
    this._tooltip = tooltip;
    this._tooltipSet = true;
  }

  @Override
  public Object saveState(FacesContext facesContext)
  {
    Object[] values = new Object[16];
    values[0] = super.saveState(facesContext);
    values[1] = _style;
    values[2] = _styleClass;
    values[3] = _dir;
    values[4] = _lang;
    values[5] = _title;
    values[6] = _infoClass;
    values[7] = _infoStyle;
    values[8] = _warnClass;
    values[9] = _warnStyle;
    values[10] = _errorClass;
    values[11] = _errorStyle;
    values[12] = _fatalClass;
    values[13] = _fatalStyle;
    values[14] = _tooltip;
    values[15] = _tooltipSet;

    return values;
  }

  @Override
  public void restoreState(FacesContext facesContext, Object state)
  {
    Object[] values = (Object[])state;
    super.restoreState(facesContext,values[0]);
    _style = (String)values[1];
    _styleClass = (String)values[2];
    _dir = (String)values[3];
    _lang = (String)values[4];
    _title = (String)values[5];
    _infoClass = (String)values[6];
    _infoStyle = (String)values[7];
    _warnClass = (String)values[8];
    _warnStyle = (String)values[9];
    _errorClass = (String)values[10];
    _errorStyle = (String)values[11];
    _fatalClass = (String)values[12];
    _fatalStyle = (String)values[13];
    _tooltip = (Boolean)values[14];
    _tooltipSet = (Boolean)values[15];
  }

  @Override
  public String getFamily()
  {
    return COMPONENT_FAMILY;
  }
}
