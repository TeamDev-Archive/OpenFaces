// WARNING: This file was automatically generated. Do not edit it directly,
//          or you will lose your changes.

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
*/
package javax.faces.component.html;

import javax.el.ValueExpression;
import javax.faces.component.UIData;
import javax.faces.context.FacesContext;

/**
 */
public class HtmlDataTable extends UIData
{

  static public final String COMPONENT_FAMILY =
    "javax.faces.Data";
  static public final String COMPONENT_TYPE =
    "javax.faces.HtmlDataTable";

  /**
   * Construct an instance of the HtmlDataTable.
   */
  public HtmlDataTable()
  {
    setRendererType("javax.faces.Table");
  }

  // Property: columnClasses
  private String _columnClasses;

  /**
   * Gets A comma separated list of CSS class names to apply to td elements in
   *                 each column. More than one class can be applied to a column by separing the classes
   *                 with a space. I there are less classes than the number of columns, apply the same
   *                 sequence of classes to the remaining columns. If there are more classes specified
   *                 than the number of columns, ignore the last classes
   *
   * @return  the new columnClasses value
   */
  public String getColumnClasses()
  {
    if (_columnClasses != null)
    {
      return _columnClasses;
    }
    ValueExpression expression = getValueExpression("columnClasses");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets A comma separated list of CSS class names to apply to td elements in
   *                 each column. More than one class can be applied to a column by separing the classes
   *                 with a space. I there are less classes than the number of columns, apply the same
   *                 sequence of classes to the remaining columns. If there are more classes specified
   *                 than the number of columns, ignore the last classes
   * 
   * @param columnClasses  the new columnClasses value
   */
  public void setColumnClasses(String columnClasses)
  {
    this._columnClasses = columnClasses;
  }

  // Property: footerClass
  private String _footerClass;

  /**
   * Gets The CSS class to be applied to footer cells.
   *
   * @return  the new footerClass value
   */
  public String getFooterClass()
  {
    if (_footerClass != null)
    {
      return _footerClass;
    }
    ValueExpression expression = getValueExpression("footerClass");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets The CSS class to be applied to footer cells.
   * 
   * @param footerClass  the new footerClass value
   */
  public void setFooterClass(String footerClass)
  {
    this._footerClass = footerClass;
  }

  // Property: headerClass
  private String _headerClass;

  /**
   * Gets The CSS class to be applied to header cells.
   *
   * @return  the new headerClass value
   */
  public String getHeaderClass()
  {
    if (_headerClass != null)
    {
      return _headerClass;
    }
    ValueExpression expression = getValueExpression("headerClass");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets The CSS class to be applied to header cells.
   * 
   * @param headerClass  the new headerClass value
   */
  public void setHeaderClass(String headerClass)
  {
    this._headerClass = headerClass;
  }

  // Property: rowClasses
  private String _rowClasses;

  /**
   * Gets A comma separated list of CSS class names to apply to td elements in
   *                 each row. If tere are less classes than the number of rows, apply the same
   *                 sequence of classes to the remaining rows, so the pattern is repeated.
   *                 More than one class can be applied to a row by separing the classes
   *                 with a space.
   *
   * @return  the new rowClasses value
   */
  public String getRowClasses()
  {
    if (_rowClasses != null)
    {
      return _rowClasses;
    }
    ValueExpression expression = getValueExpression("rowClasses");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets A comma separated list of CSS class names to apply to td elements in
   *                 each row. If tere are less classes than the number of rows, apply the same
   *                 sequence of classes to the remaining rows, so the pattern is repeated.
   *                 More than one class can be applied to a row by separing the classes
   *                 with a space.
   * 
   * @param rowClasses  the new rowClasses value
   */
  public void setRowClasses(String rowClasses)
  {
    this._rowClasses = rowClasses;
  }

  // Property: captionClass
  private String _captionClass;

  /**
   * Gets A comma separated list of CSS class names to apply to all captions.
   *                 If tere are less classes than the number of rows, apply the same
   *                 sequence of classes to the remaining captions, so the pattern is repeated.
   *                 More than one class can be applied to a row by separing the classes
   *                 with a space.
   *
   * @return  the new captionClass value
   */
  public String getCaptionClass()
  {
    if (_captionClass != null)
    {
      return _captionClass;
    }
    ValueExpression expression = getValueExpression("captionClass");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets A comma separated list of CSS class names to apply to all captions.
   *                 If tere are less classes than the number of rows, apply the same
   *                 sequence of classes to the remaining captions, so the pattern is repeated.
   *                 More than one class can be applied to a row by separing the classes
   *                 with a space.
   * 
   * @param captionClass  the new captionClass value
   */
  public void setCaptionClass(String captionClass)
  {
    this._captionClass = captionClass;
  }

  // Property: captionStyle
  private String _captionStyle;

  /**
   * Gets The CSS class to be applied to the Caption.
   *
   * @return  the new captionStyle value
   */
  public String getCaptionStyle()
  {
    if (_captionStyle != null)
    {
      return _captionStyle;
    }
    ValueExpression expression = getValueExpression("captionStyle");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets The CSS class to be applied to the Caption.
   * 
   * @param captionStyle  the new captionStyle value
   */
  public void setCaptionStyle(String captionStyle)
  {
    this._captionStyle = captionStyle;
  }

  // Property: style
  private String _style;

  /**
   * Gets CSS styling instructions.
   *
   * @return  the new style value
   */
  public String getStyle()
  {
    if (_style != null)
    {
      return _style;
    }
    ValueExpression expression = getValueExpression("style");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets CSS styling instructions.
   * 
   * @param style  the new style value
   */
  public void setStyle(String style)
  {
    this._style = style;
  }

  // Property: styleClass
  private String _styleClass;

  /**
   * Gets The CSS class for this element. Corresponds to the HTML 'class' attribute.
   *
   * @return  the new styleClass value
   */
  public String getStyleClass()
  {
    if (_styleClass != null)
    {
      return _styleClass;
    }
    ValueExpression expression = getValueExpression("styleClass");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets The CSS class for this element. Corresponds to the HTML 'class' attribute.
   * 
   * @param styleClass  the new styleClass value
   */
  public void setStyleClass(String styleClass)
  {
    this._styleClass = styleClass;
  }

  // Property: dir
  private String _dir;

  /**
   * Gets The direction of text display, either 'ltr' (left-to-right) or 'rtl' (right-to-left).
   *
   * @return  the new dir value
   */
  public String getDir()
  {
    if (_dir != null)
    {
      return _dir;
    }
    ValueExpression expression = getValueExpression("dir");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets The direction of text display, either 'ltr' (left-to-right) or 'rtl' (right-to-left).
   * 
   * @param dir  the new dir value
   */
  public void setDir(String dir)
  {
    this._dir = dir;
  }

  // Property: lang
  private String _lang;

  /**
   * Gets The base language of this document.
   *
   * @return  the new lang value
   */
  public String getLang()
  {
    if (_lang != null)
    {
      return _lang;
    }
    ValueExpression expression = getValueExpression("lang");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets The base language of this document.
   * 
   * @param lang  the new lang value
   */
  public void setLang(String lang)
  {
    this._lang = lang;
  }

  // Property: title
  private String _title;

  /**
   * Gets An advisory title for this element. Often used by the user agent as a tooltip.
   *
   * @return  the new title value
   */
  public String getTitle()
  {
    if (_title != null)
    {
      return _title;
    }
    ValueExpression expression = getValueExpression("title");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets An advisory title for this element. Often used by the user agent as a tooltip.
   * 
   * @param title  the new title value
   */
  public void setTitle(String title)
  {
    this._title = title;
  }

  // Property: onclick
  private String _onclick;

  /**
   * Gets Script to be invoked when the element is clicked.
   *
   * @return  the new onclick value
   */
  public String getOnclick()
  {
    if (_onclick != null)
    {
      return _onclick;
    }
    ValueExpression expression = getValueExpression("onclick");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the element is clicked.
   * 
   * @param onclick  the new onclick value
   */
  public void setOnclick(String onclick)
  {
    this._onclick = onclick;
  }

  // Property: ondblclick
  private String _ondblclick;

  /**
   * Gets Script to be invoked when the element is double-clicked.
   *
   * @return  the new ondblclick value
   */
  public String getOndblclick()
  {
    if (_ondblclick != null)
    {
      return _ondblclick;
    }
    ValueExpression expression = getValueExpression("ondblclick");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the element is double-clicked.
   * 
   * @param ondblclick  the new ondblclick value
   */
  public void setOndblclick(String ondblclick)
  {
    this._ondblclick = ondblclick;
  }

  // Property: onmousedown
  private String _onmousedown;

  /**
   * Gets Script to be invoked when the pointing device is pressed over this element.
   *
   * @return  the new onmousedown value
   */
  public String getOnmousedown()
  {
    if (_onmousedown != null)
    {
      return _onmousedown;
    }
    ValueExpression expression = getValueExpression("onmousedown");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the pointing device is pressed over this element.
   * 
   * @param onmousedown  the new onmousedown value
   */
  public void setOnmousedown(String onmousedown)
  {
    this._onmousedown = onmousedown;
  }

  // Property: onmouseup
  private String _onmouseup;

  /**
   * Gets Script to be invoked when the pointing device is released over this element.
   *
   * @return  the new onmouseup value
   */
  public String getOnmouseup()
  {
    if (_onmouseup != null)
    {
      return _onmouseup;
    }
    ValueExpression expression = getValueExpression("onmouseup");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the pointing device is released over this element.
   * 
   * @param onmouseup  the new onmouseup value
   */
  public void setOnmouseup(String onmouseup)
  {
    this._onmouseup = onmouseup;
  }

  // Property: onmouseover
  private String _onmouseover;

  /**
   * Gets Script to be invoked when the pointing device is moved into this element.
   *
   * @return  the new onmouseover value
   */
  public String getOnmouseover()
  {
    if (_onmouseover != null)
    {
      return _onmouseover;
    }
    ValueExpression expression = getValueExpression("onmouseover");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the pointing device is moved into this element.
   * 
   * @param onmouseover  the new onmouseover value
   */
  public void setOnmouseover(String onmouseover)
  {
    this._onmouseover = onmouseover;
  }

  // Property: onmousemove
  private String _onmousemove;

  /**
   * Gets Script to be invoked when the pointing device is moved while it is in this element.
   *
   * @return  the new onmousemove value
   */
  public String getOnmousemove()
  {
    if (_onmousemove != null)
    {
      return _onmousemove;
    }
    ValueExpression expression = getValueExpression("onmousemove");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the pointing device is moved while it is in this element.
   * 
   * @param onmousemove  the new onmousemove value
   */
  public void setOnmousemove(String onmousemove)
  {
    this._onmousemove = onmousemove;
  }

  // Property: onmouseout
  private String _onmouseout;

  /**
   * Gets Script to be invoked when the pointing device is moves out of this element.
   *
   * @return  the new onmouseout value
   */
  public String getOnmouseout()
  {
    if (_onmouseout != null)
    {
      return _onmouseout;
    }
    ValueExpression expression = getValueExpression("onmouseout");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the pointing device is moves out of this element.
   * 
   * @param onmouseout  the new onmouseout value
   */
  public void setOnmouseout(String onmouseout)
  {
    this._onmouseout = onmouseout;
  }

  // Property: onkeypress
  private String _onkeypress;

  /**
   * Gets Script to be invoked when a key is pressed over this element.
   *
   * @return  the new onkeypress value
   */
  public String getOnkeypress()
  {
    if (_onkeypress != null)
    {
      return _onkeypress;
    }
    ValueExpression expression = getValueExpression("onkeypress");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when a key is pressed over this element.
   * 
   * @param onkeypress  the new onkeypress value
   */
  public void setOnkeypress(String onkeypress)
  {
    this._onkeypress = onkeypress;
  }

  // Property: onkeydown
  private String _onkeydown;

  /**
   * Gets Script to be invoked when a key is pressed down over this element.
   *
   * @return  the new onkeydown value
   */
  public String getOnkeydown()
  {
    if (_onkeydown != null)
    {
      return _onkeydown;
    }
    ValueExpression expression = getValueExpression("onkeydown");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when a key is pressed down over this element.
   * 
   * @param onkeydown  the new onkeydown value
   */
  public void setOnkeydown(String onkeydown)
  {
    this._onkeydown = onkeydown;
  }

  // Property: onkeyup
  private String _onkeyup;

  /**
   * Gets Script to be invoked when a key is released over this element.
   *
   * @return  the new onkeyup value
   */
  public String getOnkeyup()
  {
    if (_onkeyup != null)
    {
      return _onkeyup;
    }
    ValueExpression expression = getValueExpression("onkeyup");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when a key is released over this element.
   * 
   * @param onkeyup  the new onkeyup value
   */
  public void setOnkeyup(String onkeyup)
  {
    this._onkeyup = onkeyup;
  }

  // Property: border
  private int _border;
  private boolean _borderSet;

  /**
   * Gets Specifies the width of the border of this element, in pixels. Deprecated in HTML 4.01.
   *
   * @return  the new border value
   */
  public int getBorder()
  {
    if (_borderSet)
    {
      return _border;
    }
    ValueExpression expression = getValueExpression("border");
    if (expression != null)
    {
      return (Integer)expression.getValue(getFacesContext().getELContext());
    }
    return -2147483648;
  }

  /**
   * Sets Specifies the width of the border of this element, in pixels. Deprecated in HTML 4.01.
   * 
   * @param border  the new border value
   */
  public void setBorder(int border)
  {
    this._border = border;
    this._borderSet = true;
  }

  // Property: bgcolor
  private String _bgcolor;

  /**
   * Gets The background color of this element.
   *
   * @return  the new bgcolor value
   */
  public String getBgcolor()
  {
    if (_bgcolor != null)
    {
      return _bgcolor;
    }
    ValueExpression expression = getValueExpression("bgcolor");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets The background color of this element.
   * 
   * @param bgcolor  the new bgcolor value
   */
  public void setBgcolor(String bgcolor)
  {
    this._bgcolor = bgcolor;
  }

  // Property: cellpadding
  private String _cellpadding;

  /**
   * Gets Specifies the amount of empty space between the cell border and
   * 			its contents.  It can be either a pixel length or a percentage.
   *
   * @return  the new cellpadding value
   */
  public String getCellpadding()
  {
    if (_cellpadding != null)
    {
      return _cellpadding;
    }
    ValueExpression expression = getValueExpression("cellpadding");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Specifies the amount of empty space between the cell border and
   * 			its contents.  It can be either a pixel length or a percentage.
   * 
   * @param cellpadding  the new cellpadding value
   */
  public void setCellpadding(String cellpadding)
  {
    this._cellpadding = cellpadding;
  }

  // Property: cellspacing
  private String _cellspacing;

  /**
   * Gets Specifies the amount of space between the cells of the table.
   * 			It can be either a pixel length or a percentage of available 
   * 			space.
   *
   * @return  the new cellspacing value
   */
  public String getCellspacing()
  {
    if (_cellspacing != null)
    {
      return _cellspacing;
    }
    ValueExpression expression = getValueExpression("cellspacing");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Specifies the amount of space between the cells of the table.
   * 			It can be either a pixel length or a percentage of available 
   * 			space.
   * 
   * @param cellspacing  the new cellspacing value
   */
  public void setCellspacing(String cellspacing)
  {
    this._cellspacing = cellspacing;
  }

  // Property: frame
  private String _frame;

  /**
   * Gets Controls what part of the frame that surrounds a table is
   * 			visible.  Values include:  void, above, below, hsides, lhs, 
   * 			rhs, vsides, box, and border.
   *
   * @return  the new frame value
   */
  public String getFrame()
  {
    if (_frame != null)
    {
      return _frame;
    }
    ValueExpression expression = getValueExpression("frame");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Controls what part of the frame that surrounds a table is
   * 			visible.  Values include:  void, above, below, hsides, lhs, 
   * 			rhs, vsides, box, and border.
   * 
   * @param frame  the new frame value
   */
  public void setFrame(String frame)
  {
    this._frame = frame;
  }

  // Property: rules
  private String _rules;

  /**
   * Gets Controls how rules are rendered between cells.  Values include:
   * 			none, groups, rows, cols, and all.
   *
   * @return  the new rules value
   */
  public String getRules()
  {
    if (_rules != null)
    {
      return _rules;
    }
    ValueExpression expression = getValueExpression("rules");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Controls how rules are rendered between cells.  Values include:
   * 			none, groups, rows, cols, and all.
   * 
   * @param rules  the new rules value
   */
  public void setRules(String rules)
  {
    this._rules = rules;
  }

  // Property: summary
  private String _summary;

  /**
   * Gets Provides a summary of the contents of the table, for
   * 			accessibility purposes.
   *
   * @return  the new summary value
   */
  public String getSummary()
  {
    if (_summary != null)
    {
      return _summary;
    }
    ValueExpression expression = getValueExpression("summary");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Provides a summary of the contents of the table, for
   * 			accessibility purposes.
   * 
   * @param summary  the new summary value
   */
  public void setSummary(String summary)
  {
    this._summary = summary;
  }

  // Property: width
  private String _width;

  /**
   * Gets Specifies the desired width of the table, as a pixel length or
   * 			a percentage of available space.
   *
   * @return  the new width value
   */
  public String getWidth()
  {
    if (_width != null)
    {
      return _width;
    }
    ValueExpression expression = getValueExpression("width");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Specifies the desired width of the table, as a pixel length or
   * 			a percentage of available space.
   * 
   * @param width  the new width value
   */
  public void setWidth(String width)
  {
    this._width = width;
  }

  @Override
  public Object saveState(FacesContext facesContext)
  {
    Object[] values = new Object[31];
    values[0] = super.saveState(facesContext);
    values[1] = _columnClasses;
    values[2] = _footerClass;
    values[3] = _headerClass;
    values[4] = _rowClasses;
    values[5] = _captionClass;
    values[6] = _captionStyle;
    values[7] = _style;
    values[8] = _styleClass;
    values[9] = _dir;
    values[10] = _lang;
    values[11] = _title;
    values[12] = _onclick;
    values[13] = _ondblclick;
    values[14] = _onmousedown;
    values[15] = _onmouseup;
    values[16] = _onmouseover;
    values[17] = _onmousemove;
    values[18] = _onmouseout;
    values[19] = _onkeypress;
    values[20] = _onkeydown;
    values[21] = _onkeyup;
    values[22] = _border;
    values[23] = _borderSet;
    values[24] = _bgcolor;
    values[25] = _cellpadding;
    values[26] = _cellspacing;
    values[27] = _frame;
    values[28] = _rules;
    values[29] = _summary;
    values[30] = _width;

    return values;
  }

  @Override
  public void restoreState(FacesContext facesContext, Object state)
  {
    Object[] values = (Object[])state;
    super.restoreState(facesContext,values[0]);
    _columnClasses = (String)values[1];
    _footerClass = (String)values[2];
    _headerClass = (String)values[3];
    _rowClasses = (String)values[4];
    _captionClass = (String)values[5];
    _captionStyle = (String)values[6];
    _style = (String)values[7];
    _styleClass = (String)values[8];
    _dir = (String)values[9];
    _lang = (String)values[10];
    _title = (String)values[11];
    _onclick = (String)values[12];
    _ondblclick = (String)values[13];
    _onmousedown = (String)values[14];
    _onmouseup = (String)values[15];
    _onmouseover = (String)values[16];
    _onmousemove = (String)values[17];
    _onmouseout = (String)values[18];
    _onkeypress = (String)values[19];
    _onkeydown = (String)values[20];
    _onkeyup = (String)values[21];
    _border = (Integer)values[22];
    _borderSet = (Boolean)values[23];
    _bgcolor = (String)values[24];
    _cellpadding = (String)values[25];
    _cellspacing = (String)values[26];
    _frame = (String)values[27];
    _rules = (String)values[28];
    _summary = (String)values[29];
    _width = (String)values[30];
  }

  @Override
  public String getFamily()
  {
    return COMPONENT_FAMILY;
  }
}
