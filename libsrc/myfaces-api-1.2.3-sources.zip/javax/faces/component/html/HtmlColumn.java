// WARNING: This file was automatically generated. Do not edit it directly,
//          or you will lose your changes.

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
*/
package javax.faces.component.html;

import javax.el.ValueExpression;
import javax.faces.component.UIColumn;
import javax.faces.context.FacesContext;

/**
 */
public class HtmlColumn extends UIColumn
{

  static public final String COMPONENT_FAMILY =
    "javax.faces.Column";
  static public final String COMPONENT_TYPE =
    "javax.faces.HtmlColumn";

  /**
   * Construct an instance of the HtmlColumn.
   */
  public HtmlColumn()
  {
    setRendererType(null);
  }

  // Property: headerClass
  private String _headerClass;

  /**
   * Gets CSS class to be used for the header.
   *
   * @return  the new headerClass value
   */
  public String getHeaderClass()
  {
    if (_headerClass != null)
    {
      return _headerClass;
    }
    ValueExpression expression = getValueExpression("headerClass");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets CSS class to be used for the header.
   * 
   * @param headerClass  the new headerClass value
   */
  public void setHeaderClass(String headerClass)
  {
    this._headerClass = headerClass;
  }

  // Property: footerClass
  private String _footerClass;

  /**
   * Gets CSS class to be used for the footer.
   *
   * @return  the new footerClass value
   */
  public String getFooterClass()
  {
    if (_footerClass != null)
    {
      return _footerClass;
    }
    ValueExpression expression = getValueExpression("footerClass");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets CSS class to be used for the footer.
   * 
   * @param footerClass  the new footerClass value
   */
  public void setFooterClass(String footerClass)
  {
    this._footerClass = footerClass;
  }

  @Override
  public Object saveState(FacesContext facesContext)
  {
    Object[] values = new Object[3];
    values[0] = super.saveState(facesContext);
    values[1] = _headerClass;
    values[2] = _footerClass;

    return values;
  }

  @Override
  public void restoreState(FacesContext facesContext, Object state)
  {
    Object[] values = (Object[])state;
    super.restoreState(facesContext,values[0]);
    _headerClass = (String)values[1];
    _footerClass = (String)values[2];
  }

  @Override
  public String getFamily()
  {
    return COMPONENT_FAMILY;
  }
}
