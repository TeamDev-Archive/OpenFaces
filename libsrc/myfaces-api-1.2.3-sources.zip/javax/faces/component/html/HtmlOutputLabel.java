// WARNING: This file was automatically generated. Do not edit it directly,
//          or you will lose your changes.

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
*/
package javax.faces.component.html;

import javax.el.ValueExpression;
import javax.faces.component.UIOutput;
import javax.faces.context.FacesContext;

/**
 */
public class HtmlOutputLabel extends UIOutput
{

  static public final String COMPONENT_FAMILY =
    "javax.faces.Output";
  static public final String COMPONENT_TYPE =
    "javax.faces.HtmlOutputLabel";

  /**
   * Construct an instance of the HtmlOutputLabel.
   */
  public HtmlOutputLabel()
  {
    setRendererType("javax.faces.Label");
  }

  // Property: style
  private String _style;

  /**
   * Gets CSS styling instructions.
   *
   * @return  the new style value
   */
  public String getStyle()
  {
    if (_style != null)
    {
      return _style;
    }
    ValueExpression expression = getValueExpression("style");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets CSS styling instructions.
   * 
   * @param style  the new style value
   */
  public void setStyle(String style)
  {
    this._style = style;
  }

  // Property: styleClass
  private String _styleClass;

  /**
   * Gets The CSS class for this element. Corresponds to the HTML 'class' attribute.
   *
   * @return  the new styleClass value
   */
  public String getStyleClass()
  {
    if (_styleClass != null)
    {
      return _styleClass;
    }
    ValueExpression expression = getValueExpression("styleClass");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets The CSS class for this element. Corresponds to the HTML 'class' attribute.
   * 
   * @param styleClass  the new styleClass value
   */
  public void setStyleClass(String styleClass)
  {
    this._styleClass = styleClass;
  }

  // Property: dir
  private String _dir;

  /**
   * Gets The direction of text display, either 'ltr' (left-to-right) or 'rtl' (right-to-left).
   *
   * @return  the new dir value
   */
  public String getDir()
  {
    if (_dir != null)
    {
      return _dir;
    }
    ValueExpression expression = getValueExpression("dir");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets The direction of text display, either 'ltr' (left-to-right) or 'rtl' (right-to-left).
   * 
   * @param dir  the new dir value
   */
  public void setDir(String dir)
  {
    this._dir = dir;
  }

  // Property: lang
  private String _lang;

  /**
   * Gets The base language of this document.
   *
   * @return  the new lang value
   */
  public String getLang()
  {
    if (_lang != null)
    {
      return _lang;
    }
    ValueExpression expression = getValueExpression("lang");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets The base language of this document.
   * 
   * @param lang  the new lang value
   */
  public void setLang(String lang)
  {
    this._lang = lang;
  }

  // Property: title
  private String _title;

  /**
   * Gets An advisory title for this element. Often used by the user agent as a tooltip.
   *
   * @return  the new title value
   */
  public String getTitle()
  {
    if (_title != null)
    {
      return _title;
    }
    ValueExpression expression = getValueExpression("title");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets An advisory title for this element. Often used by the user agent as a tooltip.
   * 
   * @param title  the new title value
   */
  public void setTitle(String title)
  {
    this._title = title;
  }

  // Property: onclick
  private String _onclick;

  /**
   * Gets Script to be invoked when the element is clicked.
   *
   * @return  the new onclick value
   */
  public String getOnclick()
  {
    if (_onclick != null)
    {
      return _onclick;
    }
    ValueExpression expression = getValueExpression("onclick");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the element is clicked.
   * 
   * @param onclick  the new onclick value
   */
  public void setOnclick(String onclick)
  {
    this._onclick = onclick;
  }

  // Property: ondblclick
  private String _ondblclick;

  /**
   * Gets Script to be invoked when the element is double-clicked.
   *
   * @return  the new ondblclick value
   */
  public String getOndblclick()
  {
    if (_ondblclick != null)
    {
      return _ondblclick;
    }
    ValueExpression expression = getValueExpression("ondblclick");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the element is double-clicked.
   * 
   * @param ondblclick  the new ondblclick value
   */
  public void setOndblclick(String ondblclick)
  {
    this._ondblclick = ondblclick;
  }

  // Property: onmousedown
  private String _onmousedown;

  /**
   * Gets Script to be invoked when the pointing device is pressed over this element.
   *
   * @return  the new onmousedown value
   */
  public String getOnmousedown()
  {
    if (_onmousedown != null)
    {
      return _onmousedown;
    }
    ValueExpression expression = getValueExpression("onmousedown");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the pointing device is pressed over this element.
   * 
   * @param onmousedown  the new onmousedown value
   */
  public void setOnmousedown(String onmousedown)
  {
    this._onmousedown = onmousedown;
  }

  // Property: onmouseup
  private String _onmouseup;

  /**
   * Gets Script to be invoked when the pointing device is released over this element.
   *
   * @return  the new onmouseup value
   */
  public String getOnmouseup()
  {
    if (_onmouseup != null)
    {
      return _onmouseup;
    }
    ValueExpression expression = getValueExpression("onmouseup");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the pointing device is released over this element.
   * 
   * @param onmouseup  the new onmouseup value
   */
  public void setOnmouseup(String onmouseup)
  {
    this._onmouseup = onmouseup;
  }

  // Property: onmouseover
  private String _onmouseover;

  /**
   * Gets Script to be invoked when the pointing device is moved into this element.
   *
   * @return  the new onmouseover value
   */
  public String getOnmouseover()
  {
    if (_onmouseover != null)
    {
      return _onmouseover;
    }
    ValueExpression expression = getValueExpression("onmouseover");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the pointing device is moved into this element.
   * 
   * @param onmouseover  the new onmouseover value
   */
  public void setOnmouseover(String onmouseover)
  {
    this._onmouseover = onmouseover;
  }

  // Property: onmousemove
  private String _onmousemove;

  /**
   * Gets Script to be invoked when the pointing device is moved while it is in this element.
   *
   * @return  the new onmousemove value
   */
  public String getOnmousemove()
  {
    if (_onmousemove != null)
    {
      return _onmousemove;
    }
    ValueExpression expression = getValueExpression("onmousemove");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the pointing device is moved while it is in this element.
   * 
   * @param onmousemove  the new onmousemove value
   */
  public void setOnmousemove(String onmousemove)
  {
    this._onmousemove = onmousemove;
  }

  // Property: onmouseout
  private String _onmouseout;

  /**
   * Gets Script to be invoked when the pointing device is moves out of this element.
   *
   * @return  the new onmouseout value
   */
  public String getOnmouseout()
  {
    if (_onmouseout != null)
    {
      return _onmouseout;
    }
    ValueExpression expression = getValueExpression("onmouseout");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when the pointing device is moves out of this element.
   * 
   * @param onmouseout  the new onmouseout value
   */
  public void setOnmouseout(String onmouseout)
  {
    this._onmouseout = onmouseout;
  }

  // Property: onkeypress
  private String _onkeypress;

  /**
   * Gets Script to be invoked when a key is pressed over this element.
   *
   * @return  the new onkeypress value
   */
  public String getOnkeypress()
  {
    if (_onkeypress != null)
    {
      return _onkeypress;
    }
    ValueExpression expression = getValueExpression("onkeypress");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when a key is pressed over this element.
   * 
   * @param onkeypress  the new onkeypress value
   */
  public void setOnkeypress(String onkeypress)
  {
    this._onkeypress = onkeypress;
  }

  // Property: onkeydown
  private String _onkeydown;

  /**
   * Gets Script to be invoked when a key is pressed down over this element.
   *
   * @return  the new onkeydown value
   */
  public String getOnkeydown()
  {
    if (_onkeydown != null)
    {
      return _onkeydown;
    }
    ValueExpression expression = getValueExpression("onkeydown");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when a key is pressed down over this element.
   * 
   * @param onkeydown  the new onkeydown value
   */
  public void setOnkeydown(String onkeydown)
  {
    this._onkeydown = onkeydown;
  }

  // Property: onkeyup
  private String _onkeyup;

  /**
   * Gets Script to be invoked when a key is released over this element.
   *
   * @return  the new onkeyup value
   */
  public String getOnkeyup()
  {
    if (_onkeyup != null)
    {
      return _onkeyup;
    }
    ValueExpression expression = getValueExpression("onkeyup");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Script to be invoked when a key is released over this element.
   * 
   * @param onkeyup  the new onkeyup value
   */
  public void setOnkeyup(String onkeyup)
  {
    this._onkeyup = onkeyup;
  }

  // Property: onblur
  private String _onblur;

  /**
   * Gets Specifies a script to be invoked when the element loses focus.
   *
   * @return  the new onblur value
   */
  public String getOnblur()
  {
    if (_onblur != null)
    {
      return _onblur;
    }
    ValueExpression expression = getValueExpression("onblur");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Specifies a script to be invoked when the element loses focus.
   * 
   * @param onblur  the new onblur value
   */
  public void setOnblur(String onblur)
  {
    this._onblur = onblur;
  }

  // Property: onfocus
  private String _onfocus;

  /**
   * Gets Specifies a script to be invoked when the element receives focus.
   *
   * @return  the new onfocus value
   */
  public String getOnfocus()
  {
    if (_onfocus != null)
    {
      return _onfocus;
    }
    ValueExpression expression = getValueExpression("onfocus");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Specifies a script to be invoked when the element receives focus.
   * 
   * @param onfocus  the new onfocus value
   */
  public void setOnfocus(String onfocus)
  {
    this._onfocus = onfocus;
  }

  // Property: escape
  private boolean _escape;
  private boolean _escapeSet;

  /**
   * Gets Indicates whether rendered markup should be escaped. Default: true
   *
   * @return  the new escape value
   */
  public boolean isEscape()
  {
    if (_escapeSet)
    {
      return _escape;
    }
    ValueExpression expression = getValueExpression("escape");
    if (expression != null)
    {
      return (Boolean)expression.getValue(getFacesContext().getELContext());
    }
    return true;
  }

  /**
   * Sets Indicates whether rendered markup should be escaped. Default: true
   * 
   * @param escape  the new escape value
   */
  public void setEscape(boolean escape)
  {
    this._escape = escape;
    this._escapeSet = true;
  }

  // Property: accesskey
  private String _accesskey;

  /**
   * Gets Sets the access key for this element.
   *
   * @return  the new accesskey value
   */
  public String getAccesskey()
  {
    if (_accesskey != null)
    {
      return _accesskey;
    }
    ValueExpression expression = getValueExpression("accesskey");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Sets the access key for this element.
   * 
   * @param accesskey  the new accesskey value
   */
  public void setAccesskey(String accesskey)
  {
    this._accesskey = accesskey;
  }

  // Property: tabindex
  private String _tabindex;

  /**
   * Gets Specifies the position of this element within the tab order of the document.
   *
   * @return  the new tabindex value
   */
  public String getTabindex()
  {
    if (_tabindex != null)
    {
      return _tabindex;
    }
    ValueExpression expression = getValueExpression("tabindex");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Specifies the position of this element within the tab order of the document.
   * 
   * @param tabindex  the new tabindex value
   */
  public void setTabindex(String tabindex)
  {
    this._tabindex = tabindex;
  }

  // Property: for
  private String _for;

  /**
   * Gets Client ID the label should be displayed for.
   *
   * @return  the new for value
   */
  public String getFor()
  {
    if (_for != null)
    {
      return _for;
    }
    ValueExpression expression = getValueExpression("for");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets Client ID the label should be displayed for.
   * 
   * @param forParam  the new for value
   */
  public void setFor(String forParam)
  {
    this._for = forParam;
  }

  @Override
  public Object saveState(FacesContext facesContext)
  {
    Object[] values = new Object[23];
    values[0] = super.saveState(facesContext);
    values[1] = _style;
    values[2] = _styleClass;
    values[3] = _dir;
    values[4] = _lang;
    values[5] = _title;
    values[6] = _onclick;
    values[7] = _ondblclick;
    values[8] = _onmousedown;
    values[9] = _onmouseup;
    values[10] = _onmouseover;
    values[11] = _onmousemove;
    values[12] = _onmouseout;
    values[13] = _onkeypress;
    values[14] = _onkeydown;
    values[15] = _onkeyup;
    values[16] = _onblur;
    values[17] = _onfocus;
    values[18] = _escape;
    values[19] = _escapeSet;
    values[20] = _accesskey;
    values[21] = _tabindex;
    values[22] = _for;

    return values;
  }

  @Override
  public void restoreState(FacesContext facesContext, Object state)
  {
    Object[] values = (Object[])state;
    super.restoreState(facesContext,values[0]);
    _style = (String)values[1];
    _styleClass = (String)values[2];
    _dir = (String)values[3];
    _lang = (String)values[4];
    _title = (String)values[5];
    _onclick = (String)values[6];
    _ondblclick = (String)values[7];
    _onmousedown = (String)values[8];
    _onmouseup = (String)values[9];
    _onmouseover = (String)values[10];
    _onmousemove = (String)values[11];
    _onmouseout = (String)values[12];
    _onkeypress = (String)values[13];
    _onkeydown = (String)values[14];
    _onkeyup = (String)values[15];
    _onblur = (String)values[16];
    _onfocus = (String)values[17];
    _escape = (Boolean)values[18];
    _escapeSet = (Boolean)values[19];
    _accesskey = (String)values[20];
    _tabindex = (String)values[21];
    _for = (String)values[22];
  }

  @Override
  public String getFamily()
  {
    return COMPONENT_FAMILY;
  }
}
