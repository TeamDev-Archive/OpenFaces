// WARNING: This file was automatically generated. Do not edit it directly,
//          or you will lose your changes.

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
*/
package javax.faces.component;

import javax.el.ValueExpression;
import javax.faces.context.FacesContext;

/**
 */
public class UIMessages extends UIComponentBase
{

  static public final String COMPONENT_FAMILY =
    "javax.faces.Messages";
  static public final String COMPONENT_TYPE =
    "javax.faces.Messages";

  /**
   * Construct an instance of the UIMessages.
   */
  public UIMessages()
  {
    setRendererType("javax.faces.Messages");
  }

  // Property: globalOnly
  private boolean _globalOnly;
  private boolean _globalOnlySet;

  /**
   * Gets Specifies whether only messages (FacesMessage objects) not associated with a
   *               specific component should be displayed, ie whether messages should be ignored
   *               if they are attached to a particular component. Defaults to false.
   *
   * @return  the new globalOnly value
   */
  public boolean isGlobalOnly()
  {
    if (_globalOnlySet)
    {
      return _globalOnly;
    }
    ValueExpression expression = getValueExpression("globalOnly");
    if (expression != null)
    {
      return (Boolean)expression.getValue(getFacesContext().getELContext());
    }
    return false;
  }

  /**
   * Sets Specifies whether only messages (FacesMessage objects) not associated with a
   *               specific component should be displayed, ie whether messages should be ignored
   *               if they are attached to a particular component. Defaults to false.
   * 
   * @param globalOnly  the new globalOnly value
   */
  public void setGlobalOnly(boolean globalOnly)
  {
    this._globalOnly = globalOnly;
    this._globalOnlySet = true;
  }

  // Property: showDetail
  private boolean _showDetail;
  private boolean _showDetailSet;

  /**
   * Gets Specifies whether the detailed information from the message should be shown. Defaults to false.
   *
   * @return  the new showDetail value
   */
  public boolean isShowDetail()
  {
    if (_showDetailSet)
    {
      return _showDetail;
    }
    ValueExpression expression = getValueExpression("showDetail");
    if (expression != null)
    {
      return (Boolean)expression.getValue(getFacesContext().getELContext());
    }
    return false;
  }

  /**
   * Sets Specifies whether the detailed information from the message should be shown. Defaults to false.
   * 
   * @param showDetail  the new showDetail value
   */
  public void setShowDetail(boolean showDetail)
  {
    this._showDetail = showDetail;
    this._showDetailSet = true;
  }

  // Property: showSummary
  private boolean _showSummary;
  private boolean _showSummarySet;

  /**
   * Gets Specifies whether the summary information from the message should be shown. Defaults to true.
   *
   * @return  the new showSummary value
   */
  public boolean isShowSummary()
  {
    if (_showSummarySet)
    {
      return _showSummary;
    }
    ValueExpression expression = getValueExpression("showSummary");
    if (expression != null)
    {
      return (Boolean)expression.getValue(getFacesContext().getELContext());
    }
    return true;
  }

  /**
   * Sets Specifies whether the summary information from the message should be shown. Defaults to true.
   * 
   * @param showSummary  the new showSummary value
   */
  public void setShowSummary(boolean showSummary)
  {
    this._showSummary = showSummary;
    this._showSummarySet = true;
  }

  @Override
  public Object saveState(FacesContext facesContext)
  {
    Object[] values = new Object[7];
    values[0] = super.saveState(facesContext);
    values[1] = _globalOnly;
    values[2] = _globalOnlySet;
    values[3] = _showDetail;
    values[4] = _showDetailSet;
    values[5] = _showSummary;
    values[6] = _showSummarySet;

    return values;
  }

  @Override
  public void restoreState(FacesContext facesContext, Object state)
  {
    Object[] values = (Object[])state;
    super.restoreState(facesContext,values[0]);
    _globalOnly = (Boolean)values[1];
    _globalOnlySet = (Boolean)values[2];
    _showDetail = (Boolean)values[3];
    _showDetailSet = (Boolean)values[4];
    _showSummary = (Boolean)values[5];
    _showSummarySet = (Boolean)values[6];
  }

  @Override
  public String getFamily()
  {
    return COMPONENT_FAMILY;
  }
}
