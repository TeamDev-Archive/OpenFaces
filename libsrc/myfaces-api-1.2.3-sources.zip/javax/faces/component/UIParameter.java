// WARNING: This file was automatically generated. Do not edit it directly,
//          or you will lose your changes.

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
*/
package javax.faces.component;

import javax.el.ValueExpression;
import javax.faces.context.FacesContext;

/**
 */
public class UIParameter extends UIComponentBase
{

  static public final String COMPONENT_FAMILY =
    "javax.faces.Parameter";
  static public final String COMPONENT_TYPE =
    "javax.faces.Parameter";

  /**
   * Construct an instance of the UIParameter.
   */
  public UIParameter()
  {
    setRendererType(null);
  }

  // Property: value
  private Object _value;

  /**
   * Gets The value of this component.
   *
   * @return  the new value value
   */
  public Object getValue()
  {
    if (_value != null)
    {
      return _value;
    }
    ValueExpression expression = getValueExpression("value");
    if (expression != null)
    {
      return expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets The value of this component.
   * 
   * @param value  the new value value
   */
  public void setValue(Object value)
  {
    this._value = value;
  }

  // Property: name
  private String _name;

  /**
   * Gets The name under which the value is stored.
   *
   * @return  the new name value
   */
  public String getName()
  {
    if (_name != null)
    {
      return _name;
    }
    ValueExpression expression = getValueExpression("name");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets The name under which the value is stored.
   * 
   * @param name  the new name value
   */
  public void setName(String name)
  {
    this._name = name;
  }

  @Override
  public Object saveState(FacesContext facesContext)
  {
    Object[] values = new Object[3];
    values[0] = super.saveState(facesContext);
    values[1] = _value;
    values[2] = _name;

    return values;
  }

  @Override
  public void restoreState(FacesContext facesContext, Object state)
  {
    Object[] values = (Object[])state;
    super.restoreState(facesContext,values[0]);
    _value = values[1];
    _name = (String)values[2];
  }

  @Override
  public String getFamily()
  {
    return COMPONENT_FAMILY;
  }
}
