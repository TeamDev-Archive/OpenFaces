// WARNING: This file was automatically generated. Do not edit it directly,
//          or you will lose your changes.

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
*/
package javax.faces.component;

import javax.el.ValueExpression;
import javax.faces.context.FacesContext;

/**
 */
public class UIMessage extends UIComponentBase
{

  static public final String COMPONENT_FAMILY =
    "javax.faces.Message";
  static public final String COMPONENT_TYPE =
    "javax.faces.Message";

  /**
   * Construct an instance of the UIMessage.
   */
  public UIMessage()
  {
    setRendererType("javax.faces.Message");
  }

  // Property: for
  private String _for;

  /**
   * Gets The ID of the component whose attached FacesMessage object (if present) should be
   *               diplayed by this component.
   * <p>
   * This is a required property on the component.
   * </p>
   *
   * @return  the new for value
   */
  public String getFor()
  {
    if (_for != null)
    {
      return _for;
    }
    ValueExpression expression = getValueExpression("for");
    if (expression != null)
    {
      return (String)expression.getValue(getFacesContext().getELContext());
    }
    return null;
  }

  /**
   * Sets The ID of the component whose attached FacesMessage object (if present) should be
   *               diplayed by this component.
   * <p>
   * This is a required property on the component.
   * 
   * @param forParam  the new for value
   */
  public void setFor(String forParam)
  {
    this._for = forParam;
  }

  // Property: showDetail
  private boolean _showDetail;
  private boolean _showDetailSet;

  /**
   * Gets Specifies whether the detailed information from the message should be shown. Default to false.
   *
   * @return  the new showDetail value
   */
  public boolean isShowDetail()
  {
    if (_showDetailSet)
    {
      return _showDetail;
    }
    ValueExpression expression = getValueExpression("showDetail");
    if (expression != null)
    {
      return (Boolean)expression.getValue(getFacesContext().getELContext());
    }
    return true;
  }

  /**
   * Sets Specifies whether the detailed information from the message should be shown. Default to false.
   * 
   * @param showDetail  the new showDetail value
   */
  public void setShowDetail(boolean showDetail)
  {
    this._showDetail = showDetail;
    this._showDetailSet = true;
  }

  // Property: showSummary
  private boolean _showSummary;
  private boolean _showSummarySet;

  /**
   * Gets Specifies whether the summary information from the message should be shown. Defaults to true.
   *
   * @return  the new showSummary value
   */
  public boolean isShowSummary()
  {
    if (_showSummarySet)
    {
      return _showSummary;
    }
    ValueExpression expression = getValueExpression("showSummary");
    if (expression != null)
    {
      return (Boolean)expression.getValue(getFacesContext().getELContext());
    }
    return false;
  }

  /**
   * Sets Specifies whether the summary information from the message should be shown. Defaults to true.
   * 
   * @param showSummary  the new showSummary value
   */
  public void setShowSummary(boolean showSummary)
  {
    this._showSummary = showSummary;
    this._showSummarySet = true;
  }

  @Override
  public Object saveState(FacesContext facesContext)
  {
    Object[] values = new Object[6];
    values[0] = super.saveState(facesContext);
    values[1] = _for;
    values[2] = _showDetail;
    values[3] = _showDetailSet;
    values[4] = _showSummary;
    values[5] = _showSummarySet;

    return values;
  }

  @Override
  public void restoreState(FacesContext facesContext, Object state)
  {
    Object[] values = (Object[])state;
    super.restoreState(facesContext,values[0]);
    _for = (String)values[1];
    _showDetail = (Boolean)values[2];
    _showDetailSet = (Boolean)values[3];
    _showSummary = (Boolean)values[4];
    _showSummarySet = (Boolean)values[5];
  }

  @Override
  public String getFamily()
  {
    return COMPONENT_FAMILY;
  }
}
