/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 * 
 *  http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package org.apache.myfaces.custom.navmenu.htmlnavmenu;

import javax.el.ValueExpression;
import javax.faces.context.FacesContext;
import javax.faces.component.PartialStateHolder;
import javax.faces.component.StateHolder;
import org.apache.myfaces.component.AttachedDeltaWrapper;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;


// Generated from class org.apache.myfaces.custom.navmenu.htmlnavmenu.AbstractHtmlCommandNavigationItem.
//
// WARNING: This file was automatically generated. Do not edit it directly,
//          or you will lose your changes.
public class HtmlCommandNavigationItem extends org.apache.myfaces.custom.navmenu.htmlnavmenu.AbstractHtmlCommandNavigationItem
{

    static public final String COMPONENT_FAMILY =
        "javax.faces.Command";
    static public final String COMPONENT_TYPE =
        "org.apache.myfaces.HtmlCommandNavigationItem";
    static public final String DEFAULT_RENDERER_TYPE = 
        "org.apache.myfaces.NavigationMenu";


    public HtmlCommandNavigationItem()
    {
        setRendererType("org.apache.myfaces.NavigationMenu");
    }

    public String getFamily()
    {
        return COMPONENT_FAMILY;
    }



    
    // Property: open
    protected boolean isSetOpen()
    {
        return getStateHelper().get(PropertyKeys.open) != null;
    }
    final protected boolean isLocalOpen()
    {
        return (Boolean) getStateHelper().get(PropertyKeys.open);
    }
     
    public boolean isOpen()
    {
        return (Boolean) getStateHelper().eval(PropertyKeys.open, false);
    }
    
    public void setOpen(boolean open)
    {
        getStateHelper().put(PropertyKeys.open, open ); 
    }    
    // Property: active
    protected boolean isSetActive()
    {
        return getStateHelper().get(PropertyKeys.active) != null;
    }
    final protected boolean isLocalActive()
    {
        return (Boolean) getStateHelper().get(PropertyKeys.active);
    }
     
    public boolean isActive()
    {
        return (Boolean) getStateHelper().eval(PropertyKeys.active, false);
    }
    
    public void setActive(boolean active)
    {
        getStateHelper().put(PropertyKeys.active, active ); 
    }    
    // Property: activeOnViewIds
    public String getActiveOnViewIds()
    {
        return (String) getStateHelper().eval(PropertyKeys.activeOnViewIds);
    }
    
    public void setActiveOnViewIds(String activeOnViewIds)
    {
        getStateHelper().put(PropertyKeys.activeOnViewIds, activeOnViewIds ); 
    }    
    // Property: externalLink
    public String getExternalLink()
    {
        return (String) getStateHelper().eval(PropertyKeys.externalLink);
    }
    
    public void setExternalLink(String externalLink)
    {
        getStateHelper().put(PropertyKeys.externalLink, externalLink ); 
    }    

    protected enum PropertyKeys
    {
         open
        , active
        , activeOnViewIds
        , externalLink
    }

 }
