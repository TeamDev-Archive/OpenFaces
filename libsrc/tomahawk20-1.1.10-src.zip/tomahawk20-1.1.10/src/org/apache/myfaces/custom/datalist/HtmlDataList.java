/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 * 
 *  http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package org.apache.myfaces.custom.datalist;

import javax.el.ValueExpression;
import javax.faces.context.FacesContext;
import javax.faces.component.PartialStateHolder;
import javax.faces.component.StateHolder;
import org.apache.myfaces.component.AttachedDeltaWrapper;
import javax.faces.component.UIComponent;


// Generated from class org.apache.myfaces.custom.datalist.AbstractHtmlDataList.
//
// WARNING: This file was automatically generated. Do not edit it directly,
//          or you will lose your changes.
public class HtmlDataList extends org.apache.myfaces.custom.datalist.AbstractHtmlDataList
{

    static public final String COMPONENT_FAMILY =
        "javax.faces.Data";
    static public final String COMPONENT_TYPE =
        "org.apache.myfaces.HtmlDataList";
    static public final String DEFAULT_RENDERER_TYPE = 
        "org.apache.myfaces.List";


    public HtmlDataList()
    {
        setRendererType("org.apache.myfaces.List");
    }

    public String getFamily()
    {
        return COMPONENT_FAMILY;
    }



    
    // Property: rowCountVar
    public String getRowCountVar()
    {
        return (String) getStateHelper().eval(PropertyKeys.rowCountVar);
    }
    
    public void setRowCountVar(String rowCountVar)
    {
        getStateHelper().put(PropertyKeys.rowCountVar, rowCountVar ); 
    }    
    // Property: rowIndexVar
    public String getRowIndexVar()
    {
        return (String) getStateHelper().eval(PropertyKeys.rowIndexVar);
    }
    
    public void setRowIndexVar(String rowIndexVar)
    {
        getStateHelper().put(PropertyKeys.rowIndexVar, rowIndexVar ); 
    }    
    // Property: layout
    public String getLayout()
    {
        return (String) getStateHelper().eval(PropertyKeys.layout);
    }
    
    public void setLayout(String layout)
    {
        getStateHelper().put(PropertyKeys.layout, layout ); 
    }    
    // Property: itemStyleClass
    public String getItemStyleClass()
    {
        return (String) getStateHelper().eval(PropertyKeys.itemStyleClass);
    }
    
    public void setItemStyleClass(String itemStyleClass)
    {
        getStateHelper().put(PropertyKeys.itemStyleClass, itemStyleClass ); 
    }    
    // Property: itemOnClick
    public String getItemOnClick()
    {
        return (String) getStateHelper().eval(PropertyKeys.itemOnClick);
    }
    
    public void setItemOnClick(String itemOnClick)
    {
        getStateHelper().put(PropertyKeys.itemOnClick, itemOnClick ); 
    }    
    // Property: enabledOnUserRole
    public String getEnabledOnUserRole()
    {
        return (String) getStateHelper().eval(PropertyKeys.enabledOnUserRole);
    }
    
    public void setEnabledOnUserRole(String enabledOnUserRole)
    {
        getStateHelper().put(PropertyKeys.enabledOnUserRole, enabledOnUserRole ); 
    }    
    // Property: visibleOnUserRole
    public String getVisibleOnUserRole()
    {
        return (String) getStateHelper().eval(PropertyKeys.visibleOnUserRole);
    }
    
    public void setVisibleOnUserRole(String visibleOnUserRole)
    {
        getStateHelper().put(PropertyKeys.visibleOnUserRole, visibleOnUserRole ); 
    }    

    protected enum PropertyKeys
    {
         rowCountVar
        , rowIndexVar
        , layout
        , itemStyleClass
        , itemOnClick
        , enabledOnUserRole
        , visibleOnUserRole
    }

 }
