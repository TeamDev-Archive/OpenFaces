package org.apache.myfaces.trinidad.render;

import java.io.IOException;
import javax.faces.context.FacesContext;

public interface ExtendedRenderKitService {

	public void addScript(FacesContext context, String script);

	public void encodeScripts(FacesContext context) throws IOException;

	public boolean shortCircuitRenderView(FacesContext context) throws IOException;

	public boolean isStateless(FacesContext context);

	public void encodeBegin(FacesContext context) throws IOException;

	public void encodeEnd(FacesContext context) throws IOException;

	public void encodeFinally(FacesContext context);
}
