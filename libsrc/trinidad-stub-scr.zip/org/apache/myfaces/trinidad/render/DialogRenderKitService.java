package org.apache.myfaces.trinidad.render;

import java.util.Map;
import javax.faces.component.UIComponent;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;

/**
 * @author Vladimir Kurganov
 */
public interface DialogRenderKitService {
	public boolean launchDialog(FacesContext context, UIViewRoot targetRoot, UIComponent source, Map processParameters, boolean useWindow, Map windowProperties);

	public boolean returnFromDialog(FacesContext context, Object returnValue);

	public boolean isReturning(FacesContext context, UIComponent source);
}

