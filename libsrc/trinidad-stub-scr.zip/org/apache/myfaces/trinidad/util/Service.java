package org.apache.myfaces.trinidad.util;

public class Service {
	static public interface Provider {
		public Object getService(Class serviceClass);
	}
}
