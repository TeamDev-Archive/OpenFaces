/*
 * Copyright 2004 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.myfaces.application;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.concurrent.ConcurrentHashMap;

import javax.el.CompositeELResolver;
import javax.el.ELContext;
import javax.el.ELContextListener;
import javax.el.ELException;
import javax.el.ELResolver;
import javax.el.ExpressionFactory;
import javax.el.MethodExpression;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.application.Application;
import javax.faces.application.NavigationHandler;
import javax.faces.application.StateManager;
import javax.faces.application.ViewHandler;
import javax.faces.component.UIComponent;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.el.MethodBinding;
import javax.faces.el.PropertyResolver;
import javax.faces.el.ReferenceSyntaxException;
import javax.faces.el.ValueBinding;
import javax.faces.el.VariableResolver;
import javax.faces.event.ActionListener;
import javax.faces.validator.Validator;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.myfaces.application.jsp.JspStateManagerImpl;
import org.apache.myfaces.application.jsp.JspViewHandlerImpl;
import org.apache.myfaces.config.RuntimeConfig;
import org.apache.myfaces.config.impl.digester.elements.Property;
import org.apache.myfaces.config.impl.digester.elements.ResourceBundle;
import org.apache.myfaces.el.PropertyResolverImpl;
import org.apache.myfaces.el.VariableResolverToApplicationELResolverAdapter;
import org.apache.myfaces.el.convert.MethodExpressionToMethodBinding;
import org.apache.myfaces.el.convert.ValueBindingToValueExpression;
import org.apache.myfaces.el.convert.ValueExpressionToValueBinding;
import org.apache.myfaces.el.unified.ELResolverBuilder;
import org.apache.myfaces.el.unified.ResolverBuilderForFaces;
import org.apache.myfaces.el.unified.resolver.FacesCompositeELResolver;
import org.apache.myfaces.el.unified.resolver.FacesCompositeELResolver.Scope;
import org.apache.myfaces.shared_impl.util.ClassUtils;

/**
 * DOCUMENT ME!
 *
 * @author Manfred Geiler (latest modification by $Author: lu4242 $)
 * @author Anton Koinov
 * @author Thomas Spiegl
 * @author Stan Silvert
 * @version $Revision: 641511 $ $Date: 2008-03-26 14:41:56 -0500 (Wed, 26 Mar 2008) $
 */
@SuppressWarnings("deprecation")
public class ApplicationImpl extends Application
{
    private static final Log log = LogFactory.getLog(ApplicationImpl.class);

    private final static VariableResolver VARIABLERESOLVER = new VariableResolverToApplicationELResolverAdapter();

    private final static PropertyResolver PROPERTYRESOLVER = new PropertyResolverImpl();

    // recives the runtime config instance during initializing
    private final static ThreadLocal<RuntimeConfig> initializingRuntimeConfig = new ThreadLocal<RuntimeConfig>();

    // ~ Instance fields
    // ----------------------------------------------------------------------------

    private Collection<Locale> _supportedLocales = Collections.emptySet();
    private Locale _defaultLocale;
    private String _messageBundle;

    private ViewHandler _viewHandler;
    private NavigationHandler _navigationHandler;
    private ActionListener _actionListener;
    private String _defaultRenderKitId;
    private StateManager _stateManager;

    private ArrayList<ELContextListener> _elContextListeners;

    // components, converters, and validators can be added at runtime--must
    // synchronize, uses ConcurrentHashMap to allow concurrent read of map
    private final Map<String, Class> _converterIdToClassMap = new ConcurrentHashMap<String, Class>();
    private final Map<Class, String> _converterClassNameToClassMap = new ConcurrentHashMap<Class, String>();
    private final Map<String, org.apache.myfaces.config.impl.digester.elements.Converter> _converterClassNameToConfigurationMap = new ConcurrentHashMap<String, org.apache.myfaces.config.impl.digester.elements.Converter>();
    private final Map<String, Class> _componentClassMap = new ConcurrentHashMap<String, Class>();
    private final Map<String, Class> _validatorClassMap = new ConcurrentHashMap<String, Class>();

    private final RuntimeConfig _runtimeConfig;

    private ELResolver elResolver;

    private ELResolverBuilder resolverBuilderForFaces;

    // ~ Constructors
    // -------------------------------------------------------------------------------

    public ApplicationImpl()
    {
        this(internalGetRuntimeConfig());
    }

    private static RuntimeConfig internalGetRuntimeConfig()
    {
        if (initializingRuntimeConfig.get() == null)
        {
            //It may happen that the current thread value
            //for initializingRuntimeConfig is not set 
            //(note that this value is final, so it just 
            //allow set only once per thread).
            //So the better for this case is try to get
            //the value using RuntimeConfig.getCurrentInstance()
            //instead throw an IllegalStateException (only fails if
            //the constructor is called before setInitializingRuntimeConfig).
            //From other point of view, AbstractFacesInitializer do 
            //the same as below, so there is not problem if
            //we do this here and this is the best place to do
            //this.
            //log.info("initializingRuntimeConfig.get() == null, so loading from ExternalContext");
            ApplicationImpl.setInitializingRuntimeConfig(
                    RuntimeConfig.getCurrentInstance(
                            FacesContext.getCurrentInstance()
                            .getExternalContext()));

            //throw new IllegalStateException("The runtime config instance which is created while initialize myfaces "
            //        + "must be set through ApplicationImpl.setInitializingRuntimeConfig");
        }
        return initializingRuntimeConfig.get();
    }

    ApplicationImpl(RuntimeConfig runtimeConfig)
    {
        if (runtimeConfig == null)
        {
            throw new IllegalArgumentException("runtimeConfig must mot be null");
        }
        // set default implementation in constructor
        // pragmatic approach, no syncronizing will be needed in get methods
        _viewHandler = new JspViewHandlerImpl();
        _navigationHandler = new NavigationHandlerImpl();
        _actionListener = new ActionListenerImpl();
        _defaultRenderKitId = "HTML_BASIC";
        _stateManager = new JspStateManagerImpl();
        _elContextListeners = new ArrayList<ELContextListener>();
        _runtimeConfig = runtimeConfig;

        if (log.isTraceEnabled())
            log.trace("New Application instance created");
    }

    public static void setInitializingRuntimeConfig(RuntimeConfig config)
    {
        initializingRuntimeConfig.set(config);
    }

    // ~ Methods
    // ------------------------------------------------------------------------------------

    @Override
    public void addELResolver(ELResolver resolver)
    {
        if (FacesContext.getCurrentInstance() != null)
        {
            throw new IllegalStateException("It is illegal to add a resolver after the first request is processed");
        }
        if (resolver != null)
        {
            _runtimeConfig.addApplicationElResolver(resolver);
        }
    }

    @Override
    public ELResolver getELResolver()
    {
        // we don't need synchronization here since it is ok to have multiple instances of the elresolver
        if (elResolver == null)
        {
            elResolver = createFacesResolver();
        }
        return elResolver;
    }

    private ELResolver createFacesResolver()
    {
        CompositeELResolver resolver = new FacesCompositeELResolver(Scope.Faces);
        getResolverBuilderForFaces().build(resolver);
        return resolver;
    }

    protected ELResolverBuilder getResolverBuilderForFaces()
    {
        if (resolverBuilderForFaces == null)
        {
            resolverBuilderForFaces = new ResolverBuilderForFaces(_runtimeConfig);
        }
        return resolverBuilderForFaces;
    }

    public void setResolverBuilderForFaces(ELResolverBuilder factory)
    {
        resolverBuilderForFaces = factory;
    }

    @Override
    public java.util.ResourceBundle getResourceBundle(FacesContext facesContext, String name) throws FacesException,
            NullPointerException
    {

        checkNull(facesContext, "facesContext");
        checkNull(name, "name");

        String bundleName = getBundleName(facesContext, name);

        if (bundleName == null)
        {
            return null;
        }

        Locale locale = Locale.getDefault();

        UIViewRoot viewRoot = facesContext.getViewRoot();
        if (viewRoot != null && viewRoot.getLocale() != null)
        {
            locale = viewRoot.getLocale();
        }

        try
        {
            return getResourceBundle(bundleName, locale, getClassLoader());
        }
        catch (MissingResourceException e)
        {
            throw new FacesException("Could not load resource bundle for name '" + name + "': " + e.getMessage(), e);
        }
    }

    ClassLoader getClassLoader()
    {
        return Thread.currentThread().getContextClassLoader();
    }

    String getBundleName(FacesContext facesContext, String name)
    {
        ResourceBundle bundle = getRuntimeConfig(facesContext).getResourceBundle(name);
        return bundle != null ? bundle.getBaseName() : null;
    }

    java.util.ResourceBundle getResourceBundle(String name, Locale locale, ClassLoader loader)
            throws MissingResourceException
    {
        return java.util.ResourceBundle.getBundle(name, locale, loader);
    }

    RuntimeConfig getRuntimeConfig(FacesContext facesContext)
    {
        return RuntimeConfig.getCurrentInstance(facesContext.getExternalContext());
    }

    FacesContext getFaceContext()
    {
        return FacesContext.getCurrentInstance();
    }

    @Override
    public UIComponent createComponent(ValueExpression componentExpression, FacesContext facesContext,
            String componentType) throws FacesException, NullPointerException
    {

        checkNull(componentExpression, "componentExpression");
        checkNull(facesContext, "facesContext");
        checkNull(componentType, "componentType");

        ELContext elContext = facesContext.getELContext();

        try
        {
            Object retVal = componentExpression.getValue(elContext);

            UIComponent createdComponent;

            if (retVal instanceof UIComponent)
            {
                createdComponent = (UIComponent) retVal;
            }
            else
            {
                createdComponent = createComponent(componentType);
                componentExpression.setValue(elContext, createdComponent);
            }

            return createdComponent;
        }
        catch (FacesException e)
        {
            throw e;
        }
        catch (Exception e)
        {
            throw new FacesException(e);
        }
    }

    @Override
    public ExpressionFactory getExpressionFactory()
    {
        return _runtimeConfig.getExpressionFactory();
    }

    @Override
    public Object evaluateExpressionGet(FacesContext context, String expression, Class expectedType) throws ELException
    {
        ELContext elContext = context.getELContext();
        return getExpressionFactory().createValueExpression(elContext, expression, expectedType).getValue(elContext);
    }

    @Override
    public void addELContextListener(ELContextListener listener)
    {

        synchronized (_elContextListeners)
        {
            _elContextListeners.add(listener);
        }
    }

    @Override
    public void removeELContextListener(ELContextListener listener)
    {
        synchronized (_elContextListeners)
        {
            _elContextListeners.remove(listener);
        }
    }

    @Override
    public ELContextListener[] getELContextListeners()
    {
        // this gets called on every request, so I can't afford to synchronize
        // I just have to trust that toArray() with do the right thing if the
        // list is changing (not likely)
        return _elContextListeners.toArray(new ELContextListener[0]);
    }

    @Override
    public void setActionListener(ActionListener actionListener)
    {
        checkNull(actionListener, "actionListener");

        _actionListener = actionListener;
        if (log.isTraceEnabled())
            log.trace("set actionListener = " + actionListener.getClass().getName());
    }

    @Override
    public ActionListener getActionListener()
    {
        return _actionListener;
    }

    @Override
    public Iterator<String> getComponentTypes()
    {
        return _componentClassMap.keySet().iterator();
    }

    @Override
    public Iterator<String> getConverterIds()
    {
        return _converterIdToClassMap.keySet().iterator();
    }

    @Override
    public Iterator<Class> getConverterTypes()
    {
        return _converterClassNameToClassMap.keySet().iterator();
    }

    @Override
    public void setDefaultLocale(Locale locale)
    {
        checkNull(locale, "locale");

        _defaultLocale = locale;
        if (log.isTraceEnabled())
            log.trace("set defaultLocale = " + locale.getCountry() + " " + locale.getLanguage());
    }

    @Override
    public Locale getDefaultLocale()
    {
        return _defaultLocale;
    }

    @Override
    public void setMessageBundle(String messageBundle)
    {
        checkNull(messageBundle, "messageBundle");

        _messageBundle = messageBundle;
        if (log.isTraceEnabled())
            log.trace("set MessageBundle = " + messageBundle);
    }

    @Override
    public String getMessageBundle()
    {
        return _messageBundle;
    }

    @Override
    public void setNavigationHandler(NavigationHandler navigationHandler)
    {
        checkNull(navigationHandler, "navigationHandler");

        _navigationHandler = navigationHandler;
        if (log.isTraceEnabled())
            log.trace("set NavigationHandler = " + navigationHandler.getClass().getName());
    }

    @Override
    public NavigationHandler getNavigationHandler()
    {
        return _navigationHandler;
    }

    /**
     * @deprecated
     */
    @Deprecated
    @Override
    public void setPropertyResolver(PropertyResolver propertyResolver)
    {
        checkNull(propertyResolver, "propertyResolver");

        if (getFaceContext() != null)
        {
            throw new IllegalStateException("propertyResolver must be defined before request processing");
        }

        _runtimeConfig.setPropertyResolver(propertyResolver);

        if (log.isTraceEnabled())
            log.trace("set PropertyResolver = " + propertyResolver.getClass().getName());
    }

    /**
     * @deprecated
     */
    @Deprecated
    @Override
    public PropertyResolver getPropertyResolver()
    {
        return PROPERTYRESOLVER;
    }

    @Override
    public void setSupportedLocales(Collection<Locale> locales)
    {
        checkNull(locales, "locales");

        _supportedLocales = locales;
        if (log.isTraceEnabled())
            log.trace("set SupportedLocales");
    }

    @Override
    public Iterator<Locale> getSupportedLocales()
    {
        return _supportedLocales.iterator();
    }

    @Override
    public Iterator<String> getValidatorIds()
    {
        return _validatorClassMap.keySet().iterator();
    }

    /**
     * @deprecated
     */
    @Deprecated
    @Override
    public void setVariableResolver(VariableResolver variableResolver)
    {
        checkNull(variableResolver, "variableResolver");

        if (getFaceContext() != null)
        {
            throw new IllegalStateException("variableResolver must be defined before request processing");
        }

        _runtimeConfig.setVariableResolver(variableResolver);

        if (log.isTraceEnabled())
            log.trace("set VariableResolver = " + variableResolver.getClass().getName());
    }

    /**
     * @deprecated
     */
    @Deprecated
    @Override
    public VariableResolver getVariableResolver()
    {
        return VARIABLERESOLVER;
    }

    @Override
    public void setViewHandler(ViewHandler viewHandler)
    {
        checkNull(viewHandler, "viewHandler");

        _viewHandler = viewHandler;
        if (log.isTraceEnabled())
            log.trace("set ViewHandler = " + viewHandler.getClass().getName());
    }

    @Override
    public ViewHandler getViewHandler()
    {
        return _viewHandler;
    }

    @Override
    public void addComponent(String componentType, String componentClassName)
    {
        checkNull(componentType, "componentType");
        checkEmpty(componentType, "componentType");
        checkNull(componentClassName, "componentClassName");
        checkEmpty(componentClassName, "componentClassName");

        try
        {
            _componentClassMap.put(componentType, ClassUtils.simpleClassForName(componentClassName));
            if (log.isTraceEnabled())
                log.trace("add Component class = " + componentClassName + " for type = " + componentType);
        }
        catch (Exception e)
        {
            log.error("Component class " + componentClassName + " not found", e);
        }
    }

    @Override
    public void addConverter(String converterId, String converterClass)
    {
        checkNull(converterId, "converterId");
        checkEmpty(converterId, "converterId");
        checkNull(converterClass, "converterClass");
        checkEmpty(converterClass, "converterClass");

        try
        {
            _converterIdToClassMap.put(converterId, ClassUtils.simpleClassForName(converterClass));
            if (log.isTraceEnabled())
                log.trace("add Converter id = " + converterId + " converterClass = " + converterClass);
        }
        catch (Exception e)
        {
            log.error("Converter class " + converterClass + " not found", e);
        }
    }

    @Override
    public void addConverter(Class targetClass, String converterClass)
    {
        checkNull(targetClass, "targetClass");
        checkNull(converterClass, "converterClass");
        checkEmpty(converterClass, "converterClass");

        try
        {
            _converterClassNameToClassMap.put(targetClass, converterClass);
            if (log.isTraceEnabled())
                log.trace("add Converter for class = " + targetClass + " converterClass = " + converterClass);
        }
        catch (Exception e)
        {
            log.error("Converter class " + converterClass + " not found", e);
        }
    }

    public void addConverterConfiguration(String converterClassName,
            org.apache.myfaces.config.impl.digester.elements.Converter configuration)
    {
        checkNull(converterClassName, "converterClassName");
        checkEmpty(converterClassName, "converterClassName");
        checkNull(configuration, "configuration");

        _converterClassNameToConfigurationMap.put(converterClassName, configuration);
    }

    @Override
    public void addValidator(String validatorId, String validatorClass)
    {
        checkNull(validatorId, "validatorId");
        checkEmpty(validatorId, "validatorId");
        checkNull(validatorClass, "validatorClass");
        checkEmpty(validatorClass, "validatorClass");

        try
        {
            _validatorClassMap.put(validatorId, ClassUtils.simpleClassForName(validatorClass));
            if (log.isTraceEnabled())
                log.trace("add Validator id = " + validatorId + " class = " + validatorClass);
        }
        catch (Exception e)
        {
            log.error("Validator class " + validatorClass + " not found", e);
        }
    }

    @Override
    public UIComponent createComponent(String componentType) throws FacesException
    {
        checkNull(componentType, "componentType");
        checkEmpty(componentType, "componentType");

        Class componentClass = _componentClassMap.get(componentType);
        if (componentClass == null)
        {
            log.error("Undefined component type " + componentType);
            throw new FacesException("Undefined component type " + componentType);
        }

        try
        {
            return (UIComponent) componentClass.newInstance();
        }
        catch (Exception e)
        {
            log.error("Could not instantiate component componentType = " + componentType, e);
            throw new FacesException("Could not instantiate component componentType = " + componentType, e);
        }
    }

    /**
     * @deprecated Use createComponent(ValueExpression, FacesContext, String) instead.
     */
    @Deprecated
    @Override
    public UIComponent createComponent(ValueBinding valueBinding, FacesContext facesContext, String componentType)
            throws FacesException
    {

        checkNull(valueBinding, "valueBinding");
        checkNull(facesContext, "facesContext");
        checkNull(componentType, "componentType");
        checkEmpty(componentType, "componentType");

        ValueExpression valExpression = new ValueBindingToValueExpression(valueBinding);

        return createComponent(valExpression, facesContext, componentType);
    }

    /**
     * Return an instance of the converter class that has been registered under
     * the specified id.
     * <p>
     * Converters are registered via faces-config.xml files, and can also be registered
     * via the addConverter(String id, Class converterClass) method on this class. Here
     * the the appropriate Class definition is found, then an instance is created and
     * returned.
     * <p>
     * A converter registered via a config file can have any number of nested attribute or
     * property tags. The JSF specification is very vague about what effect these nested
     * tags have. This method ignores nested attribute definitions, but for each nested
     * property tag the corresponding setter is invoked on the new Converter instance
     * passing the property's defaultValuer. Basic typeconversion is done so the target
     * properties on the Converter instance can be String, int, boolean, etc. Note that:
     * <ol>
     * <li>the Sun Mojarra JSF implemenation ignores nested property tags completely, so
     * this behaviour cannot be relied on across implementations.
     * <li>there is no equivalent functionality for converter classes registered via
     * the Application.addConverter api method.
     * </ol>
     * <p>
     * Note that this method is most commonly called from the standard f:attribute tag.
     * As an alternative, most components provide a "converter" attribute which uses an
     * EL expression to create a Converter instance, in which case this method is not
     * invoked at all. The converter attribute allows the returned Converter instance to
     * be configured via normal dependency-injection, and is generally a better choice
     * than using this method.
     */
    @Override
    public Converter createConverter(String converterId)
    {
        checkNull(converterId, "converterId");
        checkEmpty(converterId, "converterId");

        Class converterClass = _converterIdToClassMap.get(converterId);
        if(converterClass == null)
        {
            throw new FacesException("Could not find any registered converter-class by converterId : "+converterId);
        }

		try
        {
            Converter converter = (Converter) converterClass.newInstance();

            setConverterProperties(converterClass, converter);

            return converter;
        }
        catch (Exception e)
        {
            log.error("Could not instantiate converter " + converterClass, e);
            throw new FacesException("Could not instantiate converter: " + converterClass, e);
        }
    }

    @Override
    public Converter createConverter(Class targetClass)
    {
        checkNull(targetClass, "targetClass");

        return internalCreateConverter(targetClass);
    }

    private Converter internalCreateConverter(Class targetClass)
    {
        // Locate a Converter registered for the target class itself.
        String converterClassName = _converterClassNameToClassMap.get(targetClass);

        // Get EnumConverter for enum classes with no special converter, check
        // here as recursive call with java.lang.Enum will not work
        if (converterClassName == null && targetClass.isEnum()) {
        	converterClassName = _converterClassNameToClassMap.get(Enum.class);
        }

        // Locate a Converter registered for interfaces that are
        // implemented by the target class (directly or indirectly).
        if (converterClassName == null)
        {
            Class interfaces[] = targetClass.getInterfaces();
            if (interfaces != null)
            {
                for (int i = 0, len = interfaces.length; i < len; i++)
                {
                    // search all superinterfaces for a matching converter,
                    // create it
                    Converter converter = internalCreateConverter(interfaces[i]);
                    if (converter != null)
                    {
                        return converter;
                    }
                }
            }
        }

        if (converterClassName != null)
        {
            try
            {
                Class converterClass = ClassUtils.simpleClassForName(converterClassName);

                Converter converter = null;
                try
                {
                    // look for a constructor that takes a single Class object
                    // See JSF 1.2 javadoc for Converter
                    Constructor constructor = converterClass.getConstructor(new Class[] { Class.class });
                    converter = (Converter) constructor.newInstance(new Object[] { targetClass });
                }
                catch (Exception e)
                {
                    // if there is no matching constructor use no-arg
                    // constructor
                    converter = (Converter) converterClass.newInstance();
                }

                setConverterProperties(converterClass, converter);

                return converter;
            }
            catch (Exception e)
            {
                log.error("Could not instantiate converter " + converterClassName, e);
                throw new FacesException("Could not instantiate converter: " + converterClassName, e);
            }
        }

        // locate converter for primitive types
        if (targetClass == Long.TYPE)
        {
            return internalCreateConverter(Long.class);
        }
        else if (targetClass == Boolean.TYPE)
        {
            return internalCreateConverter(Boolean.class);
        }
        else if (targetClass == Double.TYPE)
        {
            return internalCreateConverter(Double.class);
        }
        else if (targetClass == Byte.TYPE)
        {
            return internalCreateConverter(Byte.class);
        }
        else if (targetClass == Short.TYPE)
        {
            return internalCreateConverter(Short.class);
        }
        else if (targetClass == Integer.TYPE)
        {
            return internalCreateConverter(Integer.class);
        }
        else if (targetClass == Float.TYPE)
        {
            return internalCreateConverter(Float.class);
        }
        else if (targetClass == Character.TYPE)
        {
            return internalCreateConverter(Character.class);
        }

        // Locate a Converter registered for the superclass (if any) of the
        // target class,
        // recursively working up the inheritance hierarchy.
        Class superClazz = targetClass.getSuperclass();

        return superClazz != null ? internalCreateConverter(superClazz) : null;

    }

    private void setConverterProperties(Class converterClass, Converter converter)
    {
        org.apache.myfaces.config.impl.digester.elements.Converter converterConfig = _converterClassNameToConfigurationMap
                .get(converterClass.getName());

        if (converterConfig != null)
        {

            Iterator it = converterConfig.getProperties();

            while (it.hasNext())
            {
                Property property = (Property) it.next();

                try
                {
                    BeanUtils.setProperty(converter, property.getPropertyName(), property.getDefaultValue());
                }
                catch (Throwable th)
                {
                    log.error("Initializing converter : " + converterClass.getName() + " with property : "
                            + property.getPropertyName() + " and value : " + property.getDefaultValue() + " failed.");
                }
            }
        }
    }

    // Note: this method used to be synchronized in the JSF 1.1 version. Why?
    /**
     * @deprecated
     */
    @Deprecated
    @Override
    public MethodBinding createMethodBinding(String reference, Class[] params) throws ReferenceSyntaxException
    {
        checkNull(reference, "reference");
        checkEmpty(reference, "reference");

        // TODO: this check should be performed by the expression factory. It is a requirement of the TCK
        if (!(reference.startsWith("#{") && reference.endsWith("}")))
        {
            throw new ReferenceSyntaxException("Invalid method reference: '" + reference + "'");
        }

        if (params == null)
            params = new Class[0];

        MethodExpression methodExpression;

        try
        {
            methodExpression = getExpressionFactory().createMethodExpression(threadELContext(), reference,
                    Object.class, params);
        }
        catch (ELException e)
        {
            throw new ReferenceSyntaxException(e);
        }

        return new MethodExpressionToMethodBinding(methodExpression);
    }

    @Override
    public Validator createValidator(String validatorId) throws FacesException
    {
        checkNull(validatorId, "validatorId");
        checkEmpty(validatorId, "validatorId");

        Class validatorClass = _validatorClassMap.get(validatorId);
        if (validatorClass == null)
        {
            String message = "Unknown validator id '" + validatorId + "'.";
            log.error(message);
            throw new FacesException(message);
        }

        try
        {
            return (Validator) validatorClass.newInstance();
        }
        catch (Exception e)
        {
            log.error("Could not instantiate validator " + validatorClass, e);
            throw new FacesException("Could not instantiate validator: " + validatorClass, e);
        }
    }

    /**
     * @deprecated
     */
    @Override
    public ValueBinding createValueBinding(String reference) throws ReferenceSyntaxException
    {
        checkNull(reference, "reference");
        checkEmpty(reference, "reference");

        ValueExpression valueExpression;

        try
        {
            valueExpression = getExpressionFactory().createValueExpression(threadELContext(), reference, Object.class);
        }
        catch (ELException e)
        {
            throw new ReferenceSyntaxException(e);
        }

        return new ValueExpressionToValueBinding(valueExpression);
    }

    // gets the elContext from the current FacesContext()
    private ELContext threadELContext()
    {
        return getFaceContext().getELContext();
    }

    @Override
    public String getDefaultRenderKitId()
    {
        return _defaultRenderKitId;
    }

    @Override
    public void setDefaultRenderKitId(String defaultRenderKitId)
    {
        _defaultRenderKitId = defaultRenderKitId;
    }

    @Override
    public StateManager getStateManager()
    {
        return _stateManager;
    }

    @Override
    public void setStateManager(StateManager stateManager)
    {
        _stateManager = stateManager;
    }

    private void checkNull(Object param, String paramName)
    {
        if (param == null)
        {
            throw new NullPointerException(paramName + " can not be null.");
        }
    }

    private void checkEmpty(String param, String paramName)
    {
        if (param.length() == 0)
        {
            throw new NullPointerException("String " + paramName + " can not be empty.");
        }
    }
}
