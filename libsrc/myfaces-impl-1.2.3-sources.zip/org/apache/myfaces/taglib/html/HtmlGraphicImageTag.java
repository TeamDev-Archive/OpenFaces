// WARNING: This file was automatically generated. Do not edit it directly,
//          or you will lose your changes.

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
*/
package org.apache.myfaces.taglib.html;

import javax.el.ValueExpression;
import javax.faces.component.UIComponent;
import javax.faces.component.UIGraphic;
import javax.faces.component.html.HtmlGraphicImage;
import javax.faces.webapp.UIComponentELTag;

/**
 * Auto-generated tag class.
 */
public class HtmlGraphicImageTag extends UIComponentELTag
{

  /**
   * Construct an instance of the HtmlGraphicImageTag.
   */
  public HtmlGraphicImageTag()
  {
  }

  @Override
  public String getComponentType()
  {
    return "javax.faces.HtmlGraphicImage";
  }

  public String getRendererType()
  {
    return "javax.faces.Image";
  }

  private ValueExpression _value;
  public void setValue(ValueExpression value)
  {
    _value = value;
  }

  private ValueExpression _url;
  public void setUrl(ValueExpression url)
  {
    _url = url;
  }

  private ValueExpression _style;
  public void setStyle(ValueExpression style)
  {
    _style = style;
  }

  private ValueExpression _styleClass;
  public void setStyleClass(ValueExpression styleClass)
  {
    _styleClass = styleClass;
  }

  private ValueExpression _dir;
  public void setDir(ValueExpression dir)
  {
    _dir = dir;
  }

  private ValueExpression _lang;
  public void setLang(ValueExpression lang)
  {
    _lang = lang;
  }

  private ValueExpression _title;
  public void setTitle(ValueExpression title)
  {
    _title = title;
  }

  private ValueExpression _onclick;
  public void setOnclick(ValueExpression onclick)
  {
    _onclick = onclick;
  }

  private ValueExpression _ondblclick;
  public void setOndblclick(ValueExpression ondblclick)
  {
    _ondblclick = ondblclick;
  }

  private ValueExpression _onmousedown;
  public void setOnmousedown(ValueExpression onmousedown)
  {
    _onmousedown = onmousedown;
  }

  private ValueExpression _onmouseup;
  public void setOnmouseup(ValueExpression onmouseup)
  {
    _onmouseup = onmouseup;
  }

  private ValueExpression _onmouseover;
  public void setOnmouseover(ValueExpression onmouseover)
  {
    _onmouseover = onmouseover;
  }

  private ValueExpression _onmousemove;
  public void setOnmousemove(ValueExpression onmousemove)
  {
    _onmousemove = onmousemove;
  }

  private ValueExpression _onmouseout;
  public void setOnmouseout(ValueExpression onmouseout)
  {
    _onmouseout = onmouseout;
  }

  private ValueExpression _onkeypress;
  public void setOnkeypress(ValueExpression onkeypress)
  {
    _onkeypress = onkeypress;
  }

  private ValueExpression _onkeydown;
  public void setOnkeydown(ValueExpression onkeydown)
  {
    _onkeydown = onkeydown;
  }

  private ValueExpression _onkeyup;
  public void setOnkeyup(ValueExpression onkeyup)
  {
    _onkeyup = onkeyup;
  }

  private ValueExpression _alt;
  public void setAlt(ValueExpression alt)
  {
    _alt = alt;
  }

  private ValueExpression _height;
  public void setHeight(ValueExpression height)
  {
    _height = height;
  }

  private ValueExpression _width;
  public void setWidth(ValueExpression width)
  {
    _width = width;
  }

  private ValueExpression _longdesc;
  public void setLongdesc(ValueExpression longdesc)
  {
    _longdesc = longdesc;
  }

  private ValueExpression _usemap;
  public void setUsemap(ValueExpression usemap)
  {
    _usemap = usemap;
  }

  private ValueExpression _ismap;
  public void setIsmap(ValueExpression ismap)
  {
    _ismap = ismap;
  }

  @Override
  protected void setProperties(UIComponent component)
{
  if (!(component instanceof HtmlGraphicImage))
  {
    throw new IllegalArgumentException("Component " + component.getClass().getName() + " is no HtmlGraphicImage");
  }
  HtmlGraphicImage comp = (HtmlGraphicImage)component;

  super.setProperties(component);

  if (_dir != null) 
  {
    comp.setValueExpression("dir", _dir);
  }
  if (_onkeypress != null) 
  {
    comp.setValueExpression("onkeypress", _onkeypress);
  }
  if (_onmouseout != null) 
  {
    comp.setValueExpression("onmouseout", _onmouseout);
  }
  if (_onmousedown != null) 
  {
    comp.setValueExpression("onmousedown", _onmousedown);
  }
  if (_onmouseover != null) 
  {
    comp.setValueExpression("onmouseover", _onmouseover);
  }
  if (_ondblclick != null) 
  {
    comp.setValueExpression("ondblclick", _ondblclick);
  }
  if (_value != null) 
  {
    comp.setValueExpression("value", _value);
  }
  if (_lang != null) 
  {
    comp.setValueExpression("lang", _lang);
  }
  if (_title != null) 
  {
    comp.setValueExpression("title", _title);
  }
  if (_style != null) 
  {
    comp.setValueExpression("style", _style);
  }
  if (_url != null) 
  {
    comp.setValueExpression("url", _url);
  }
  if (_ismap != null) 
  {
    comp.setValueExpression("ismap", _ismap);
  }
  if (_usemap != null) 
  {
    comp.setValueExpression("usemap", _usemap);
  }
  if (_longdesc != null) 
  {
    comp.setValueExpression("longdesc", _longdesc);
  }
  if (_height != null) 
  {
    comp.setValueExpression("height", _height);
  }
  if (_alt != null) 
  {
    comp.setValueExpression("alt", _alt);
  }
  if (_styleClass != null) 
  {
    comp.setValueExpression("styleClass", _styleClass);
  }
  if (_onclick != null) 
  {
    comp.setValueExpression("onclick", _onclick);
  }
  if (_width != null) 
  {
    comp.setValueExpression("width", _width);
  }
  if (_onkeydown != null) 
  {
    comp.setValueExpression("onkeydown", _onkeydown);
  }
  if (_onmousemove != null) 
  {
    comp.setValueExpression("onmousemove", _onmousemove);
  }
  if (_onkeyup != null) 
  {
    comp.setValueExpression("onkeyup", _onkeyup);
  }
  if (_onmouseup != null) 
  {
    comp.setValueExpression("onmouseup", _onmouseup);
  }
}

@Override
public void release()
{
  super.release();
  _dir = null;
  _onkeypress = null;
  _onmouseout = null;
  _onmousedown = null;
  _onmouseover = null;
  _ondblclick = null;
  _value = null;
  _lang = null;
  _title = null;
  _style = null;
  _url = null;
  _ismap = null;
  _usemap = null;
  _longdesc = null;
  _height = null;
  _alt = null;
  _styleClass = null;
  _onclick = null;
  _width = null;
  _onkeydown = null;
  _onmousemove = null;
  _onkeyup = null;
  _onmouseup = null;
}
}
