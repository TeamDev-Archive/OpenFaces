// WARNING: This file was automatically generated. Do not edit it directly,
//          or you will lose your changes.

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
*/
package org.apache.myfaces.taglib.html;

import javax.el.ValueExpression;
import javax.faces.component.UIComponent;
import javax.faces.component.UIPanel;
import javax.faces.component.html.HtmlPanelGroup;
import javax.faces.webapp.UIComponentELTag;

/**
 * Auto-generated tag class.
 */
public class HtmlPanelGroupTag extends UIComponentELTag
{

  /**
   * Construct an instance of the HtmlPanelGroupTag.
   */
  public HtmlPanelGroupTag()
  {
  }

  @Override
  public String getComponentType()
  {
    return "javax.faces.HtmlPanelGroup";
  }

  public String getRendererType()
  {
    return "javax.faces.Group";
  }

  private ValueExpression _style;
  public void setStyle(ValueExpression style)
  {
    _style = style;
  }

  private ValueExpression _styleClass;
  public void setStyleClass(ValueExpression styleClass)
  {
    _styleClass = styleClass;
  }

  private ValueExpression _layout;
  public void setLayout(ValueExpression layout)
  {
    _layout = layout;
  }

  @Override
  protected void setProperties(UIComponent component)
{
  if (!(component instanceof HtmlPanelGroup))
  {
    throw new IllegalArgumentException("Component " + component.getClass().getName() + " is no HtmlPanelGroup");
  }
  HtmlPanelGroup comp = (HtmlPanelGroup)component;

  super.setProperties(component);

  if (_style != null) 
  {
    comp.setValueExpression("style", _style);
  }
  if (_layout != null) 
  {
    comp.setValueExpression("layout", _layout);
  }
  if (_styleClass != null) 
  {
    comp.setValueExpression("styleClass", _styleClass);
  }
}

@Override
public void release()
{
  super.release();
  _style = null;
  _layout = null;
  _styleClass = null;
}
}
