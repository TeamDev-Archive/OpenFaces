// WARNING: This file was automatically generated. Do not edit it directly,
//          or you will lose your changes.

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
*/
package org.apache.myfaces.taglib.html;

import javax.el.ValueExpression;
import javax.faces.component.UIComponent;
import javax.faces.component.UIOutput;
import javax.faces.component.html.HtmlOutputFormat;
import javax.faces.convert.Converter;
import javax.faces.webapp.UIComponentELTag;

/**
 * Auto-generated tag class.
 */
public class HtmlOutputFormatTag extends UIComponentELTag
{

  /**
   * Construct an instance of the HtmlOutputFormatTag.
   */
  public HtmlOutputFormatTag()
  {
  }

  @Override
  public String getComponentType()
  {
    return "javax.faces.HtmlOutputFormat";
  }

  public String getRendererType()
  {
    return "javax.faces.Format";
  }

  private ValueExpression _style;
  public void setStyle(ValueExpression style)
  {
    _style = style;
  }

  private ValueExpression _styleClass;
  public void setStyleClass(ValueExpression styleClass)
  {
    _styleClass = styleClass;
  }

  private ValueExpression _dir;
  public void setDir(ValueExpression dir)
  {
    _dir = dir;
  }

  private ValueExpression _lang;
  public void setLang(ValueExpression lang)
  {
    _lang = lang;
  }

  private ValueExpression _title;
  public void setTitle(ValueExpression title)
  {
    _title = title;
  }

  private ValueExpression _escape;
  public void setEscape(ValueExpression escape)
  {
    _escape = escape;
  }

  private ValueExpression _value;
  public void setValue(ValueExpression value)
  {
    _value = value;
  }

  private ValueExpression _converter;
  public void setConverter(ValueExpression converter)
  {
    _converter = converter;
  }

  @Override
  protected void setProperties(UIComponent component)
{
  if (!(component instanceof HtmlOutputFormat))
  {
    throw new IllegalArgumentException("Component " + component.getClass().getName() + " is no HtmlOutputFormat");
  }
  HtmlOutputFormat comp = (HtmlOutputFormat)component;

  super.setProperties(component);

  if (_style != null) 
  {
    comp.setValueExpression("style", _style);
  }
  if (_value != null) 
  {
    comp.setValueExpression("value", _value);
  }
  if (_escape != null) 
  {
    comp.setValueExpression("escape", _escape);
  }
  if (_styleClass != null) 
  {
    comp.setValueExpression("styleClass", _styleClass);
  }
  if (_dir != null) 
  {
    comp.setValueExpression("dir", _dir);
  }
  if (_converter != null)
  {
    if (!_converter.isLiteralText())
    {
      comp.setValueExpression("converter", _converter);
    }
    else
    {
      String s = _converter.getExpressionString();
      if (s != null)
      {
        Converter converter = getFacesContext().getApplication().
          createConverter(s);
        comp.setConverter(converter);
      }
    }
  }
  if (_title != null) 
  {
    comp.setValueExpression("title", _title);
  }
  if (_lang != null) 
  {
    comp.setValueExpression("lang", _lang);
  }
}

@Override
public void release()
{
  super.release();
  _style = null;
  _value = null;
  _escape = null;
  _styleClass = null;
  _dir = null;
  _converter = null;
  _title = null;
  _lang = null;
}
}
