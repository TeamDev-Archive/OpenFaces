// WARNING: This file was automatically generated. Do not edit it directly,
//          or you will lose your changes.

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
*/
package org.apache.myfaces.taglib.html;

import javax.el.MethodExpression;
import javax.el.ValueExpression;
import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.component.UIOutput;
import javax.faces.component.html.HtmlInputHidden;
import javax.faces.convert.Converter;
import javax.faces.event.MethodExpressionValueChangeListener;
import javax.faces.validator.MethodExpressionValidator;
import javax.faces.webapp.UIComponentELTag;

/**
 * Auto-generated tag class.
 */
public class HtmlInputHiddenTag extends UIComponentELTag
{

  /**
   * Construct an instance of the HtmlInputHiddenTag.
   */
  public HtmlInputHiddenTag()
  {
  }

  @Override
  public String getComponentType()
  {
    return "javax.faces.HtmlInputHidden";
  }

  public String getRendererType()
  {
    return "javax.faces.Hidden";
  }

  private ValueExpression _immediate;
  public void setImmediate(ValueExpression immediate)
  {
    _immediate = immediate;
  }

  private ValueExpression _required;
  public void setRequired(ValueExpression required)
  {
    _required = required;
  }

  private ValueExpression _converterMessage;
  public void setConverterMessage(ValueExpression converterMessage)
  {
    _converterMessage = converterMessage;
  }

  private ValueExpression _requiredMessage;
  public void setRequiredMessage(ValueExpression requiredMessage)
  {
    _requiredMessage = requiredMessage;
  }

  private MethodExpression _validator;
  public void setValidator(MethodExpression validator)
  {
    _validator = validator;
  }

  private ValueExpression _validatorMessage;
  public void setValidatorMessage(ValueExpression validatorMessage)
  {
    _validatorMessage = validatorMessage;
  }

  private MethodExpression _valueChangeListener;
  public void setValueChangeListener(MethodExpression valueChangeListener)
  {
    _valueChangeListener = valueChangeListener;
  }

  private ValueExpression _value;
  public void setValue(ValueExpression value)
  {
    _value = value;
  }

  private ValueExpression _converter;
  public void setConverter(ValueExpression converter)
  {
    _converter = converter;
  }

  @Override
  protected void setProperties(UIComponent component)
{
  if (!(component instanceof HtmlInputHidden))
  {
    throw new IllegalArgumentException("Component " + component.getClass().getName() + " is no HtmlInputHidden");
  }
  HtmlInputHidden comp = (HtmlInputHidden)component;

  super.setProperties(component);

  if (_validatorMessage != null) 
  {
    comp.setValueExpression("validatorMessage", _validatorMessage);
  }
  if (_validator != null)
  {
    comp.addValidator(new MethodExpressionValidator(_validator));
  }
  if (_requiredMessage != null) 
  {
    comp.setValueExpression("requiredMessage", _requiredMessage);
  }
  if (_converterMessage != null) 
  {
    comp.setValueExpression("converterMessage", _converterMessage);
  }
  if (_value != null) 
  {
    comp.setValueExpression("value", _value);
  }
  if (_valueChangeListener != null)
  {
    comp.addValueChangeListener(new MethodExpressionValueChangeListener(_valueChangeListener));
  }
  if (_immediate != null) 
  {
    comp.setValueExpression("immediate", _immediate);
  }
  if (_converter != null)
  {
    if (!_converter.isLiteralText())
    {
      comp.setValueExpression("converter", _converter);
    }
    else
    {
      String s = _converter.getExpressionString();
      if (s != null)
      {
        Converter converter = getFacesContext().getApplication().
          createConverter(s);
        comp.setConverter(converter);
      }
    }
  }
  if (_required != null) 
  {
    comp.setValueExpression("required", _required);
  }
}

@Override
public void release()
{
  super.release();
  _validatorMessage = null;
  _validator = null;
  _requiredMessage = null;
  _converterMessage = null;
  _value = null;
  _valueChangeListener = null;
  _immediate = null;
  _converter = null;
  _required = null;
}
}
