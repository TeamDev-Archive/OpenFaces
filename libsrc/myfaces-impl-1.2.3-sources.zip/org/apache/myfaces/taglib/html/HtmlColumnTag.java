// WARNING: This file was automatically generated. Do not edit it directly,
//          or you will lose your changes.

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
*/
package org.apache.myfaces.taglib.html;

import javax.el.ValueExpression;
import javax.faces.component.UIColumn;
import javax.faces.component.UIComponent;
import javax.faces.component.html.HtmlColumn;
import javax.faces.webapp.UIComponentELTag;

/**
 * Auto-generated tag class.
 */
public class HtmlColumnTag extends UIComponentELTag
{

  /**
   * Construct an instance of the HtmlColumnTag.
   */
  public HtmlColumnTag()
  {
  }

  @Override
  public String getComponentType()
  {
    return "javax.faces.Column";
  }

  public String getRendererType()
  {
    return null;
  }

  private ValueExpression _headerClass;
  public void setHeaderClass(ValueExpression headerClass)
  {
    _headerClass = headerClass;
  }

  private ValueExpression _footerClass;
  public void setFooterClass(ValueExpression footerClass)
  {
    _footerClass = footerClass;
  }

  @Override
  protected void setProperties(UIComponent component)
{
  if (!(component instanceof UIColumn))
  {
    throw new IllegalArgumentException("Component " + component.getClass().getName() + " is no UIColumn");
  }
  UIColumn comp = (UIColumn)component;

  super.setProperties(component);

  if (_footerClass != null) 
  {
    comp.setValueExpression("footerClass", _footerClass);
  }
  if (_headerClass != null) 
  {
    comp.setValueExpression("headerClass", _headerClass);
  }
}

@Override
public void release()
{
  super.release();
  _footerClass = null;
  _headerClass = null;
}
}
