// WARNING: This file was automatically generated. Do not edit it directly,
//          or you will lose your changes.

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
*/
package org.apache.myfaces.taglib.html;

import javax.el.MethodExpression;
import javax.el.ValueExpression;
import javax.faces.component.UICommand;
import javax.faces.component.UIComponent;
import javax.faces.component.html.HtmlCommandButton;
import javax.faces.event.MethodExpressionActionListener;
import javax.faces.webapp.UIComponentELTag;

/**
 * Auto-generated tag class.
 */
public class HtmlCommandButtonTag extends UIComponentELTag
{

  /**
   * Construct an instance of the HtmlCommandButtonTag.
   */
  public HtmlCommandButtonTag()
  {
  }

  @Override
  public String getComponentType()
  {
    return "javax.faces.HtmlCommandButton";
  }

  public String getRendererType()
  {
    return "javax.faces.Button";
  }

  private ValueExpression _immediate;
  public void setImmediate(ValueExpression immediate)
  {
    _immediate = immediate;
  }

  private ValueExpression _value;
  public void setValue(ValueExpression value)
  {
    _value = value;
  }

  private MethodExpression _actionExpression;
  public void setAction(MethodExpression actionExpression)
  {
    _actionExpression = actionExpression;
  }

  private MethodExpression _actionListener;
  public void setActionListener(MethodExpression actionListener)
  {
    _actionListener = actionListener;
  }

  private ValueExpression _style;
  public void setStyle(ValueExpression style)
  {
    _style = style;
  }

  private ValueExpression _styleClass;
  public void setStyleClass(ValueExpression styleClass)
  {
    _styleClass = styleClass;
  }

  private ValueExpression _dir;
  public void setDir(ValueExpression dir)
  {
    _dir = dir;
  }

  private ValueExpression _lang;
  public void setLang(ValueExpression lang)
  {
    _lang = lang;
  }

  private ValueExpression _title;
  public void setTitle(ValueExpression title)
  {
    _title = title;
  }

  private ValueExpression _onclick;
  public void setOnclick(ValueExpression onclick)
  {
    _onclick = onclick;
  }

  private ValueExpression _ondblclick;
  public void setOndblclick(ValueExpression ondblclick)
  {
    _ondblclick = ondblclick;
  }

  private ValueExpression _onmousedown;
  public void setOnmousedown(ValueExpression onmousedown)
  {
    _onmousedown = onmousedown;
  }

  private ValueExpression _onmouseup;
  public void setOnmouseup(ValueExpression onmouseup)
  {
    _onmouseup = onmouseup;
  }

  private ValueExpression _onmouseover;
  public void setOnmouseover(ValueExpression onmouseover)
  {
    _onmouseover = onmouseover;
  }

  private ValueExpression _onmousemove;
  public void setOnmousemove(ValueExpression onmousemove)
  {
    _onmousemove = onmousemove;
  }

  private ValueExpression _onmouseout;
  public void setOnmouseout(ValueExpression onmouseout)
  {
    _onmouseout = onmouseout;
  }

  private ValueExpression _onkeypress;
  public void setOnkeypress(ValueExpression onkeypress)
  {
    _onkeypress = onkeypress;
  }

  private ValueExpression _onkeydown;
  public void setOnkeydown(ValueExpression onkeydown)
  {
    _onkeydown = onkeydown;
  }

  private ValueExpression _onkeyup;
  public void setOnkeyup(ValueExpression onkeyup)
  {
    _onkeyup = onkeyup;
  }

  private ValueExpression _onblur;
  public void setOnblur(ValueExpression onblur)
  {
    _onblur = onblur;
  }

  private ValueExpression _onfocus;
  public void setOnfocus(ValueExpression onfocus)
  {
    _onfocus = onfocus;
  }

  private ValueExpression _onchange;
  public void setOnchange(ValueExpression onchange)
  {
    _onchange = onchange;
  }

  private ValueExpression _onselect;
  public void setOnselect(ValueExpression onselect)
  {
    _onselect = onselect;
  }

  private ValueExpression _accesskey;
  public void setAccesskey(ValueExpression accesskey)
  {
    _accesskey = accesskey;
  }

  private ValueExpression _tabindex;
  public void setTabindex(ValueExpression tabindex)
  {
    _tabindex = tabindex;
  }

  private ValueExpression _disabled;
  public void setDisabled(ValueExpression disabled)
  {
    _disabled = disabled;
  }

  private ValueExpression _readonly;
  public void setReadonly(ValueExpression readonly)
  {
    _readonly = readonly;
  }

  private ValueExpression _label;
  public void setLabel(ValueExpression label)
  {
    _label = label;
  }

  private ValueExpression _image;
  public void setImage(ValueExpression image)
  {
    _image = image;
  }

  private ValueExpression _alt;
  public void setAlt(ValueExpression alt)
  {
    _alt = alt;
  }

  private ValueExpression _type;
  public void setType(ValueExpression type)
  {
    _type = type;
  }

  @Override
  protected void setProperties(UIComponent component)
{
  if (!(component instanceof HtmlCommandButton))
  {
    throw new IllegalArgumentException("Component " + component.getClass().getName() + " is no HtmlCommandButton");
  }
  HtmlCommandButton comp = (HtmlCommandButton)component;

  super.setProperties(component);

  if (_onfocus != null) 
  {
    comp.setValueExpression("onfocus", _onfocus);
  }
  if (_title != null) 
  {
    comp.setValueExpression("title", _title);
  }
  if (_onselect != null) 
  {
    comp.setValueExpression("onselect", _onselect);
  }
  if (_onkeyup != null) 
  {
    comp.setValueExpression("onkeyup", _onkeyup);
  }
  if (_onblur != null) 
  {
    comp.setValueExpression("onblur", _onblur);
  }
  if (_onmouseup != null) 
  {
    comp.setValueExpression("onmouseup", _onmouseup);
  }
  if (_actionExpression != null) 
  {
    comp.setActionExpression(_actionExpression);
  }
  if (_value != null) 
  {
    comp.setValueExpression("value", _value);
  }
  if (_accesskey != null) 
  {
    comp.setValueExpression("accesskey", _accesskey);
  }
  if (_dir != null) 
  {
    comp.setValueExpression("dir", _dir);
  }
  if (_onkeypress != null) 
  {
    comp.setValueExpression("onkeypress", _onkeypress);
  }
  if (_disabled != null) 
  {
    comp.setValueExpression("disabled", _disabled);
  }
  if (_onmouseover != null) 
  {
    comp.setValueExpression("onmouseover", _onmouseover);
  }
  if (_image != null) 
  {
    comp.setValueExpression("image", _image);
  }
  if (_type != null) 
  {
    comp.setValueExpression("type", _type);
  }
  if (_lang != null) 
  {
    comp.setValueExpression("lang", _lang);
  }
  if (_readonly != null) 
  {
    comp.setValueExpression("readonly", _readonly);
  }
  if (_ondblclick != null) 
  {
    comp.setValueExpression("ondblclick", _ondblclick);
  }
  if (_onmousedown != null) 
  {
    comp.setValueExpression("onmousedown", _onmousedown);
  }
  if (_tabindex != null) 
  {
    comp.setValueExpression("tabindex", _tabindex);
  }
  if (_onclick != null) 
  {
    comp.setValueExpression("onclick", _onclick);
  }
  if (_style != null) 
  {
    comp.setValueExpression("style", _style);
  }
  if (_onchange != null) 
  {
    comp.setValueExpression("onchange", _onchange);
  }
  if (_label != null) 
  {
    comp.setValueExpression("label", _label);
  }
  if (_immediate != null) 
  {
    comp.setValueExpression("immediate", _immediate);
  }
  if (_onmouseout != null) 
  {
    comp.setValueExpression("onmouseout", _onmouseout);
  }
  if (_onmousemove != null) 
  {
    comp.setValueExpression("onmousemove", _onmousemove);
  }
  if (_styleClass != null) 
  {
    comp.setValueExpression("styleClass", _styleClass);
  }
  if (_onkeydown != null) 
  {
    comp.setValueExpression("onkeydown", _onkeydown);
  }
  if (_alt != null) 
  {
    comp.setValueExpression("alt", _alt);
  }
  if (_actionListener != null)
  {
    comp.addActionListener(new MethodExpressionActionListener(_actionListener));
  }
}

@Override
public void release()
{
  super.release();
  _onfocus = null;
  _title = null;
  _onselect = null;
  _onkeyup = null;
  _onblur = null;
  _onmouseup = null;
  _actionExpression = null;
  _value = null;
  _accesskey = null;
  _dir = null;
  _onkeypress = null;
  _disabled = null;
  _onmouseover = null;
  _image = null;
  _type = null;
  _lang = null;
  _readonly = null;
  _ondblclick = null;
  _onmousedown = null;
  _tabindex = null;
  _onclick = null;
  _style = null;
  _onchange = null;
  _label = null;
  _immediate = null;
  _onmouseout = null;
  _onmousemove = null;
  _styleClass = null;
  _onkeydown = null;
  _alt = null;
  _actionListener = null;
}
}
