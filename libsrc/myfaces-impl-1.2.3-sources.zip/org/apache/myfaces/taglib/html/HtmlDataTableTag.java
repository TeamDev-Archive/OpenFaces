// WARNING: This file was automatically generated. Do not edit it directly,
//          or you will lose your changes.

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
*/
package org.apache.myfaces.taglib.html;

import javax.el.ValueExpression;
import javax.faces.component.UIComponent;
import javax.faces.component.UIData;
import javax.faces.component.html.HtmlDataTable;
import javax.faces.webapp.UIComponentELTag;

/**
 * Auto-generated tag class.
 */
public class HtmlDataTableTag extends UIComponentELTag
{

  /**
   * Construct an instance of the HtmlDataTableTag.
   */
  public HtmlDataTableTag()
  {
  }

  @Override
  public String getComponentType()
  {
    return "javax.faces.HtmlDataTable";
  }

  public String getRendererType()
  {
    return "javax.faces.Table";
  }

  private ValueExpression _columnClasses;
  public void setColumnClasses(ValueExpression columnClasses)
  {
    _columnClasses = columnClasses;
  }

  private ValueExpression _footerClass;
  public void setFooterClass(ValueExpression footerClass)
  {
    _footerClass = footerClass;
  }

  private ValueExpression _headerClass;
  public void setHeaderClass(ValueExpression headerClass)
  {
    _headerClass = headerClass;
  }

  private ValueExpression _rowClasses;
  public void setRowClasses(ValueExpression rowClasses)
  {
    _rowClasses = rowClasses;
  }

  private ValueExpression _captionClass;
  public void setCaptionClass(ValueExpression captionClass)
  {
    _captionClass = captionClass;
  }

  private ValueExpression _captionStyle;
  public void setCaptionStyle(ValueExpression captionStyle)
  {
    _captionStyle = captionStyle;
  }

  private ValueExpression _style;
  public void setStyle(ValueExpression style)
  {
    _style = style;
  }

  private ValueExpression _styleClass;
  public void setStyleClass(ValueExpression styleClass)
  {
    _styleClass = styleClass;
  }

  private ValueExpression _dir;
  public void setDir(ValueExpression dir)
  {
    _dir = dir;
  }

  private ValueExpression _lang;
  public void setLang(ValueExpression lang)
  {
    _lang = lang;
  }

  private ValueExpression _title;
  public void setTitle(ValueExpression title)
  {
    _title = title;
  }

  private ValueExpression _onclick;
  public void setOnclick(ValueExpression onclick)
  {
    _onclick = onclick;
  }

  private ValueExpression _ondblclick;
  public void setOndblclick(ValueExpression ondblclick)
  {
    _ondblclick = ondblclick;
  }

  private ValueExpression _onmousedown;
  public void setOnmousedown(ValueExpression onmousedown)
  {
    _onmousedown = onmousedown;
  }

  private ValueExpression _onmouseup;
  public void setOnmouseup(ValueExpression onmouseup)
  {
    _onmouseup = onmouseup;
  }

  private ValueExpression _onmouseover;
  public void setOnmouseover(ValueExpression onmouseover)
  {
    _onmouseover = onmouseover;
  }

  private ValueExpression _onmousemove;
  public void setOnmousemove(ValueExpression onmousemove)
  {
    _onmousemove = onmousemove;
  }

  private ValueExpression _onmouseout;
  public void setOnmouseout(ValueExpression onmouseout)
  {
    _onmouseout = onmouseout;
  }

  private ValueExpression _onkeypress;
  public void setOnkeypress(ValueExpression onkeypress)
  {
    _onkeypress = onkeypress;
  }

  private ValueExpression _onkeydown;
  public void setOnkeydown(ValueExpression onkeydown)
  {
    _onkeydown = onkeydown;
  }

  private ValueExpression _onkeyup;
  public void setOnkeyup(ValueExpression onkeyup)
  {
    _onkeyup = onkeyup;
  }

  private ValueExpression _border;
  public void setBorder(ValueExpression border)
  {
    _border = border;
  }

  private ValueExpression _bgcolor;
  public void setBgcolor(ValueExpression bgcolor)
  {
    _bgcolor = bgcolor;
  }

  private ValueExpression _cellpadding;
  public void setCellpadding(ValueExpression cellpadding)
  {
    _cellpadding = cellpadding;
  }

  private ValueExpression _cellspacing;
  public void setCellspacing(ValueExpression cellspacing)
  {
    _cellspacing = cellspacing;
  }

  private ValueExpression _frame;
  public void setFrame(ValueExpression frame)
  {
    _frame = frame;
  }

  private ValueExpression _rules;
  public void setRules(ValueExpression rules)
  {
    _rules = rules;
  }

  private ValueExpression _summary;
  public void setSummary(ValueExpression summary)
  {
    _summary = summary;
  }

  private ValueExpression _width;
  public void setWidth(ValueExpression width)
  {
    _width = width;
  }

  private ValueExpression _value;
  public void setValue(ValueExpression value)
  {
    _value = value;
  }

  private java.lang.String _var;
  public void setVar(java.lang.String var)
  {
    _var = var;
  }

  private ValueExpression _rows;
  public void setRows(ValueExpression rows)
  {
    _rows = rows;
  }

  private ValueExpression _first;
  public void setFirst(ValueExpression first)
  {
    _first = first;
  }

  @Override
  protected void setProperties(UIComponent component)
{
  if (!(component instanceof HtmlDataTable))
  {
    throw new IllegalArgumentException("Component " + component.getClass().getName() + " is no HtmlDataTable");
  }
  HtmlDataTable comp = (HtmlDataTable)component;

  super.setProperties(component);

  if (_onmousedown != null) 
  {
    comp.setValueExpression("onmousedown", _onmousedown);
  }
  if (_lang != null) 
  {
    comp.setValueExpression("lang", _lang);
  }
  if (_cellpadding != null) 
  {
    comp.setValueExpression("cellpadding", _cellpadding);
  }
  if (_columnClasses != null) 
  {
    comp.setValueExpression("columnClasses", _columnClasses);
  }
  if (_value != null) 
  {
    comp.setValueExpression("value", _value);
  }
  if (_captionClass != null) 
  {
    comp.setValueExpression("captionClass", _captionClass);
  }
  if (_styleClass != null) 
  {
    comp.setValueExpression("styleClass", _styleClass);
  }
  if (_ondblclick != null) 
  {
    comp.setValueExpression("ondblclick", _ondblclick);
  }
  if (_onkeypress != null) 
  {
    comp.setValueExpression("onkeypress", _onkeypress);
  }
  if (_captionStyle != null) 
  {
    comp.setValueExpression("captionStyle", _captionStyle);
  }
  if (_width != null) 
  {
    comp.setValueExpression("width", _width);
  }
  if (_onmouseup != null) 
  {
    comp.setValueExpression("onmouseup", _onmouseup);
  }
  if (_frame != null) 
  {
    comp.setValueExpression("frame", _frame);
  }
  if (_onclick != null) 
  {
    comp.setValueExpression("onclick", _onclick);
  }
  if (_rowClasses != null) 
  {
    comp.setValueExpression("rowClasses", _rowClasses);
  }
  if (_bgcolor != null) 
  {
    comp.setValueExpression("bgcolor", _bgcolor);
  }
  if (_first != null) 
  {
    comp.setValueExpression("first", _first);
  }
  if (_cellspacing != null) 
  {
    comp.setValueExpression("cellspacing", _cellspacing);
  }
  if (_onmousemove != null) 
  {
    comp.setValueExpression("onmousemove", _onmousemove);
  }
  if (_title != null) 
  {
    comp.setValueExpression("title", _title);
  }
  if (_headerClass != null) 
  {
    comp.setValueExpression("headerClass", _headerClass);
  }
  if (_onkeyup != null) 
  {
    comp.setValueExpression("onkeyup", _onkeyup);
  }
  if (_var != null) 
  {
    comp.getAttributes().put("var", _var);
  }
  if (_style != null) 
  {
    comp.setValueExpression("style", _style);
  }
  if (_rules != null) 
  {
    comp.setValueExpression("rules", _rules);
  }
  if (_onmouseout != null) 
  {
    comp.setValueExpression("onmouseout", _onmouseout);
  }
  if (_rows != null) 
  {
    comp.setValueExpression("rows", _rows);
  }
  if (_onkeydown != null) 
  {
    comp.setValueExpression("onkeydown", _onkeydown);
  }
  if (_summary != null) 
  {
    comp.setValueExpression("summary", _summary);
  }
  if (_dir != null) 
  {
    comp.setValueExpression("dir", _dir);
  }
  if (_border != null) 
  {
    comp.setValueExpression("border", _border);
  }
  if (_footerClass != null) 
  {
    comp.setValueExpression("footerClass", _footerClass);
  }
  if (_onmouseover != null) 
  {
    comp.setValueExpression("onmouseover", _onmouseover);
  }
}

@Override
public void release()
{
  super.release();
  _onmousedown = null;
  _lang = null;
  _cellpadding = null;
  _columnClasses = null;
  _value = null;
  _captionClass = null;
  _styleClass = null;
  _ondblclick = null;
  _onkeypress = null;
  _captionStyle = null;
  _width = null;
  _onmouseup = null;
  _frame = null;
  _onclick = null;
  _rowClasses = null;
  _bgcolor = null;
  _first = null;
  _cellspacing = null;
  _onmousemove = null;
  _title = null;
  _headerClass = null;
  _onkeyup = null;
  _var = null;
  _style = null;
  _rules = null;
  _onmouseout = null;
  _rows = null;
  _onkeydown = null;
  _summary = null;
  _dir = null;
  _border = null;
  _footerClass = null;
  _onmouseover = null;
}
}
