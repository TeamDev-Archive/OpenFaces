/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 * 
 *  http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package org.apache.myfaces.shared_impl.renderkit.html.util;

import java.io.IOException;
import java.io.Writer;

/**
 * Converts Strings so that they can be used within HTML-Code.
 */
public abstract class HTMLEncoder
{
	/**
	 * Variant of {@link #encode} where encodeNewline is false and encodeNbsp is true.
	 */
	public static String encode (String string)
	{
		return encode(string, false, true);
	}

	/**
	 * Variant of {@link #encode} where encodeNbsp is true.
	 */
	public static String encode (String string, boolean encodeNewline)
	{
		return encode(string, encodeNewline, true);
	}

	/**
	 * Variant of {@link #encode} where encodeNbsp and encodeNonLatin are true 
	 */
	public static String encode (String string, boolean encodeNewline, boolean encodeSubsequentBlanksToNbsp)
	{
		return encode(string, encodeNewline, encodeSubsequentBlanksToNbsp, true);
	}

	/**
	 * Encodes the given string, so that it can be used within a html page.
	 * @param string the string to convert
	 * @param encodeNewline if true newline characters are converted to &lt;br&gt;'s
	 * @param encodeSubsequentBlanksToNbsp if true subsequent blanks are converted to &amp;nbsp;'s
	 * @param encodeNonLatin if true encode non-latin characters as numeric character references
	 */
	public static String encode (String string,
								 boolean encodeNewline,
								 boolean encodeSubsequentBlanksToNbsp,
								 boolean encodeNonLatin)
	{
		if (string == null)
		{
			return "";
		}

		StringBuilder sb = null;	//create later on demand
		String app;
		char c;
		for (int i = 0; i < string.length (); ++i)
		{
			app = null;
			c = string.charAt(i);
			
			// All characters before letters
			if ((int)c < 0x41)
			{
				switch (c)
				{
					case '"': app = "&quot;"; break;    //"
					case '&': app = "&amp;"; break;     //&
					case '<': app = "&lt;"; break;      //<
					case '>': app = "&gt;"; break;      //>
					case ' ':
						if (encodeSubsequentBlanksToNbsp &&
								(i == 0 || (i - 1 >= 0 && string.charAt(i - 1) == ' ')))
						{
							//Space at beginning or after another space
							app = "&#160;";
						}
						break;
					case '\n':
						if (encodeNewline)
						{
							app = "<br/>";
						}
						break;
				}
			} else if (encodeNonLatin && (int)c > 0x80) {
				 switch(c) {
					//german umlauts
					case '\u00E4' : app = "&auml;";  break;
					case '\u00C4' : app = "&Auml;";  break;
					case '\u00F6' : app = "&ouml;";  break;
					case '\u00D6' : app = "&Ouml;";  break;
					case '\u00FC' : app = "&uuml;";  break;
					case '\u00DC' : app = "&Uuml;";  break;
					case '\u00DF' : app = "&szlig;"; break;

					//misc
					//case 0x80: app = "&euro;"; break;  sometimes euro symbol is ascii 128, should we suport it?
					case '\u20AC': app = "&euro;";  break;
					case '\u00AB': app = "&laquo;"; break;
					case '\u00BB': app = "&raquo;"; break;
					case '\u00A0': app = "&#160;"; break;

					default :
						//encode all non basic latin characters
						app = "&#" + ((int)c) + ";";
					break;
				}
			}
			if (app != null)
			{
				if (sb == null)
				{
					sb = new StringBuilder(string.substring(0, i));
				}
				sb.append(app);
			} else {
				if (sb != null)
				{
					sb.append(c);
				}
			}
		}

		if (sb == null)
		{
			return string;
		}
		else
		{
			return sb.toString();
		}
	}

	/**
	 * Variant of {@link #encode} where encodeNewline is false and encodeNbsp is true.
	 */
	public static void encode (char[] string, int offset, int length, Writer writer) throws IOException
	{
		encode(string, offset, length, false, true, writer);
	}

	/**
	 * Variant of {@link #encode} where encodeNbsp is true.
	 */
	public static void encode (char[] string, int offset, int length, boolean encodeNewline, Writer writer) throws IOException
	{
		encode(string, offset, length, encodeNewline, true, writer);
	}

	/**
	 * Variant of {@link #encode} where encodeNbsp and encodeNonLatin are true 
	 */
	public static void encode (char[] string, int offset, int length, boolean encodeNewline, boolean encodeSubsequentBlanksToNbsp, Writer writer) throws IOException
	{
		encode(string, offset, length, encodeNewline, encodeSubsequentBlanksToNbsp, true, writer);
	}


	/**
	 * Encodes the given string, so that it can be used within a html page.
	 * @param string the string to convert
	 * @param encodeNewline if true newline characters are converted to &lt;br&gt;'s
	 * @param encodeSubsequentBlanksToNbsp if true subsequent blanks are converted to &amp;nbsp;'s
	 * @param encodeNonLatin if true encode non-latin characters as numeric character references
	 */
	public static void encode (char[] string, int offset, int length,
								 boolean encodeNewline,
								 boolean encodeSubsequentBlanksToNbsp,
								 boolean encodeNonLatin, Writer writer) throws IOException
	{
		if (string == null || length < 0 || offset >= string.length)
		{
			return;
		}
		offset = Math.max(0, offset);
		int realLength = Math.min(length, string.length - offset);

		StringBuilder sb = null;	//create later on demand
		String app;
		char c;
		
		for (int i = offset; i < offset + realLength; ++i)
		{
			app = null;
			c = string[i];

			// All characters before letters
			if ((int)c < 0x41)
			{
				switch (c)
				{
					case '"': app = "&quot;"; break;    //"
					case '&': app = "&amp;"; break;     //&
					case '<': app = "&lt;"; break;      //<
					case '>': app = "&gt;"; break;      //>
					case ' ':
						if (encodeSubsequentBlanksToNbsp &&
								(i == 0 || (i - 1 >= 0 && string[i - 1] == ' ')))
						{
							//Space at beginning or after another space
							app = "&#160;";
						}
						break;
					case '\n':
						if (encodeNewline)
						{
							app = "<br/>";
						}
						break;
				}
			} else if (encodeNonLatin && (int)c > 0x80) {
				 switch(c) {
					//german umlauts
					case '\u00E4' : app = "&auml;";  break;
					case '\u00C4' : app = "&Auml;";  break;
					case '\u00F6' : app = "&ouml;";  break;
					case '\u00D6' : app = "&Ouml;";  break;
					case '\u00FC' : app = "&uuml;";  break;
					case '\u00DC' : app = "&Uuml;";  break;
					case '\u00DF' : app = "&szlig;"; break;

					//misc
					//case 0x80: app = "&euro;"; break;  sometimes euro symbol is ascii 128, should we suport it?
					case '\u20AC': app = "&euro;";  break;
					case '\u00AB': app = "&laquo;"; break;
					case '\u00BB': app = "&raquo;"; break;
					case '\u00A0': app = "&#160;"; break;

					default :
						//encode all non basic latin characters
						app = "&#" + ((int)c) + ";";
					break;
				}
			}
			if (app != null)
			{
				if (sb == null)
				{
					sb = new StringBuilder(realLength*2);
					sb.append(string, offset, i - offset);
				}
				sb.append(app);
			} else {
				if (sb != null)
				{
					sb.append(c);
				}
			}
		}

		if (sb == null)
		{
			writer.write(string, offset, realLength);
		}
		else
		{
			writer.write(sb.toString());
		}
	}
}
