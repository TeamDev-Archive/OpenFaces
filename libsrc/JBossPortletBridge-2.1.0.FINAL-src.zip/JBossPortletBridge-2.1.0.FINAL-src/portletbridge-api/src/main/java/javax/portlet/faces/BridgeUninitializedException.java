/**
 * 
 */
package javax.portlet.faces;

/**
 * @author asmirnov
 *
 */
public class BridgeUninitializedException extends BridgeException {

	/**
	 * 
	 */
	public BridgeUninitializedException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public BridgeUninitializedException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 */
	public BridgeUninitializedException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 */
	public BridgeUninitializedException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
