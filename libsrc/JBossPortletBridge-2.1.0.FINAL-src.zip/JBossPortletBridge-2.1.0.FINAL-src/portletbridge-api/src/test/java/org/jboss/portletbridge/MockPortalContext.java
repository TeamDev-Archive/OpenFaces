/**
 * 
 */
package org.jboss.portletbridge;

import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.portlet.PortalContext;
import javax.portlet.PortletMode;
import javax.portlet.WindowState;

/**
 * @author asmirnov
 *
 */
public class MockPortalContext implements PortalContext {
	
	private Map<String,String> properties = new HashMap<String, String>();
	private static final List<PortletMode> modes = Arrays.asList(PortletMode.VIEW,PortletMode.EDIT,PortletMode.HELP);
	private static final List<WindowState> states = Arrays.asList(WindowState.NORMAL,WindowState.MINIMIZED,WindowState.MAXIMIZED);
	

	/* (non-Javadoc)
	 * @see javax.portlet.PortalContext#getPortalInfo()
	 */
	public String getPortalInfo() {
		return "Mock";
	}

	/* (non-Javadoc)
	 * @see javax.portlet.PortalContext#getProperty(java.lang.String)
	 */
	public String getProperty(String arg0) {
		return properties.get(arg0);
	}

	/* (non-Javadoc)
	 * @see javax.portlet.PortalContext#getPropertyNames()
	 */
	public Enumeration<String> getPropertyNames() {
		return Collections.enumeration(properties.keySet());
	}

	/* (non-Javadoc)
	 * @see javax.portlet.PortalContext#getSupportedPortletModes()
	 */
	public Enumeration<PortletMode> getSupportedPortletModes() {
		return Collections.enumeration(modes);
	}

	/* (non-Javadoc)
	 * @see javax.portlet.PortalContext#getSupportedWindowStates()
	 */
	public Enumeration<WindowState> getSupportedWindowStates() {
		return Collections.enumeration(states);
	}

	public void addProperty(String name,String value) {
		properties.put(name, value);
	}
}
