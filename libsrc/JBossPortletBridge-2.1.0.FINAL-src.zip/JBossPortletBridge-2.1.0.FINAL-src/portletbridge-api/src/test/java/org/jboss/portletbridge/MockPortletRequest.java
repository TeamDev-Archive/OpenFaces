/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge;

import java.security.Principal;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import javax.portlet.PortalContext;
import javax.portlet.PortletContext;
import javax.portlet.PortletMode;
import javax.portlet.PortletPreferences;
import javax.portlet.PortletRequest;
import javax.portlet.PortletSession;
import javax.portlet.WindowState;

import org.apache.shale.test.mock.MockHttpServletRequest;

/**
 * @author asmirnov
 * 
 */
public class MockPortletRequest extends MockHttpServletRequest implements
		PortletRequest {

	public static final String _01234567890 = "01234567890";
	public static final String PARAMETER_VALUE2 = "value2";
	public static final String PARAMETER_VALUE1 = "value1";
	public static final String PARAMETER = "parameter";
	public Map<String, String[]> parameters = new HashMap<String, String[]>();
	public Map<String, Object> attributes = new HashMap<String, Object>();
	public PortletMode mode = PortletMode.VIEW;
	public WindowState windowState = WindowState.NORMAL;
	public MockPortletSession portletSession = null;
	private PortletContext portletContext;
	public MockPortalContext mockPortalContext = new MockPortalContext();
	public Map<String, String[]> publicParameters = new HashMap<String, String[]>();
	public Map<String, String> properties = new HashMap<String, String>();
	public MockPortletPreferences preferences;

	public MockPortletRequest(PortletContext portletContext) {
		parameters.put(PARAMETER, new String[] { PARAMETER_VALUE1,
				PARAMETER_VALUE2 });
		preferences = new MockPortletPreferences();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getAttribute(java.lang.String)
	 */
	public Object getAttribute(String arg0) {
		return attributes.get(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getAttributeNames()
	 */
	public Enumeration<String> getAttributeNames() {
		return Collections.enumeration(attributes.keySet());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getAuthType()
	 */
	public String getAuthType() {
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getContextPath()
	 */
	public String getContextPath() {
		return "/context";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getLocale()
	 */
	public Locale getLocale() {
		return Locale.US;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getLocales()
	 */
	public Enumeration<Locale> getLocales() {
		return Collections.enumeration(Collections.singleton(getLocale()));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getParameter(java.lang.String)
	 */
	public String getParameter(String name) {
		String result = null;
		String[] vals = parameters.get(name);
		if (null != vals && vals.length != 0) {
			result = vals[0];
		}
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getParameterMap()
	 */
	public Map<String, String[]> getParameterMap() {
		return parameters;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getParameterNames()
	 */
	public Enumeration<String> getParameterNames() {
		return Collections.enumeration(parameters.keySet());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getParameterValues(java.lang.String)
	 */
	public String[] getParameterValues(String arg0) {
		return parameters.get(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getPrivateParameterMap()
	 */
	public Map<String, String[]> getPrivateParameterMap() {
		return parameters;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getPublicParameterMap()
	 */
	public Map<String, String[]> getPublicParameterMap() {
		return publicParameters;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getWindowID()
	 */
	public String getWindowID() {
		return _01234567890;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getPortalContext()
	 */
	public PortalContext getPortalContext() {
		return mockPortalContext;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getPortletMode()
	 */
	public PortletMode getPortletMode() {
		return mode;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getPortletSession()
	 */
	public PortletSession getPortletSession() {
		return getPortletSession(true);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getPortletSession(boolean)
	 */
	public PortletSession getPortletSession(boolean arg0) {
		if (arg0 && null == portletSession) {
			portletSession = new MockPortletSession(portletContext);
		}
		return portletSession;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getPreferences()
	 */
	public PortletPreferences getPreferences() {
		return preferences;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getProperties(java.lang.String)
	 */
	public Enumeration<String> getProperties(String arg0) {
		return Collections.enumeration(Collections.singleton(properties.get(arg0)));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getProperty(java.lang.String)
	 */
	public String getProperty(String arg0) {
		return properties.get(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getPropertyNames()
	 */
	public Enumeration<String> getPropertyNames() {
		// TODO Auto-generated method stub
		return Collections.enumeration(properties.keySet());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getRemoteUser()
	 */
	public String getRemoteUser() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getRequestedSessionId()
	 */
	public String getRequestedSessionId() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getResponseContentType()
	 */
	public String getResponseContentType() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getResponseContentTypes()
	 */
	public Enumeration getResponseContentTypes() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getScheme()
	 */
	public String getScheme() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getServerName()
	 */
	public String getServerName() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getServerPort()
	 */
	public int getServerPort() {
		return 80;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getUserPrincipal()
	 */
	public Principal getUserPrincipal() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#getWindowState()
	 */
	public WindowState getWindowState() {
		return windowState;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.portlet.PortletRequest#isPortletModeAllowed(javax.portlet.PortletMode
	 * )
	 */
	public boolean isPortletModeAllowed(PortletMode arg0) {
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#isRequestedSessionIdValid()
	 */
	public boolean isRequestedSessionIdValid() {
		// TODO Auto-generated method stub
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#isSecure()
	 */
	public boolean isSecure() {
		// TODO Auto-generated method stub
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#isUserInRole(java.lang.String)
	 */
	public boolean isUserInRole(String arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.portlet.PortletRequest#isWindowStateAllowed(javax.portlet.WindowState
	 * )
	 */
	public boolean isWindowStateAllowed(WindowState arg0) {
		// TODO Auto-generated method stub
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#removeAttribute(java.lang.String)
	 */
	public void removeAttribute(String arg0) {
		attributes.remove(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.PortletRequest#setAttribute(java.lang.String,
	 * java.lang.Object)
	 */
	public void setAttribute(String arg0, Object arg1) {
		attributes.put(arg0, arg1);
	}
}
