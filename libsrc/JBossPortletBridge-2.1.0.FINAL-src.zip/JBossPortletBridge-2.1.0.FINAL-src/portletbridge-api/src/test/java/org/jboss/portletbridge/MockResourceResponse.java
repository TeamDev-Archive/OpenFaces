/**
 * 
 */
package org.jboss.portletbridge;

import java.io.IOException;
import java.io.OutputStream;

import javax.portlet.CacheControl;
import javax.portlet.PortletURL;
import javax.portlet.ResourceResponse;
import javax.portlet.ResourceURL;

/**
 * @author asmirnov
 *
 */
public class MockResourceResponse extends MockPortletResponse implements
		ResourceResponse {

	/* (non-Javadoc)
	 * @see javax.portlet.ResourceResponse#createActionURL()
	 */
	public PortletURL createActionURL() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.portlet.ResourceResponse#createRenderURL()
	 */
	public PortletURL createRenderURL() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.portlet.ResourceResponse#createResourceURL()
	 */
	public ResourceURL createResourceURL() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.portlet.MimeResponse#getCacheControl()
	 */
	public CacheControl getCacheControl() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.portlet.MimeResponse#getPortletOutputStream()
	 */
	public OutputStream getPortletOutputStream() throws IOException {
		// TODO Auto-generated method stub
		return null;
	}

}
