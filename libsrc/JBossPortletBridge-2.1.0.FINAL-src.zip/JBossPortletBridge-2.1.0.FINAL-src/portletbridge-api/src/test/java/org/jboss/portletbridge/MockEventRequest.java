/**
 * 
 */
package org.jboss.portletbridge;

import javax.portlet.Event;
import javax.portlet.EventRequest;
import javax.portlet.PortletContext;

/**
 * @author asmirnov
 *
 */
public class MockEventRequest extends MockPortletRequest implements
		EventRequest {

	/**
	 * @param portletContext
	 */
	public MockEventRequest(PortletContext portletContext) {
		super(portletContext);
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see javax.portlet.EventRequest#getEvent()
	 */
	public Event getEvent() {
		// TODO Auto-generated method stub
		return null;
	}

}
