/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Collection;
import java.util.Collections;
import java.util.ArrayList;

import javax.portlet.PortletConfig;
import javax.portlet.PortletContext;
import javax.xml.namespace.QName;

/**
 * @author asmirnov
 *
 */
public class MockPortletConfig implements PortletConfig {

   /* (non-Javadoc)
	 * @see javax.portlet.PortletConfig#getContainerRuntimeOptions()
	 */
	public Map<String, String[]> getContainerRuntimeOptions() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.portlet.PortletConfig#getDefaultNamespace()
	 */
	public String getDefaultNamespace() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.portlet.PortletConfig#getProcessingEventQNames()
	 */
	public Enumeration<QName> getProcessingEventQNames() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.portlet.PortletConfig#getPublicRenderParameterNames()
	 */
	public Enumeration<String> getPublicRenderParameterNames() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.portlet.PortletConfig#getPublishingEventQNames()
	 */
	public Enumeration<QName> getPublishingEventQNames() {
		// TODO Auto-generated method stub
		return null;
	}



private final PortletContext context;

   private Map<String, String> parameters;
   private Collection<Locale> locales;

   private String portletName="generic";


   /* (non-Javadoc)
    * @see javax.portlet.PortletConfig#getInitParameter(java.lang.String)
    */
   public String getInitParameter(String arg0) {

      return parameters.get(arg0);
   }

   /* (non-Javadoc)
    * @see javax.portlet.PortletConfig#getInitParameterNames()
    */
   public Enumeration getInitParameterNames() {
      return new IteratorEnumeration(parameters.keySet().iterator());
   }

   /* (non-Javadoc)
	 * @see javax.portlet.PortletConfig#getSupportedLocales()
	 */
      public Enumeration<Locale> getSupportedLocales() {
        return Collections.enumeration(locales);
      }

   /* (non-Javadoc)
    * @see javax.portlet.PortletConfig#getPortletContext()
    */
   public PortletContext getPortletContext() {
      return context;
   }

   /* (non-Javadoc)
    * @see javax.portlet.PortletConfig#getPortletName()
    */
   public String getPortletName() {
      // TODO Auto-generated method stub
      return this.portletName;
   }

   /* (non-Javadoc)
    * @see javax.portlet.PortletConfig#getResourceBundle(java.util.Locale)
    */
   public ResourceBundle getResourceBundle(Locale arg0) {
      return ResourceBundle.getBundle("javax.portlet.faces.bundle", arg0);
   }

   /**
    * @param portletName the portletName to set
    */
   public void setPortletName(String name) {
      this.portletName = name;
   }

   public void addInitParameter(String name, String value){
      this.parameters.put(name, value);
   }

   public void addSupportedLocale(Locale locale){
      this.locales.add(locale);
   }

   public MockPortletConfig(PortletContext context) {
      super();
      this.context = context;
      parameters = new HashMap<String, String>();
      locales = new ArrayList();
   }

}
