/**
 * 
 */
package org.jboss.portletbridge;

import java.io.IOException;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.portlet.PortletPreferences;
import javax.portlet.ReadOnlyException;
import javax.portlet.ValidatorException;

/**
 * @author asmirnov
 *
 */
public class MockPortletPreferences implements PortletPreferences {

	public Map<String, String[]> preferences = new HashMap<String, String[]>();

	/* (non-Javadoc)
	 * @see javax.portlet.PortletPreferences#getMap()
	 */
	public Map<String, String[]> getMap() {
		return preferences;
	}

	/* (non-Javadoc)
	 * @see javax.portlet.PortletPreferences#getNames()
	 */
	public Enumeration<String> getNames() {
		return Collections.enumeration(preferences.keySet());
	}

	/* (non-Javadoc)
	 * @see javax.portlet.PortletPreferences#getValue(java.lang.String, java.lang.String)
	 */
	public String getValue(String arg0, String arg1) {
		String[] values = preferences.get(arg0);
		if(null == values && values.length !=0){
			return values[0];
		}
		return arg1;
	}

	/* (non-Javadoc)
	 * @see javax.portlet.PortletPreferences#getValues(java.lang.String, java.lang.String[])
	 */
	public String[] getValues(String arg0, String[] arg1) {
		String[] values = preferences.get(arg0);
		if(null == values){
			values = arg1;
		}
		return values;
	}

	/* (non-Javadoc)
	 * @see javax.portlet.PortletPreferences#isReadOnly(java.lang.String)
	 */
	public boolean isReadOnly(String arg0) {
		return false;
	}

	/* (non-Javadoc)
	 * @see javax.portlet.PortletPreferences#reset(java.lang.String)
	 */
	public void reset(String arg0) throws ReadOnlyException {
		preferences.remove(arg0);
	}

	/* (non-Javadoc)
	 * @see javax.portlet.PortletPreferences#setValue(java.lang.String, java.lang.String)
	 */
	public void setValue(String arg0, String arg1) throws ReadOnlyException {
		setValues(arg0, new String[]{arg1});
	}

	/* (non-Javadoc)
	 * @see javax.portlet.PortletPreferences#setValues(java.lang.String, java.lang.String[])
	 */
	public void setValues(String arg0, String[] arg1) throws ReadOnlyException {
		preferences.put(arg0, arg1);
	}

	/* (non-Javadoc)
	 * @see javax.portlet.PortletPreferences#store()
	 */
	public void store() throws IOException, ValidatorException {

	}

}
