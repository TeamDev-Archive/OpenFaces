/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge;

import javax.portlet.PortletResponse;
import javax.servlet.http.Cookie;

import org.apache.shale.test.mock.MockHttpServletResponse;
import org.w3c.dom.DOMException;
import org.w3c.dom.Element;

/**
 * @author asmirnov
 *
 */
public class MockPortletResponse extends MockHttpServletResponse implements PortletResponse {
    /* (non-Javadoc)
     * @see javax.portlet.PortletResponse#addProperty(java.lang.String, java.lang.String)
     */
    public void addProperty(String arg0, String arg1) {
   // TODO Auto-generated method stub
    }

    /* (non-Javadoc)
     * @see javax.portlet.PortletResponse#encodeURL(java.lang.String)
     */
    public String encodeURL(String arg0) {
   // TODO Auto-generated method stub
   return null;
    }

    /* (non-Javadoc)
     * @see javax.portlet.PortletResponse#setProperty(java.lang.String, java.lang.String)
     */
    public void setProperty(String arg0, String arg1) {
   // TODO Auto-generated method stub
    }

	/* (non-Javadoc)
	 * @see javax.portlet.PortletResponse#addProperty(javax.servlet.http.Cookie)
	 */
	public void addProperty(Cookie arg0) {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see javax.portlet.PortletResponse#addProperty(java.lang.String, org.w3c.dom.Element)
	 */
	public void addProperty(String arg0, Element arg1) {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see javax.portlet.PortletResponse#createElement(java.lang.String)
	 */
	public Element createElement(String arg0) throws DOMException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.portlet.PortletResponse#getNamespace()
	 */
	public String getNamespace() {
		// TODO Auto-generated method stub
		return null;
	}
    
}
