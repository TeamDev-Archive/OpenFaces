/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge;

import java.io.IOException;
import java.io.Serializable;
import java.util.Map;
import javax.portlet.ActionResponse;
import javax.portlet.PortletMode;
import javax.portlet.PortletModeException;
import javax.portlet.WindowState;
import javax.portlet.WindowStateException;
import javax.xml.namespace.QName;

/**
 * @author asmirnov
 *
 */
public class MockActionResponse extends MockPortletResponse implements
   ActionResponse {
    /* (non-Javadoc)
	 * @see javax.portlet.ActionResponse#sendRedirect(java.lang.String, java.lang.String)
	 */
	public void sendRedirect(String arg0, String arg1) throws IOException {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see javax.portlet.StateAwareResponse#getPortletMode()
	 */
	public PortletMode getPortletMode() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.portlet.StateAwareResponse#getRenderParameterMap()
	 */
	public Map<String, String[]> getRenderParameterMap() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.portlet.StateAwareResponse#getWindowState()
	 */
	public WindowState getWindowState() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.portlet.StateAwareResponse#removePublicRenderParameter(java.lang.String)
	 */
	public void removePublicRenderParameter(String arg0) {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see javax.portlet.StateAwareResponse#setEvent(javax.xml.namespace.QName, java.io.Serializable)
	 */
	public void setEvent(QName arg0, Serializable arg1) {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see javax.portlet.StateAwareResponse#setEvent(java.lang.String, java.io.Serializable)
	 */
	public void setEvent(String arg0, Serializable arg1) {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
     * @see javax.portlet.ActionResponse#sendRedirect(java.lang.String)
     */
    public void sendRedirect(String arg0) {
   // TODO Auto-generated method stub
    }

    /* (non-Javadoc)
     * @see javax.portlet.ActionResponse#setPortletMode(javax.portlet.PortletMode)
     */
    public void setPortletMode(PortletMode arg0) throws PortletModeException {
   // TODO Auto-generated method stub
    }

    /* (non-Javadoc)
     * @see javax.portlet.ActionResponse#setRenderParameter(java.lang.String, java.lang.String)
     */
    public void setRenderParameter(String arg0, String arg1) {
   // TODO Auto-generated method stub
    }

    /* (non-Javadoc)
     * @see javax.portlet.ActionResponse#setRenderParameter(java.lang.String, java.lang.String[])
     */
    public void setRenderParameter(String arg0, String[] arg1) {
   // TODO Auto-generated method stub
    }

    /* (non-Javadoc)
     * @see javax.portlet.ActionResponse#setRenderParameters(java.util.Map)
     */
    public void setRenderParameters(Map arg0) {
   // TODO Auto-generated method stub
    }

    /* (non-Javadoc)
     * @see javax.portlet.ActionResponse#setWindowState(javax.portlet.WindowState)
     */
    public void setWindowState(WindowState arg0) throws WindowStateException {
   // TODO Auto-generated method stub
    }
}
