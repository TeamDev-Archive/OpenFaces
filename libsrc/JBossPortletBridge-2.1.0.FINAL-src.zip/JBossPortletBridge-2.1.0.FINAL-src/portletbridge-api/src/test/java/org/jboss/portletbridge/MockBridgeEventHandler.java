/**
 * 
 */
package org.jboss.portletbridge;

import java.util.ArrayList;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.portlet.Event;
import javax.portlet.faces.BridgeEventHandler;
import javax.portlet.faces.event.EventNavigationResult;

/**
 * @author asmirnov
 *
 */
public class MockBridgeEventHandler implements BridgeEventHandler {
	
	private List<Event> events = new ArrayList<Event>();
	
	private EventNavigationResult defaultResult = new EventNavigationResult();

	/* (non-Javadoc)
	 * @see javax.portlet.faces.BridgeEventHandler#handleEvent(javax.faces.context.FacesContext, javax.portlet.Event)
	 */
	public EventNavigationResult handleEvent(FacesContext context, Event event) {
		events.add(event);
		return defaultResult;
	}

	/**
	 * @return the defaultResult
	 */
	public EventNavigationResult getDefaultResult() {
		return defaultResult;
	}

	/**
	 * @param defaultResult the defaultResult to set
	 */
	public void setDefaultResult(EventNavigationResult defaultResult) {
		this.defaultResult = defaultResult;
	}

	/**
	 * @return the events
	 */
	public List<Event> getEvents() {
		return events;
	}

}
