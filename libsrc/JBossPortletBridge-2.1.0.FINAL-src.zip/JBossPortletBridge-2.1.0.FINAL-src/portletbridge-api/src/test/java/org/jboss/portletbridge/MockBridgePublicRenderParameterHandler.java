/**
 * 
 */
package org.jboss.portletbridge;

import javax.faces.context.FacesContext;
import javax.portlet.faces.BridgePublicRenderParameterHandler;

/**
 * @author asmirnov
 *
 */
public class MockBridgePublicRenderParameterHandler implements
		BridgePublicRenderParameterHandler {
	
	public int processCount = 0;

	/* (non-Javadoc)
	 * @see javax.portlet.faces.BridgePublicRenderParameterHandler#processUpdates(javax.faces.context.FacesContext)
	 */
	public void processUpdates(FacesContext context) {
		processCount++;

	}

}
