/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge;

import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.portlet.PortletContext;
import javax.portlet.PortletSession;

/**
 * @author asmirnov
 *
 */
public class MockPortletSession implements PortletSession {

   private static final String ID = "foobar";

   private Map<String, Object> portletScopeAttributes;

   private Map<String, Object> appScopeAttributes;

   private long created;

   private PortletContext portletContext;

   private int maxInactive = 0;

   public MockPortletSession(PortletContext pc) {
      portletContext = pc;
      portletScopeAttributes = new HashMap<String, Object>();
      appScopeAttributes = new HashMap<String, Object>();
      created = System.currentTimeMillis();
   }

   private Map<String,Object> getAttributesMap(int scope) {
      return scope == PORTLET_SCOPE?portletScopeAttributes:appScopeAttributes;
   }
   /* (non-Javadoc)
    * @see javax.portlet.PortletSession#getAttribute(java.lang.String)
    */
   public Object getAttribute(String arg0) {
      // TODO Auto-generated method stub
      return getAttribute(arg0, PORTLET_SCOPE);
   }

   /* (non-Javadoc)
    * @see javax.portlet.PortletSession#getAttribute(java.lang.String, int)
    */
   public Object getAttribute(String arg0, int arg1) {
      return getAttributesMap(arg1).get(arg0);
   }

   /* (non-Javadoc)
    * @see javax.portlet.PortletSession#getAttributeNames()
    */
   public Enumeration getAttributeNames() {
      // TODO Auto-generated method stub
      return getAttributeNames(PORTLET_SCOPE);
   }

   /* (non-Javadoc)
    * @see javax.portlet.PortletSession#getAttributeNames(int)
    */
   public Enumeration getAttributeNames(int arg0) {
      // TODO Auto-generated method stub
      return Collections.enumeration(getAttributesMap(arg0).keySet());
   }

   /* (non-Javadoc)
    * @see javax.portlet.PortletSession#getCreationTime()
    */
   public long getCreationTime() {
      // TODO Auto-generated method stub
      return created;
   }

   /* (non-Javadoc)
    * @see javax.portlet.PortletSession#getId()
    */
   public String getId() {
      // TODO Auto-generated method stub
      return ID;
   }

   /* (non-Javadoc)
    * @see javax.portlet.PortletSession#getLastAccessedTime()
    */
   public long getLastAccessedTime() {
      // TODO Auto-generated method stub
      return 0;
   }

   /* (non-Javadoc)
    * @see javax.portlet.PortletSession#getMaxInactiveInterval()
    */
   public int getMaxInactiveInterval() {
      // TODO Auto-generated method stub
      return maxInactive;
   }

   /* (non-Javadoc)
    * @see javax.portlet.PortletSession#getPortletContext()
    */
   public PortletContext getPortletContext() {
      // TODO Auto-generated method stub
      return portletContext;
   }

   /* (non-Javadoc)
    * @see javax.portlet.PortletSession#invalidate()
    */
   public void invalidate() {
      // TODO Auto-generated method stub

   }

   /* (non-Javadoc)
    * @see javax.portlet.PortletSession#isNew()
    */
   public boolean isNew() {
      // TODO Auto-generated method stub
      return false;
   }

   /* (non-Javadoc)
    * @see javax.portlet.PortletSession#removeAttribute(java.lang.String)
    */
   public void removeAttribute(String arg0) {
      removeAttribute(arg0, PORTLET_SCOPE);

   }

   /* (non-Javadoc)
    * @see javax.portlet.PortletSession#removeAttribute(java.lang.String, int)
    */
   public void removeAttribute(String arg0, int arg1) {
      getAttributesMap(arg1).remove(arg0);

   }

   /* (non-Javadoc)
    * @see javax.portlet.PortletSession#setAttribute(java.lang.String, java.lang.Object)
    */
   public void setAttribute(String arg0, Object arg1) {
      setAttribute(arg0, arg1, PORTLET_SCOPE);

   }

   /* (non-Javadoc)
    * @see javax.portlet.PortletSession#setAttribute(java.lang.String, java.lang.Object, int)
    */
   public void setAttribute(String arg0, Object arg1, int arg2) {
      getAttributesMap(arg2).put(arg0, arg1);

   }

   /* (non-Javadoc)
    * @see javax.portlet.PortletSession#setMaxInactiveInterval(int)
    */
   public void setMaxInactiveInterval(int arg0) {
      maxInactive  = arg0;
   }

/* (non-Javadoc)
 * @see javax.portlet.PortletSession#getAttributeMap()
 */
public Map<String, Object> getAttributeMap() {
	// TODO Auto-generated method stub
	return null;
}

/* (non-Javadoc)
 * @see javax.portlet.PortletSession#getAttributeMap(int)
 */
public Map<String, Object> getAttributeMap(int arg0) {
	// TODO Auto-generated method stub
	return null;
}

}
