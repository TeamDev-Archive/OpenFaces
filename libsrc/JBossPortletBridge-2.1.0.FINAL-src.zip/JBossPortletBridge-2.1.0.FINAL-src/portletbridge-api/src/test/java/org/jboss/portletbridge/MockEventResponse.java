/**
 * 
 */
package org.jboss.portletbridge;

import java.io.Serializable;
import java.util.Map;

import javax.portlet.EventRequest;
import javax.portlet.EventResponse;
import javax.portlet.PortletMode;
import javax.portlet.PortletModeException;
import javax.portlet.WindowState;
import javax.portlet.WindowStateException;
import javax.xml.namespace.QName;

/**
 * @author asmirnov
 *
 */
public class MockEventResponse extends MockPortletResponse implements
		EventResponse {

	/* (non-Javadoc)
	 * @see javax.portlet.EventResponse#setRenderParameters(javax.portlet.EventRequest)
	 */
	public void setRenderParameters(EventRequest arg0) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see javax.portlet.StateAwareResponse#getPortletMode()
	 */
	public PortletMode getPortletMode() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.portlet.StateAwareResponse#getRenderParameterMap()
	 */
	public Map<String, String[]> getRenderParameterMap() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.portlet.StateAwareResponse#getWindowState()
	 */
	public WindowState getWindowState() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.portlet.StateAwareResponse#removePublicRenderParameter(java.lang.String)
	 */
	public void removePublicRenderParameter(String arg0) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see javax.portlet.StateAwareResponse#setEvent(javax.xml.namespace.QName, java.io.Serializable)
	 */
	public void setEvent(QName arg0, Serializable arg1) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see javax.portlet.StateAwareResponse#setEvent(java.lang.String, java.io.Serializable)
	 */
	public void setEvent(String arg0, Serializable arg1) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see javax.portlet.StateAwareResponse#setPortletMode(javax.portlet.PortletMode)
	 */
	public void setPortletMode(PortletMode arg0) throws PortletModeException {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see javax.portlet.StateAwareResponse#setRenderParameter(java.lang.String, java.lang.String)
	 */
	public void setRenderParameter(String arg0, String arg1) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see javax.portlet.StateAwareResponse#setRenderParameter(java.lang.String, java.lang.String[])
	 */
	public void setRenderParameter(String arg0, String[] arg1) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see javax.portlet.StateAwareResponse#setRenderParameters(java.util.Map)
	 */
	public void setRenderParameters(Map<String, String[]> arg0) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see javax.portlet.StateAwareResponse#setWindowState(javax.portlet.WindowState)
	 */
	public void setWindowState(WindowState arg0) throws WindowStateException {
		// TODO Auto-generated method stub

	}

}
