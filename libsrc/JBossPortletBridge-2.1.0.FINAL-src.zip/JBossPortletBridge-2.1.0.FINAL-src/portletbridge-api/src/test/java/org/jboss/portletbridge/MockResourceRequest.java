/**
 * 
 */
package org.jboss.portletbridge;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

import javax.portlet.PortletContext;
import javax.portlet.ResourceRequest;

/**
 * @author asmirnov
 *
 */
public class MockResourceRequest extends MockPortletRequest implements
		ResourceRequest {

	public MockResourceRequest(PortletContext portletContext) {
		super(portletContext);
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see javax.portlet.ResourceRequest#getCacheability()
	 */
	public String getCacheability() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.portlet.ResourceRequest#getETag()
	 */
	public String getETag() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.portlet.ResourceRequest#getPrivateRenderParameterMap()
	 */
	public Map<String, String[]> getPrivateRenderParameterMap() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.portlet.ResourceRequest#getResourceID()
	 */
	public String getResourceID() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.portlet.ClientDataRequest#getPortletInputStream()
	 */
	public InputStream getPortletInputStream() throws IOException {
		// TODO Auto-generated method stub
		return null;
	}

}
