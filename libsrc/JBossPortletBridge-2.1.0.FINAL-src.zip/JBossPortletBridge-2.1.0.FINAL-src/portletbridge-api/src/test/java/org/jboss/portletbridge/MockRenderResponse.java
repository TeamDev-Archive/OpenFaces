/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Collection;
import java.util.Locale;

import javax.portlet.CacheControl;
import javax.portlet.PortletMode;
import javax.portlet.PortletURL;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceURL;

/**
 * @author asmirnov
 *
 */
public class MockRenderResponse extends MockPortletResponse implements
   RenderResponse {
    /* (non-Javadoc)
     * @see javax.portlet.RenderResponse#createActionURL()
     */
    public PortletURL createActionURL() {
   // TODO Auto-generated method stub
   return null;
    }

    /* (non-Javadoc)
     * @see javax.portlet.RenderResponse#createRenderURL()
     */
    public PortletURL createRenderURL() {
   // TODO Auto-generated method stub
   return null;
    }

    /* (non-Javadoc)
     * @see javax.portlet.RenderResponse#flushBuffer()
     */
    public void flushBuffer() {
   // TODO Auto-generated method stub
    }

    /* (non-Javadoc)
     * @see javax.portlet.RenderResponse#getBufferSize()
     */
    public int getBufferSize() {
   // TODO Auto-generated method stub
   return 0;
    }

    /* (non-Javadoc)
     * @see javax.portlet.RenderResponse#getCharacterEncoding()
     */
    public String getCharacterEncoding() {
   // TODO Auto-generated method stub
   return null;
    }

    /* (non-Javadoc)
     * @see javax.portlet.RenderResponse#getContentType()
     */
    public String getContentType() {
   // TODO Auto-generated method stub
   return null;
    }

    /* (non-Javadoc)
     * @see javax.portlet.RenderResponse#getLocale()
     */
    public Locale getLocale() {
   // TODO Auto-generated method stub
   return null;
    }

    /* (non-Javadoc)
     * @see javax.portlet.RenderResponse#getNamespace()
     */
    public String getNamespace() {
   // TODO Auto-generated method stub
   return null;
    }

    /* (non-Javadoc)
     * @see javax.portlet.RenderResponse#getPortletOutputStream()
     */
    public OutputStream getPortletOutputStream() throws IOException {
   // TODO Auto-generated method stub
   return null;
    }

    /* (non-Javadoc)
     * @see javax.portlet.RenderResponse#getWriter()
     */
    public PrintWriter getWriter() throws IOException {
   // TODO Auto-generated method stub
   return null;
    }

    /* (non-Javadoc)
     * @see javax.portlet.RenderResponse#isCommitted()
     */
    public boolean isCommitted() {
   // TODO Auto-generated method stub
   return false;
    }

    /* (non-Javadoc)
     * @see javax.portlet.RenderResponse#reset()
     */
    public void reset() {
   // TODO Auto-generated method stub
    }

    /* (non-Javadoc)
     * @see javax.portlet.RenderResponse#resetBuffer()
     */
    public void resetBuffer() {
   // TODO Auto-generated method stub
    }

    /* (non-Javadoc)
     * @see javax.portlet.RenderResponse#setBufferSize(int)
     */
    public void setBufferSize(int arg0) {
   // TODO Auto-generated method stub
    }

    /* (non-Javadoc)
     * @see javax.portlet.RenderResponse#setContentType(java.lang.String)
     */
    public void setContentType(String arg0) {
   // TODO Auto-generated method stub
    }

    /* (non-Javadoc)
     * @see javax.portlet.RenderResponse#setTitle(java.lang.String)
     */
    public void setTitle(String arg0) {
   // TODO Auto-generated method stub
    }

	/* (non-Javadoc)
	 * @see javax.portlet.MimeResponse#createResourceURL()
	 */
	public ResourceURL createResourceURL() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.portlet.MimeResponse#getCacheControl()
	 */
	public CacheControl getCacheControl() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.portlet.RenderResponse#setNextPossiblePortletModes(java.util.Collection)
	 */
	public void setNextPossiblePortletModes(Collection<PortletMode> arg0) {
		// TODO Auto-generated method stub
		
	}
}
