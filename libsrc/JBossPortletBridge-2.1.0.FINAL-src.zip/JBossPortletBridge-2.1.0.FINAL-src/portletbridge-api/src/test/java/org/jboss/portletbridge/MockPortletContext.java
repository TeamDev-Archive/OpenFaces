/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge;

import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Set;
import javax.portlet.PortletContext;
import javax.portlet.PortletRequestDispatcher;

import org.apache.shale.test.mock.MockServletContext;

/**
 * @author asmirnov
 *
 */
public class MockPortletContext implements PortletContext {
    public static final String PORTLET_INIT_VALUE = "portlet_init_value";
    public static final String INIT_PARAMETER = "init_parameter";
    
    
    private MockServletContext servletContext;
    

    public MockPortletContext(MockServletContext sc) {
       servletContext = sc;
   }
    /* (non-Javadoc)
     * @see javax.portlet.PortletContext#getAttribute(java.lang.String)
     */
    public Object getAttribute(String arg0) {
   return servletContext.getAttribute(arg0);
    }

    /* (non-Javadoc)
     * @see javax.portlet.PortletContext#getAttributeNames()
     */
    public Enumeration getAttributeNames() {
   return servletContext.getAttributeNames();
    }

    /* (non-Javadoc)
     * @see javax.portlet.PortletContext#getInitParameter(java.lang.String)
     */
    public String getInitParameter(String arg0) {
   return servletContext.getInitParameter(arg0);
    }

    /* (non-Javadoc)
     * @see javax.portlet.PortletContext#getInitParameterNames()
     */
    public Enumeration getInitParameterNames() {
   return servletContext.getInitParameterNames();
    }

    /* (non-Javadoc)
     * @see javax.portlet.PortletContext#getMajorVersion()
     */
    public int getMajorVersion() {
   // TODO Auto-generated method stub
   return 1;
    }

    /* (non-Javadoc)
     * @see javax.portlet.PortletContext#getMimeType(java.lang.String)
     */
    public String getMimeType(String arg0) {
       // TODO Auto-generated method stub
       return servletContext.getMimeType(arg0);
    }

    /* (non-Javadoc)
     * @see javax.portlet.PortletContext#getMinorVersion()
     */
    public int getMinorVersion() {
   // TODO Auto-generated method stub
   return 0;
    }

    /* (non-Javadoc)
     * @see javax.portlet.PortletContext#getNamedDispatcher(java.lang.String)
     */
    public PortletRequestDispatcher getNamedDispatcher(String arg0) {
   // TODO Auto-generated method stub
   return null;
    }

    /* (non-Javadoc)
     * @see javax.portlet.PortletContext#getPortletContextName()
     */
    public String getPortletContextName() {
   // TODO Auto-generated method stub
   return "testPortlet";
    }

    /* (non-Javadoc)
     * @see javax.portlet.PortletContext#getRealPath(java.lang.String)
     */
    public String getRealPath(String arg0) {
   // TODO Auto-generated method stub
   return servletContext.getRealPath(arg0);
    }

    /* (non-Javadoc)
     * @see javax.portlet.PortletContext#getRequestDispatcher(java.lang.String)
     */
    public PortletRequestDispatcher getRequestDispatcher(String arg0) {
   // TODO Auto-generated method stub
   return null;
    }

    /* (non-Javadoc)
     * @see javax.portlet.PortletContext#getResource(java.lang.String)
     */
    public URL getResource(String arg0) throws MalformedURLException {
   // TODO Auto-generated method stub
   return servletContext.getResource(arg0);
    }

    /* (non-Javadoc)
     * @see javax.portlet.PortletContext#getResourceAsStream(java.lang.String)
     */
    public InputStream getResourceAsStream(String arg0) {
   // TODO Auto-generated method stub
   return servletContext.getResourceAsStream(arg0);
    }

    /* (non-Javadoc)
     * @see javax.portlet.PortletContext#getResourcePaths(java.lang.String)
     */
    public Set getResourcePaths(String arg0) {
   // TODO Auto-generated method stub
   return servletContext.getResourcePaths(arg0);
    }

    /* (non-Javadoc)
     * @see javax.portlet.PortletContext#getServerInfo()
     */
    public String getServerInfo() {
   // TODO Auto-generated method stub
   return servletContext.getServerInfo();
    }

    /* (non-Javadoc)
     * @see javax.portlet.PortletContext#log(java.lang.String)
     */
    public void log(String arg0) {
   // TODO Auto-generated method stub
       servletContext.log(arg0);
    }

    /* (non-Javadoc)
     * @see javax.portlet.PortletContext#log(java.lang.String, java.lang.Throwable)
     */
    public void log(String arg0, Throwable arg1) {
   // TODO Auto-generated method stub
       servletContext.log(arg0, arg1);
    }

    /* (non-Javadoc)
     * @see javax.portlet.PortletContext#removeAttribute(java.lang.String)
     */
    public void removeAttribute(String arg0) {
   servletContext.removeAttribute(arg0);
    }

    /* (non-Javadoc)
     * @see javax.portlet.PortletContext#setAttribute(java.lang.String, java.lang.Object)
     */
    public void setAttribute(String arg0, Object arg1) {
   servletContext.setAttribute(arg0, arg1);
    }
    
    public void setInitParameter(String name, String value) {
       servletContext.addInitParameter(name, value);
   }
	/* (non-Javadoc)
	 * @see javax.portlet.PortletContext#getContainerRuntimeOptions()
	 */
	public Enumeration<String> getContainerRuntimeOptions() {
		// TODO Auto-generated method stub
		return null;
	}
}
