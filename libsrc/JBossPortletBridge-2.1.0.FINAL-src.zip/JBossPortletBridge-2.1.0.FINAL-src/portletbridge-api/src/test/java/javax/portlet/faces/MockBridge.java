/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package javax.portlet.faces;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.EventRequest;
import javax.portlet.EventResponse;
import javax.portlet.PortletConfig;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

/**
 * @author asmirnov
 * 
 */
public class MockBridge implements Bridge {

	private boolean initialized = false;
	private boolean actionProcessed = false;
	private boolean responseProcessed = false;

	static int initCount = 0;
	static int actionCount = 0;
	static int responseCount = 0;
	static int destroyCount = 0;
	static int resourceCount = 0;
	static int eventCount = 0;

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.faces.Bridge#destroy()
	 */
	public void destroy() {
		if (this.initialized == false) {
			throw new IllegalStateException("bridge not initialized");
		}
		this.initialized = false;
		destroyCount++;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.portlet.faces.Bridge#doFacesRequest(javax.portlet.ActionRequest,
	 * javax.portlet.ActionResponse)
	 */
	public void doFacesRequest(ActionRequest request, ActionResponse response)
			throws BridgeException {
		if (null == request || null == response) {
			throw new NullPointerException();
		}
		if (this.initialized == false) {
			throw new IllegalStateException("bridge not initialized");
		}
		this.actionProcessed = true;
		actionCount++;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.portlet.faces.Bridge#doFacesRequest(javax.portlet.RenderRequest,
	 * javax.portlet.RenderResponse)
	 */
	public void doFacesRequest(RenderRequest request, RenderResponse response)
			throws BridgeException {
		if (null == request || null == response) {
			throw new NullPointerException();
		}
		if (this.initialized == false) {
			throw new IllegalStateException("bridge not initialized");
		}
		this.responseProcessed = true;
		responseCount++;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.portlet.faces.Bridge#init(javax.portlet.PortletConfig)
	 */
	public void init(PortletConfig config) throws BridgeException {
		if (null == config) {
			throw new NullPointerException();
		}
		this.initialized = true;
		initCount++;
	}

	/**
	 * @return the initialized
	 */
	protected boolean isInitialized() {
		return initialized;
	}

	/**
	 * @return the actionProcessed
	 */
	protected boolean isActionProcessed() {
		return actionProcessed;
	}

	/**
	 * @return the responseProcessed
	 */
	protected boolean isResponseProcessed() {
		return responseProcessed;
	}

	public void doFacesRequest(ResourceRequest request,
			ResourceResponse response) throws BridgeException {
		if (null == request || null == response) {
			throw new NullPointerException();
		}
		if (this.initialized == false) {
			throw new IllegalStateException("bridge not initialized");
		}
		resourceCount++;
	}

	public void doFacesRequest(EventRequest request, EventResponse response)
			throws BridgeException {
		if (null == request || null == response) {
			throw new NullPointerException();
		}
		if (this.initialized == false) {
			throw new IllegalStateException("bridge not initialized");
		}
		eventCount++;
	}

}
