/******************************************************************************
 * $Id$
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.context;

import javax.portlet.MimeResponse;
import javax.portlet.PortletContext;
import javax.portlet.PortletMode;
import javax.portlet.PortletModeException;
import javax.portlet.PortletRequest;
import javax.portlet.PortletSecurityException;
import javax.portlet.PortletURL;
import javax.portlet.ResourceURL;
import javax.portlet.WindowState;
import javax.portlet.WindowStateException;
import javax.portlet.faces.Bridge;

import org.jboss.portletbridge.util.PlatformUtil;

/**
 * @author asmirnov
 *
 */
public abstract class MimeExternalContextImpl extends PortletExternalContextImpl {

	//============================================================
	// public constants

	//============================================================
	// private constants

	//============================================================
	// static variables

	//============================================================
	// instance variables

	//============================================================
	// constructors

	/**
	 * @param context
	 * @param request
	 * @param response
	 */
	public MimeExternalContextImpl(PortletContext context,
	        PortletRequest request, MimeResponse response) {
		super(context, request, response);
	}

	//============================================================
	// public methods
	   

	public PortletRequest getRequest() {
		return (PortletRequest) super.getRequest();
	}

	public MimeResponse getResponse() {
		return (MimeResponse) super.getResponse();
	}

	public String getResponseCharacterEncoding() {
          return getResponse().getCharacterEncoding();
       }

	public String getResponseContentType() {
          return getResponse().getContentType();
       }

	protected String getNamespace() {
        return getResponse().getNamespace();
     }
	//============================================================
	// non-public methods

	@Override
    protected String createActionUrl(PortalActionURL url) {
    	  String viewId = getViewIdFromUrl(url);
          MimeResponse renderResponse = getResponse();
          PortletURL portletURL = renderResponse.createActionURL();
          portletURL.setParameter(Bridge.FACES_VIEW_ID_PARAMETER, viewId);
    //      portletURL.setParameter(AbstractExternalContext.NAMESPACE_PARAMETER,
    //            renderResponse.getNamespace());
          for (String key : url.getParameters().keySet()) {
    		String value = url.getParameter(key);
    		if(Bridge.PORTLET_MODE_PARAMETER.equals(key)){
    			PortletMode mode = new PortletMode(value);
    			try {
    				portletURL.setPortletMode(mode);
    			} catch (PortletModeException e) {
    				// only valid modes supported.
    			}
    		} else if (Bridge.PORTLET_WINDOWSTATE_PARAMETER.equals(key)) {
    			try {
    				WindowState state = new WindowState(value);
    				portletURL.setWindowState(state);
    			} catch (WindowStateException e) {
    				// only valid modes supported.
    			}
    
    		} else if (Bridge.PORTLET_SECURE_PARAMETER.equals(key)) {
    			try {
    				portletURL.setSecure(Boolean.getBoolean(value));
    			} catch (PortletSecurityException e) {
    				// Just ignore it.
    			}
    
    		} else {
    			portletURL.setParameter(key, value);
    		}
          }
          return portletURL.toString();
       }

	@Override
    protected String createResourceUrl(PortalActionURL portalUrl) {
    	MimeResponse renderResponse = getResponse();
    	ResourceURL resourceURL =
    		PlatformUtil.createResourceURL(renderResponse);
    	portalUrl.removeParameter(Bridge.PORTLET_MODE_PARAMETER);
    	portalUrl.removeParameter(Bridge.PORTLET_WINDOWSTATE_PARAMETER);
    	String secure = portalUrl.getParameter(Bridge.PORTLET_SECURE_PARAMETER);
    	if(null != secure){
    		try {
    		if("true".equalsIgnoreCase(secure)){
    			resourceURL.setSecure(true);
    		} else if ("false".equalsIgnoreCase(secure)) {
    			resourceURL.setSecure(false);				
    		}
    		} catch (PortletSecurityException e) {
    			// do nothing
    		}
    		portalUrl.removeParameter(Bridge.PORTLET_SECURE_PARAMETER);
    	}
    	resourceURL.setResourceID(portalUrl.getPath());
    	resourceURL.setParameters(portalUrl.getParameters());
    	return resourceURL.toString();
    }

	//============================================================
	// inner classes

}
