/******************************************************************************
 * $Id$
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.richfaces;

import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Set;

import javax.portlet.PortletContext;
import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;

/**
 * @author asmirnov
 *
 */
public class ServletPortletContextWrapper implements ServletContext {
	//============================================================
	// public constants

	//============================================================
	// private constants

	//============================================================
	// static variables

	//============================================================
	// instance variables
	private final PortletContext portletContext;
	//============================================================
	// constructors

	/**
     * @param portletContext
     */
    public ServletPortletContextWrapper(PortletContext portletContext) {
	    this.portletContext = portletContext;
    }
	/**
     * @param name
     * @return
     * @see javax.portlet.PortletContext#getAttribute(java.lang.String)
     */
    public Object getAttribute(String name) {
	    return portletContext.getAttribute(name);
    }
	/**
     * @return
     * @see javax.portlet.PortletContext#getAttributeNames()
     */
    public Enumeration<String> getAttributeNames() {
	    return portletContext.getAttributeNames();
    }
	/**
     * @param name
     * @return
     * @see javax.portlet.PortletContext#getInitParameter(java.lang.String)
     */
    public String getInitParameter(String name) {
	    return portletContext.getInitParameter(name);
    }
	/**
     * @return
     * @see javax.portlet.PortletContext#getInitParameterNames()
     */
    public Enumeration<String> getInitParameterNames() {
	    return portletContext.getInitParameterNames();
    }
	/**
     * @param file
     * @return
     * @see javax.portlet.PortletContext#getMimeType(java.lang.String)
     */
    public String getMimeType(String file) {
	    return portletContext.getMimeType(file);
    }
	/**
     * @param path
     * @return
     * @see javax.portlet.PortletContext#getRealPath(java.lang.String)
     */
    public String getRealPath(String path) {
	    return portletContext.getRealPath(path);
    }
	/**
     * @param path
     * @return
     * @throws MalformedURLException
     * @see javax.portlet.PortletContext#getResource(java.lang.String)
     */
    public URL getResource(String path) throws MalformedURLException {
	    return portletContext.getResource(path);
    }
	/**
     * @param path
     * @return
     * @see javax.portlet.PortletContext#getResourceAsStream(java.lang.String)
     */
    public InputStream getResourceAsStream(String path) {
	    return portletContext.getResourceAsStream(path);
    }
	/**
     * @param path
     * @return
     * @see javax.portlet.PortletContext#getResourcePaths(java.lang.String)
     */
    public Set<String> getResourcePaths(String path) {
	    return portletContext.getResourcePaths(path);
    }
	/**
     * @return
     * @see javax.portlet.PortletContext#getServerInfo()
     */
    public String getServerInfo() {
	    return portletContext.getServerInfo();
    }
	/**
     * @param message
     * @param throwable
     * @see javax.portlet.PortletContext#log(java.lang.String, java.lang.Throwable)
     */
    public void log(String message, Throwable throwable) {
	    portletContext.log(message, throwable);
    }
	/**
     * @param msg
     * @see javax.portlet.PortletContext#log(java.lang.String)
     */
    public void log(String msg) {
	    portletContext.log(msg);
    }
	/**
     * @param name
     * @see javax.portlet.PortletContext#removeAttribute(java.lang.String)
     */
    public void removeAttribute(String name) {
	    portletContext.removeAttribute(name);
    }
	/**
     * @param name
     * @param object
     * @see javax.portlet.PortletContext#setAttribute(java.lang.String, java.lang.Object)
     */
    public void setAttribute(String name, Object object) {
	    portletContext.setAttribute(name, object);
    }
	public ServletContext getContext(String uripath) {
	    // TODO Auto-generated method stub
	    return null;
    }
	public String getContextPath() {
	    // TODO Auto-generated method stub
	    return null;
    }
	public int getMajorVersion() {
	    // TODO Auto-generated method stub
	    return 0;
    }
	public int getMinorVersion() {
	    // TODO Auto-generated method stub
	    return 0;
    }
	public RequestDispatcher getNamedDispatcher(String name) {
	    // TODO Auto-generated method stub
	    return null;
    }
	public RequestDispatcher getRequestDispatcher(String path) {
	    // TODO Auto-generated method stub
	    return null;
    }
	public Servlet getServlet(String name) throws ServletException {
	    // TODO Auto-generated method stub
	    return null;
    }
	public String getServletContextName() {
	    // TODO Auto-generated method stub
	    return null;
    }
	public Enumeration getServletNames() {
	    // TODO Auto-generated method stub
	    return null;
    }
	public Enumeration getServlets() {
	    // TODO Auto-generated method stub
	    return null;
    }
	public void log(Exception exception, String msg) {
	    // TODO Auto-generated method stub
	    
    }
	
	//============================================================
	// public methods
    
	//============================================================
	// non-public methods

	//============================================================
	// inner classes

}
