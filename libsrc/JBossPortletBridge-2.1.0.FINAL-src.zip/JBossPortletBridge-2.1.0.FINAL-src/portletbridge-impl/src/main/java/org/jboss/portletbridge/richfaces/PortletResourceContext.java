/******************************************************************************
 * $Id$
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.richfaces;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.util.Date;
import java.util.Set;
import java.util.TimeZone;

import javax.portlet.PortletContext;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.ajax4jsf.resource.ResourceContext;

/**
 * @author asmirnov
 *
 */
public class PortletResourceContext extends ResourceContext {

	private final PortletContext context;
	private final ResourceRequest request;
	private final ResourceResponse response;


	public PortletResourceContext(PortletContext portletContext,
            ResourceRequest request, ResourceResponse response) {
				this.context = portletContext;
				this.request = request;
				this.response = response;
    }

	/* (non-Javadoc)
	 * @see org.ajax4jsf.resource.ResourceContext#setHeader(java.lang.String, java.lang.String)
	 */
	public void setHeader(String name, String value) {
		response.setProperty(name,value);

	}

	/* (non-Javadoc)
	 * @see org.ajax4jsf.resource.ResourceContext#setIntHeader(java.lang.String, int)
	 */
	public void setIntHeader(String name, int value) {
		response.setProperty(name,String.valueOf(value));

	}

	/* (non-Javadoc)
	 * @see org.ajax4jsf.resource.ResourceContext#setDateHeader(java.lang.String, long)
	 */
	public void setDateHeader(String name, long value) {
		Date date = new Date(value);
//		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.FULL);
//		dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
//		;
		response.setProperty(name,date.toGMTString());
	}

	/* (non-Javadoc)
	 * @see org.ajax4jsf.resource.ResourceContext#getOutputStream()
	 */
	public OutputStream getOutputStream() throws IOException {
		// TODO Auto-generated method stub
		return response.getPortletOutputStream();
	}

	/* (non-Javadoc)
	 * @see org.ajax4jsf.resource.ResourceContext#getQueryString()
	 */
	public String getQueryString() {
		return null;//request.getQueryString();
	}

	/* (non-Javadoc)
	 * @see org.ajax4jsf.resource.ResourceContext#getPathInfo()
	 */
	public String getPathInfo() {
		return null;//request.getPathInfo();
	}

	/* (non-Javadoc)
	 * @see org.ajax4jsf.resource.ResourceContext#getSessionAttribute(java.lang.String)
	 */
	public Object getSessionAttribute(String name) {
		return request.getPortletSession(false).getAttribute(name);
	}

	/**
	 * @param name
	 * @return
	 * @see javax.servlet.ServletContext#getAttribute(java.lang.String)
	 */
	public Object getContextAttribute(String name) {
		return context.getAttribute(name);
	}

	/**
	 * @param path
	 * @return
	 * @throws MalformedURLException
	 * @see javax.servlet.ServletContext#getResource(java.lang.String)
	 */
	public URL getResource(String path) throws MalformedURLException {
		return context.getResource(path);
	}

	/**
	 * @param path
	 * @return
	 * @see javax.servlet.ServletContext#getResourcePaths(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
    public Set getResourcePaths(String path) {
		return context.getResourcePaths(path);
	}

	public InputStream getResourceAsStream(String path) {
		// TODO Auto-generated method stub
		return context.getResourceAsStream(path);
	}

	public String getRequestParameter(String data_parameter) {
		// TODO Auto-generated method stub
		return request.getParameter(data_parameter);
	}

	/* (non-Javadoc)
	 * @see org.ajax4jsf.resource.ResourceContext#getWriter()
	 */
	public PrintWriter getWriter() throws IOException {
		// TODO Auto-generated method stub
		return response.getWriter();
	}

	public void setContentType(String contentType) {
		response.setContentType(contentType);		
	}

	public void setContentLength(int contentLength) {
//		response.setContentLength(contentLength);
	}
	
	public String getInitParameter(String name) {
		// TODO Auto-generated method stub
		return context.getInitParameter(name);
	}

	public String getServletPath() {
		return PortletResourceBuilder.RFRES;//request.getServletPath();
	}

}
