/**
 * 
 */
package org.jboss.portletbridge.richfaces;

import java.io.IOException;
import java.io.Writer;

import javax.faces.FacesException;
import javax.faces.FactoryFinder;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import javax.faces.render.RenderKit;
import javax.faces.render.RenderKitFactory;

import org.ajax4jsf.css.CssCompressor;
import org.ajax4jsf.renderkit.RendererBase;
import org.ajax4jsf.renderkit.compiler.PreparedTemplate;
import org.ajax4jsf.resource.CountingOutputWriter;
import org.ajax4jsf.resource.InternetResource;
import org.ajax4jsf.resource.ResourceContext;
import org.ajax4jsf.resource.TemplateCSSRenderer;

/**
 * @author asmirnov
 *
 */
public class PotrletTemplateCSSRenderer extends TemplateCSSRenderer {
	private static final class DummyRenderer extends RendererBase {
		protected Class<? extends UIComponent> getComponentClass() {
			return UIComponent.class;
		}
	}
	private static final String COMPRESS_STYLE_PARAMETER = "org.ajax4jsf.COMPRESS_STYLE";

	private static final RendererBase renderer = new DummyRenderer();
	/* (non-Javadoc)
	 * @see org.ajax4jsf.resource.BaseResourceRenderer#send(org.ajax4jsf.resource.InternetResource, org.ajax4jsf.resource.ResourceContext)
	 */
	public int send(InternetResource base, ResourceContext context) throws IOException {
		PreparedTemplate template = null;
		CountingOutputWriter countingOutputWriter = new CountingOutputWriter();
		template = getTemplate(base, context);
		FacesContext facesContext = FacesContext.getCurrentInstance();
		boolean _CompressStyleOn = !"false".equals(facesContext.getExternalContext()
					   		.getInitParameter(COMPRESS_STYLE_PARAMETER));
		Writer writer = context.getWriter();
		int bytesLength;
		if(null != facesContext) {
			// Create responseWriter.
			String defaultRenderKitId = facesContext.getApplication().getDefaultRenderKitId();
			if (null == defaultRenderKitId) {
				defaultRenderKitId = RenderKitFactory.HTML_BASIC_RENDER_KIT;
			}
//			RenderKitFactory renderKitFactory = (RenderKitFactory) FactoryFinder.getFactory(FactoryFinder.RENDER_KIT_FACTORY);
//			RenderKit renderKit = renderKitFactory.getRenderKit(facesContext,defaultRenderKitId);
//			// TODO - handle response encoding 
//				
//			ResponseWriter responseWriter = renderKit.createResponseWriter(countingOutputWriter,null,"UTF-8");
			TextCssResponseWriter responseWriter = new TextCssResponseWriter(writer);
			facesContext.setResponseWriter(responseWriter);
			responseWriter.startDocument();
			
			// TODO - parameters and mock renderer/component ?
			// for first time, this template only allow skin or faces variables interaction
			template.encode(renderer,facesContext,null);
			responseWriter.endDocument();
			responseWriter.flush();
			responseWriter.close();
			
			if (_CompressStyleOn) {    
			    	CssCompressor compressor = new CssCompressor(countingOutputWriter.getContent()); // Compressing css document and printing result in response stream
			    	bytesLength = compressor.compress(writer, -1);
			    	writer.flush();
			    	writer.close();
			} else {
			    	writer.write(countingOutputWriter.getContent().toString());  // Write not compressed style content
			    	bytesLength = countingOutputWriter.getWritten();
			    	writer.flush();
			    	writer.close();
			}
			
		} else {
			throw new FacesException("FacesContext for resource from template "+base.getKey()+" is null");
		}
		return bytesLength;
	}

}
