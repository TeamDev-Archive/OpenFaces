/******************************************************************************
 * $Id$
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.richfaces;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Date;

import javax.faces.context.FacesContext;
import javax.portlet.MimeResponse;
import javax.portlet.ResourceResponse;

import org.ajax4jsf.resource.FacesResourceContext;

/**
 * @author asmirnov
 * 
 */
public class PortletFacesResourceContext extends FacesResourceContext {

	// ============================================================
	// public constants

	// ============================================================
	// private constants

	// ============================================================
	// static variables

	// ============================================================
	// instance variables
	private ResourceResponse portletResponse;

	// ============================================================
	// constructors
	/**
	 * @param facesContext
	 */
	public PortletFacesResourceContext(FacesContext facesContext) {
		super(facesContext);
		Object responseObject = facesContext.getExternalContext().getResponse();
		if (responseObject instanceof ResourceResponse) {
			portletResponse = (ResourceResponse) responseObject;
		}
	}

	// ============================================================
	// public methods
	@Override
	public void setContentType(String contentType) {
		if (null != portletResponse) {
			portletResponse.setContentType(contentType);
		}
	}

	@Override
	public void setContentLength(int contentLength) {
		// if(null != portletResponse){
		// portletResponse.setContentLength(contentLength);
		// }
	}

	@Override
	public void setHeader(String name, String value) {
		if (null != portletResponse) {
			portletResponse.setProperty(name, value);
		}
	}

	@Override
	public void setDateHeader(String name, long value) {
		if (null != portletResponse) {
			Date date = new Date(value);
			portletResponse.setProperty(name, date.toGMTString());
		}
	}
	
	@Override
	public OutputStream getOutputStream() throws IOException {
		if (null != portletResponse) {
			return portletResponse.getPortletOutputStream();
		}
	    return super.getOutputStream();
	}
	
	@Override
	public PrintWriter getWriter() throws IOException {
		if (null != portletResponse) {
			return portletResponse.getWriter();
		}
	    return super.getWriter();
	}
	// ============================================================
	// non-public methods

	// ============================================================
	// inner classes

}
