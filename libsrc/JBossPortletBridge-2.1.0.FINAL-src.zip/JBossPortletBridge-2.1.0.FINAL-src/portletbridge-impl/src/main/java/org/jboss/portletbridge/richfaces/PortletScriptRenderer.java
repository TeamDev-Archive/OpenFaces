/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.richfaces;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;
import java.util.logging.Logger;

import javax.faces.context.FacesContext;

import org.ajax4jsf.Messages;
import org.ajax4jsf.javascript.ScriptUtils;
import org.ajax4jsf.resource.InternetResource;
import org.ajax4jsf.resource.ResourceContext;
import org.ajax4jsf.resource.ResourceRenderer;
import org.ajax4jsf.resource.ResourceRenderer;
import org.jboss.portletbridge.util.BridgeLogger;

/**
 * @author <a href="mailto:whales@redhat.com">Wesley Hales</a>
 * @version $Revision: 630 $
 */
public class PortletScriptRenderer implements ResourceRenderer {

	private static final Logger _log = BridgeLogger.AJAX.getLogger();

	private static final String BRIDGE_WRAP_SCRIPTS = "org.jboss.portletbridge.WRAP_SCRIPTS";

	private final ResourceRenderer parent;

	/**
	 * @param parent
	 */
	public PortletScriptRenderer(ResourceRenderer parent) {
		super();
		this.parent = parent;
	}

	public int send(InternetResource base, ResourceContext context)
			throws IOException {
		InputStream in = base.getResourceAsStream(context);

		if (null == in) {
			String message = Messages.getMessage(
					Messages.NO_INPUT_STREAM_ERROR, base.getKey());
			throw new IOException(message);
		}
		if ("true".equalsIgnoreCase(context
				.getInitParameter(BRIDGE_WRAP_SCRIPTS))) {
			OutputStream out = context.getOutputStream();
			CountingOutputStream countingStream = new CountingOutputStream(out);
			try {

				String scriptId = base.getKey();
				scriptId = "RF_" + ScriptUtils.getValidJavascriptName(scriptId);
				out.write(("if(!window." + scriptId + "){\nwindow." + scriptId + " = {};\n")
						.getBytes());
				parent.send(base, new ResourceContextWrapper(context,
						countingStream));
				countingStream.write("\n}\n".getBytes());
			} finally {
				in.close();
				out.flush();
				out.close();
			}
			return countingStream.getWritten();
		} else {
			return parent.send(base, context);
		}
	}

	/**
	 * @param resource
	 * @param context
	 * @param data
	 * @param attributes
	 * @throws IOException
	 * @see org.ajax4jsf.resource.BaseResourceRenderer#encode(org.ajax4jsf.resource.InternetResource,
	 *      javax.faces.context.FacesContext, java.lang.Object, java.util.Map)
	 */
	public void encode(InternetResource resource, FacesContext context,
			Object data, Map<String, Object> attributes) throws IOException {
		parent.encode(resource, context, data, attributes);
	}

	/**
	 * @param resource
	 * @param context
	 * @param data
	 * @throws IOException
	 * @see org.ajax4jsf.resource.BaseResourceRenderer#encode(org.ajax4jsf.resource.InternetResource,
	 *      javax.faces.context.FacesContext, java.lang.Object)
	 */
	public void encode(InternetResource resource, FacesContext context,
			Object data) throws IOException {
		parent.encode(resource, context, data);
	}

	/**
	 * @param resource
	 * @param context
	 * @param data
	 * @param attributes
	 * @throws IOException
	 * @see org.ajax4jsf.resource.OneTimeRenderer#encodeBegin(org.ajax4jsf.resource.InternetResource,
	 *      javax.faces.context.FacesContext, java.lang.Object, java.util.Map)
	 */
	public void encodeBegin(InternetResource resource, FacesContext context,
			Object data, Map<String, Object> attributes) throws IOException {
		parent.encodeBegin(resource, context, data, attributes);
	}

	/**
	 * @param resource
	 * @param context
	 * @param data
	 * @throws IOException
	 * @see org.ajax4jsf.resource.OneTimeRenderer#encodeEnd(org.ajax4jsf.resource.InternetResource,
	 *      javax.faces.context.FacesContext, java.lang.Object)
	 */
	public void encodeEnd(InternetResource resource, FacesContext context,
			Object data) throws IOException {
		parent.encodeEnd(resource, context, data);
	}

	/**
	 * @return
	 * @see org.ajax4jsf.resource.CompressedScriptRenderer#getContentType()
	 */
	public String getContentType() {
		return parent.getContentType();
	}

	/**
	 * @param base
	 * @param context
	 * @param data
	 * @return
	 * @see org.ajax4jsf.resource.BaseResourceRenderer#getData(org.ajax4jsf.resource.InternetResource,
	 *      javax.faces.context.FacesContext, java.lang.Object)
	 */
	public Object getData(InternetResource base, FacesContext context,
			Object data) {
		return parent.getData(base, context, data);
	}

	/**
	 * @return
	 * @see org.ajax4jsf.resource.BaseResourceRenderer#requireFacesContext()
	 */
	public boolean requireFacesContext() {
		return parent.requireFacesContext();
	}

}

class CountingOutputStream extends OutputStream {
	private OutputStream outputStream;
	private int written = 0;

	CountingOutputStream(OutputStream outputStream) {
		super();
		this.outputStream = outputStream;
	}

	public void close() throws IOException {
		// outputStream.close();
	}

	public void flush() throws IOException {
		// outputStream.flush();
	}

	public void write(byte[] b, int off, int len) throws IOException {
		outputStream.write(b, off, len);
		written += len;
	}

	public void write(byte[] b) throws IOException {
		outputStream.write(b);
		written += b.length;
	}

	public void write(int b) throws IOException {
		outputStream.write(b);
		written++;
	}

	int getWritten() {
		return written;
	}
}
