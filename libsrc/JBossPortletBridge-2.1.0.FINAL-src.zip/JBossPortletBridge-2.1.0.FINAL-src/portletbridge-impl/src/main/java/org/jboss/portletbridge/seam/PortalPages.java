/******************************************************************************
 * $Id$
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.seam;

import javax.faces.context.FacesContext;
import javax.portlet.PortletRequest;
import javax.portlet.faces.BridgeUtil;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Install;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.Startup;
import org.jboss.seam.annotations.intercept.BypassInterceptors;
import org.jboss.seam.navigation.Pages;

/**
 * Workaround for PBR-117 .
 * @author asmirnov
 *
 */
@Scope(ScopeType.APPLICATION)
@BypassInterceptors
@Name("org.jboss.seam.navigation.pages")
@Install(precedence=Install.FRAMEWORK, classDependencies={"javax.faces.context.FacesContext","javax.portlet.faces.Bridge"})
@Startup
public class PortalPages extends Pages {

	@Override
	public String getRequestScheme(FacesContext facesContext) {
	    if(BridgeUtil.isPortletRequest()){
	    	PortletRequest request  = (PortletRequest) facesContext.getExternalContext().getRequest();
	    	return request.getScheme();
	    } else {
	    	return super.getRequestScheme(facesContext);
	    }
	}
	
	@Override
	public String encodeScheme(String viewId, FacesContext context, String url) {
	    if(BridgeUtil.isPortletRequest()){
	    	// Do nothing in the portlet case.
	    	return url;
	    } else {
	    	return super.encodeScheme(viewId, context, url);
	    }
	}
}
