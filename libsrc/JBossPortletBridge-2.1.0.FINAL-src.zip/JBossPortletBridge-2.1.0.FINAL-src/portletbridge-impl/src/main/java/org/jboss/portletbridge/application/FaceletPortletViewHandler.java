/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.application;

import java.io.IOException;
import java.io.Writer;

import javax.faces.FacesException;
import javax.faces.application.ViewHandler;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import javax.faces.render.RenderKit;
import javax.portlet.MimeResponse;
import javax.portlet.PortletRequest;
import javax.portlet.PortletResponse;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.faces.Bridge;
import javax.servlet.http.HttpServletResponse;

import com.sun.facelets.FaceletViewHandler;

/** ViewHandler implementation for Facelets used in Portlets */
public class FaceletPortletViewHandler extends FaceletViewHandler
{
   private static final Writer nullWriter = new Writer()
   {
      public void close() throws IOException
      {
         // Do nothing
      }

      public void flush() throws IOException
      {
         // Do nothing
      }

      public void write(char[] cbuf, int off, int len) throws IOException
      {
         // Do nothing
      }
   };

   public FaceletPortletViewHandler(ViewHandler parent)
   {
      super(parent);
   }

   protected ResponseWriter createResponseWriter(FacesContext context)
      throws IOException, FacesException
   {
      ResponseWriter writer;
      ExternalContext extContext = context.getExternalContext();
      Object lifecyclePhaseAttr = extContext.getRequestMap().get(Bridge.PORTLET_LIFECYCLE_PHASE);
      if (Bridge.PortletPhase.RENDER_PHASE.equals(lifecyclePhaseAttr) || Bridge.PortletPhase.RESOURCE_PHASE.equals(lifecyclePhaseAttr))
      {
         RenderKit renderKit = context.getRenderKit();
         PortletRequest request = (PortletRequest)extContext.getRequest();
         MimeResponse response = (MimeResponse)extContext.getResponse();
         String contenttype = request.getResponseContentType();
         if (contenttype == null)
         {
            contenttype = "text/html";
         }
         String encoding = response.getCharacterEncoding();
         if (encoding == null)
         {
            encoding = "UTF-8";
         }
         writer = renderKit.createResponseWriter(nullWriter, contenttype,
            encoding);
         contenttype = writer.getContentType();
         // apply them to the response
         // response.setContentType(contenttype);
         // Now, clone with the real writer
         writer = writer.cloneWithWriter(response.getWriter());
      }
      else if (null != lifecyclePhaseAttr)
      {
         RenderKit renderKit = context.getRenderKit();
         writer = renderKit.createResponseWriter(nullWriter, null,
            null);
      }
      else
      {
         writer = super.createResponseWriter(context);
      }
      return writer;
   }

   @Override
   protected void handleFaceletNotFound(FacesContext context, String viewId) throws FacesException, IOException
   {
     String actualId = this.getActionURL(context, viewId);
     Object respObj = context.getExternalContext().getResponse();
     if (respObj instanceof HttpServletResponse) {
         HttpServletResponse respHttp = (HttpServletResponse) respObj;
         respHttp.sendError(HttpServletResponse.SC_NOT_FOUND, actualId);
         context.responseComplete();
     }
   }
}