/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.context;

import org.jboss.portletbridge.BridgeRequestScope;
import org.jboss.portletbridge.seam.PortletScope;

import javax.faces.FacesException;
import javax.faces.application.ViewHandler;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContextFactory;
import javax.portlet.PortletContext;
import javax.portlet.PortletException;
import javax.portlet.PortletRequest;
import javax.portlet.PortletRequestDispatcher;
import javax.portlet.PortletResponse;
import javax.portlet.PortletSession;
import javax.portlet.faces.Bridge;
import javax.portlet.faces.BridgeDefaultViewNotSpecifiedException;
import javax.portlet.faces.BridgeInvalidViewPathException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Version of the {@link ExternalContext} for a Portlet request.
 * {@link FacesContextFactory} will create instance of this class for a portal
 * <code>action</code> phase.
 *
 * @author asmirnov
 *
 */
public abstract class PortletExternalContextImpl extends AbstractExternalContext {

	public static final String SERVLET_PATH_ATTRIBUTE = "javax.servlet.include.servlet_path";
	public static final String PATH_INFO_ATTRIBUTE = "javax.servlet.include.path_info";
	public static final String ACTION_URL_DO_NOTHITG = "/JBossPortletBridge/actionUrl/do/nothing";
	public static final String RESOURCE_URL_DO_NOTHITG = "/JBossPortletBridge/resourceUrl/do/nothing";

	public PortletExternalContextImpl(PortletContext context,
			PortletRequest request, PortletResponse response) {
		super(context, request, response);
		portletBridgeContext = (PortletBridgeContext) request
				.getAttribute(PortletBridgeContext.REQUEST_PARAMETER_NAME);
		if (null == portletBridgeContext) {
			throw new FacesException("No portlet bridge context");
		}
		// Calculate FacesServlet prefix.
		calculateViewId();
	}

	public void setResponseCharacterEncoding(String encoding) {
		// Do nothing
	}

	public String getResponseCharacterEncoding() {
		return null;
	}

	public String getResponseContentType() {
		return null;
	}


	public String getRequestContentType() {
		return null;
	}

	public PortletContext getContext() {
		return (PortletContext) super.getContext();
	}

	public PortletRequest getRequest() {
		return (PortletRequest) super.getRequest();
	}

	public PortletResponse getResponse() {
		return (PortletResponse) super.getResponse();
	}

	public String getInitParameter(String name) {
		return getContext().getInitParameter(name);
	}

	protected String getNamespace() {
		return getResponse().getNamespace();
	}

	public URL getResource(String path) throws MalformedURLException {
		return getContext().getResource(path);
	}

	public InputStream getResourceAsStream(String path) {
		return getContext().getResourceAsStream(path);
	}

	public Set<String> getResourcePaths(String path) {
		return getContext().getResourcePaths(path);
	}

	protected Enumeration<String> enumerateRequestParameterNames() {
		return getRequest().getParameterNames();
	}

	protected Object getContextAttribute(String name) {
		return getContext().getAttribute(name);
	}

	protected Enumeration<String> getContextAttributeNames() {
		return getContext().getAttributeNames();
	}

	protected Enumeration<String> getInitParametersNames() {
		return getContext().getInitParameterNames();
	}

	protected Object getRequestAttribute(String name) {
		if(PATH_INFO_ATTRIBUTE.equals(name)){
			return getRequestPathInfo();
		} else if (SERVLET_PATH_ATTRIBUTE.equals(name)) {
			return getRequestServletPath();
		} else {
			return getRequest().getAttribute(name);
		}
	}

	protected Enumeration<String> getRequestAttributeNames() {
		return getRequest().getAttributeNames();
	}

	public Map<String, String[]> getRequestParameterValuesMap() {
		return getRequest().getParameterMap();
	}

	protected String[] getRequestParameterValues(String name) {
		return getRequest().getParameterValues(name);
	}

	protected String getRequestHeader(String name) {
		return getRequest().getProperty(name);
	}

	protected Enumeration<String> getRequestHeaderNames() {
		return getRequest().getPropertyNames();
	}

	protected String[] getRequestHeaderValues(String name) {
		Enumeration<String> properties = getRequest()
				.getProperties(name);
		List<String> values = new ArrayList<String>();
		while (properties.hasMoreElements()) {
			String value = properties.nextElement();
			values.add(value);
		}
		return (String[]) values.toArray(EMPTY_STRING_ARRAY);
	}

	protected String getRequestParameter(String name) {
		return getRequest().getParameter(name);
	}

	protected Object getSessionAttribute(String name) {
		return getSessionAttribute(name, getScopeForName(name));
	}

   protected int getScopeForName(String name) {
	    return this.portletBridgeContext.getBridgeConfig().getStrategy().getPortletSessionScopeForName(name);
    }

protected Object getSessionAttribute(String name,int scope) {
		return getRequest().getPortletSession(true).getAttribute(name, scope);
	}

	protected Enumeration<String> getSessionAttributeNames() {
		class AttributeEnumeration implements Enumeration<String> {
            int scope;
            Enumeration<String> attributes;

            public AttributeEnumeration() {
                scope = PortletSession.PORTLET_SCOPE;
                attributes = getSessionAttributeNames(scope);
                if (!attributes.hasMoreElements()) {
                    scope = PortletSession.APPLICATION_SCOPE;
                    attributes = getSessionAttributeNames(scope);
                }
            }

            public boolean hasMoreElements() {
                return attributes.hasMoreElements();
            }

            public String nextElement() {
                final String result = attributes.nextElement();

                if (!attributes.hasMoreElements()
                    && scope == PortletSession.PORTLET_SCOPE) {
                    scope = PortletSession.APPLICATION_SCOPE;
                    attributes = getSessionAttributeNames(scope);
                }

                return result;
            }
        }

        return new AttributeEnumeration();

        //return getSessionAttributeNames(PortletSession.PORTLET_SCOPE);
	}

	protected Enumeration<String> getSessionAttributeNames(int scope) {
		return getRequest().getPortletSession(true).getAttributeNames(
				scope);
	}

	protected void removeContextAttribute(String name) {
		getContext().removeAttribute(name);
	}

	protected void removeRequestAttribute(String name) {
		getRequest().removeAttribute(name);
	}

	protected void removeSessionAttribute(String name) {
		removeSessionAttribute(name, getScopeForName(name));
	}

   protected void removeSessionAttribute(String name,int scope) {
		getRequest().getPortletSession(true).removeAttribute(name,
				scope);
	}

	protected void setContextAttribute(String name, Object value) {
		getContext().setAttribute(name, value);
	}

	protected void setRequestAttribute(String name, Object value) {
		getRequest().setAttribute(name, value);
	}

	protected void setSessionAttribute(String name, Object value) {
		setSessionAttribute(name, value, getScopeForName(name));
	}

	protected void setSessionAttribute(String name, Object value, int scope) {
      getRequest().getPortletSession(true).setAttribute(name, value,
				scope);
	}


	// private static final Pattern absoluteUrl = Pattern.compile("");
	// private static final Pattern directLink = Pattern.compile("");
	// private static final Pattern viewIdParam = Pattern.compile("");


	/**
	 * @param url
	 * @return
	 */
	protected String encodeURL(String url) {
		return getResponse().encodeURL(url);
	}

	public String getAuthType() {
		return getRequest().getAuthType();
	}

	public String getRemoteUser() {
		String user = getRequest().getRemoteUser();
		if (user == null) {
			Principal userPrincipal = getUserPrincipal();
			if (null != userPrincipal) {
				user = userPrincipal.getName();

			}
		}
		return user;
	}

	public String getRequestContextPath() {
		return getRequest().getContextPath();
	}

	public Locale getRequestLocale() {
		return getRequest().getLocale();
	}

	public Iterator<Locale> getRequestLocales() {
		return new EnumerationIterator<Locale>(getRequest().getLocales());
	}

	private String _pathInfo = null;

	public String getRequestPathInfo() {
		return _pathInfo;
	}

	private String _servletPath = null;
	private String servletMappingSuffix;
	private String defaultJsfSuffix;
	private String servletMappingPrefix;
	private String viewId;

	public String getRequestServletPath() {
		return _servletPath;
	}

	public Object getSession(boolean create) {
		return getRequest().getPortletSession(create);
	}

	public Principal getUserPrincipal() {
		return getRequest().getUserPrincipal();
	}

	public boolean isUserInRole(String role) {
		return getRequest().isUserInRole(role);
	}

	public void log(String message) {
		getContext().log(message);
	}

	public void log(String message, Throwable exception) {
		getContext().log(message, exception);
	}


	protected void calculateViewId() {
		viewId = (String) getRequest().getAttribute(Bridge.VIEW_ID);
      String portletModeName = getRequest()
							.getPortletMode().toString();
		// Get stored ViewId from window state
		if (null == viewId) {
			String viewPath = (String) getRequest().getAttribute(
					Bridge.VIEW_PATH);
			if (null != viewPath) {
				viewId = getViewIdFromPath(viewPath);
			} else {
				BridgeRequestScope windowState = portletBridgeContext
						.getRequestScope();
            String resetModeViewId = portletBridgeContext.getBridgeConfig().getPortletConfig()
               .getInitParameter(Bridge.RESET_MODE_VIEWID);
            if(resetModeViewId != null && Boolean.parseBoolean(resetModeViewId)){
               //reset the default viewId for the given mode if
               //param is true
               viewId = calculateDefaultViewId(portletModeName);
            } else if (null != windowState) {
               //continue as normal
					viewId = windowState.getViewId();
				}
				if (null == viewId) {
					// Try to get viewId from stored session attribute
					PortletSession portletSession = getRequest()
							.getPortletSession(false);
					if (null != portletSession) {
						String historyViewId = (String) portletSession
								.getAttribute(Bridge.VIEWID_HISTORY + "."
										+ portletModeName);
						if (null != historyViewId) {
							try {
								PortalActionURL viewIdUrl = new PortalActionURL(
								        historyViewId);
								viewId = viewIdUrl.getPath();
							} catch (MalformedURLException e) {
								// Ignore it.
							}
                        }					}
					if (null == viewId) {
						viewId = calculateDefaultViewId(portletModeName);
					}
					if (null == viewId) {
						throw new BridgeDefaultViewNotSpecifiedException();
					}
				}
			}
		}
		// TODO - detect mapping and convert viewId into appropriate url
		List<String> servletMappings = portletBridgeContext.getBridgeConfig()
				.getFacesServletMappings();
		calculateServletPath(viewId, servletMappings);
	}

   private String calculateDefaultViewId(String modeName){
      return portletBridgeContext.getBridgeConfig().getDefaultViewIdMap().get(modeName);
   }

	protected void calculateServletPath(String viewId,
			List<String> servletMappings) {
		if (null != servletMappings && servletMappings.size() > 0) {
			String mapping = servletMappings.get(0);
			if (mapping.startsWith("*")) {
				// Suffix Mapping
				servletMappingSuffix = mapping.substring(mapping.indexOf('.'));
				defaultJsfSuffix = getContext().getInitParameter(
						ViewHandler.DEFAULT_SUFFIX_PARAM_NAME);
				if (null == defaultJsfSuffix) {
					defaultJsfSuffix = ViewHandler.DEFAULT_SUFFIX;
				}
				int i = viewId.lastIndexOf(defaultJsfSuffix);
				if (i < 0) {
					i = viewId.lastIndexOf('.');
				}
				if (i >= 0) {
					viewId = viewId.substring(0, i) + servletMappingSuffix;
				}
				_servletPath = viewId;
				getRequest().setAttribute(
						SERVLET_PATH_ATTRIBUTE, viewId);
				getRequest().setAttribute(
						"com.sun.faces.INVOCATION_PATH", servletMappingSuffix);
				_pathInfo = null;
			} else if (mapping.endsWith("*")) {
				mapping = mapping.substring(0, mapping.length() - 1);
				if (mapping.endsWith("/")) {
					mapping = mapping.substring(0, mapping.length() - 1);
				}
				servletMappingPrefix = _servletPath = mapping;
				getRequest().setAttribute(
						"com.sun.faces.INVOCATION_PATH", mapping);
				_pathInfo = viewId;
			} else {
				_servletPath = null;
				_pathInfo = viewId;
			}
		} else {
			_servletPath = null;
			_pathInfo = viewId;
		}
	}

	/**
	 * @param actionURL
	 */
	protected void internalRedirect(PortalActionURL actionURL) {
		// Detect ViewId from URL and create new view for them.
		String viewId = actionURL.getParameter(Bridge.FACES_VIEW_ID_PARAMETER);
		if (null != viewId) {
			// Save new viewId to restore after redirect.
			portletBridgeContext.setRedirectViewId(viewId);
			// FacesContext facesContext =
			// FacesContext.getCurrentInstance();
			// ViewHandler viewHandler = facesContext.getApplication()
			// .getViewHandler();
			// facesContext.setViewRoot(viewHandler.createView(facesContext,
			// viewId));
			// setHasNavigationRedirect(true);
			Map<String, String[]> requestParameters = actionURL.getParameters();
			if (requestParameters.size() > 0) {
				portletBridgeContext
						.setRedirectRequestParameters(requestParameters);
			}

		}
	}

	/**
	 * @return the servletMappingSuffix
	 */
	public String getServletMappingSuffix() {
		return servletMappingSuffix;
	}

	/**
	 * @return the defaultJsfSuffix
	 */
	public String getDefaultJsfSuffix() {
		return defaultJsfSuffix;
	}

	/**
	 * @return the defaultJsfPrefix
	 */
	public String getServletMappingPrefix() {
		return servletMappingPrefix;
	}

	protected String getViewIdFromUrl(PortalActionURL url) {
		String viewId;
		viewId = url.getParameter(Bridge.FACES_VIEW_ID_PARAMETER);
		if (null == viewId) {
			viewId = url.getPath();
			if (viewId.startsWith(getRequestContextPath())) {
				viewId = viewId.substring(getRequestContextPath().length());
			}
			viewId = getViewIdFromPath(viewId);

		}
		return viewId;
	}

	protected String getViewIdFromPath(String viewId) {
		if (null != getServletMappingPrefix() && viewId.startsWith(getServletMappingPrefix())) {
				viewId = viewId.substring(getServletMappingPrefix()
						.length());
		} else if (null != getServletMappingSuffix()) {
			int i = viewId.lastIndexOf(getServletMappingSuffix());
			if (i >= 0) {
				viewId = viewId.substring(0, i) + getDefaultJsfSuffix();
//			} else {
//				throw new BridgeInvalidViewPathException(viewId);
			}
		}
		return viewId;
	}

	@Override
	protected String createResourceUrl(PortalActionURL portalUrl) {
		return RESOURCE_URL_DO_NOTHITG;
	}

	public void dispatch(String path) throws IOException {
          if (null == path) {
             throw new NullPointerException("Path to new view is null");
          }
          PortletRequestDispatcher dispatcher = getContext()
                .getRequestDispatcher(path);
          if (null == dispatcher) {
             throw new IllegalStateException(
                   "Dispatcher for render request is not created");
          }
          // Bridge has had to set this attribute so  Faces RI will skip servlet dependent
          // code when mapping from request paths to viewIds -- however we need to remove it
          // as it screws up the dispatch
    //      Object oldPath = getRequestMap().remove(SERVLET_PATH_ATTRIBUTE);
          try {
             dispatcher.forward(getRequest(), getResponse());
          } catch (PortletException e) {
             throw new FacesException(e);
          } finally {
    //    	  if(null !=oldPath){
    //    		  getRequestMap().put(SERVLET_PATH_ATTRIBUTE, oldPath);
    //    	  }
          }
       }



}
