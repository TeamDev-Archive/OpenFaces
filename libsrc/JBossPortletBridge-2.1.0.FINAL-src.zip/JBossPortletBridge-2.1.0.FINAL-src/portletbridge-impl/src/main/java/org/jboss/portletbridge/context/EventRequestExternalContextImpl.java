/**
 * 
 */
package org.jboss.portletbridge.context;

import java.io.IOException;

import javax.portlet.EventRequest;
import javax.portlet.EventResponse;
import javax.portlet.PortletContext;
import javax.portlet.PortletRequest;
import javax.portlet.PortletResponse;

/**
 * @author asmirnov
 *
 */
public class EventRequestExternalContextImpl extends PortletExternalContextImpl {

	/**
	 * @param context
	 * @param request
	 * @param response
	 */
	public EventRequestExternalContextImpl(PortletContext context,
			EventRequest request, EventResponse response) {
		super(context, request, response);
		// TODO Auto-generated constructor stub
	}

	@Override
    protected String createActionUrl(PortalActionURL url) {
	    return ACTION_URL_DO_NOTHITG;
    }

	@Override
    public void redirect(String url) throws IOException {
	    // TODO Auto-generated method stub
	    
    }

}
