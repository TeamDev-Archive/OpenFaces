/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.seam;

import org.jboss.seam.Component;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Install;
import static org.jboss.seam.annotations.Install.DEPLOYMENT;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.intercept.BypassInterceptors;
import org.jboss.seam.contexts.Contexts;
import org.jboss.seam.international.StatusMessage;
import org.jboss.seam.international.StatusMessages;

import javax.faces.application.FacesMessage;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * @author Joseph Berdat
 */

@SuppressWarnings("serial")
@Scope(ScopeType.CONVERSATION)
@Name(StatusMessages.COMPONENT_NAME)
@Install(precedence=DEPLOYMENT, classDependencies="javax.faces.context.FacesContext")
@BypassInterceptors
public class FacesMessages extends org.jboss.seam.faces.FacesMessages {

	public List<FacesMessage> getStatusMessages() {
		Iterator<StatusMessage> messages = this.getMessages().iterator();
		List<FacesMessage>      fMessages = new ArrayList<FacesMessage>();

		while(messages.hasNext()) {
			StatusMessage sm = messages.next();
			FacesMessage  fm = new FacesMessage(toSeverity(sm.getSeverity()), sm.getSummary(), sm.getDetail() );
			fMessages.add(fm);
		}

		return fMessages;
	}

	   /**
	    * Convert a StatusMessage.Severity to a FacesMessage.Severity
	    */
	   private static javax.faces.application.FacesMessage.Severity toSeverity(org.jboss.seam.international.StatusMessage.Severity severity)
	   {
	      switch (severity)
	      {
	      case ERROR:
	         return FacesMessage.SEVERITY_ERROR;
	      case FATAL:
	         return FacesMessage.SEVERITY_FATAL;
	      case INFO:
	         return FacesMessage.SEVERITY_INFO;
	      case WARN:
	         return FacesMessage.SEVERITY_WARN;
	      default:
	         return null;
	      }
	   }

	   public static FacesMessages instance()
	   {
	      if ( !Contexts.isConversationContextActive() )
	      {
	         throw new IllegalStateException("No active conversation context");
	      }
	      return (FacesMessages) Component.getInstance(StatusMessages.COMPONENT_NAME, ScopeType.CONVERSATION);
	   }
}

