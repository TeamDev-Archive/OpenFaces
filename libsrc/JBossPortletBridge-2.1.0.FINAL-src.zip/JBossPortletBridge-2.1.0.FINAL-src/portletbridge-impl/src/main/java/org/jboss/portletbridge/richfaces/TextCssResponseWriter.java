/**
 * 
 */
package org.jboss.portletbridge.richfaces;

import java.io.IOException;
import java.io.Writer;

import javax.faces.component.UIComponent;
import javax.faces.context.ResponseWriter;

/**
 * @author asmirnov
 *
 */
public class TextCssResponseWriter extends ResponseWriter {
	
	private final Writer writer;

	/**
	 * @param writer
	 */
	public TextCssResponseWriter(Writer writer) {
		super();
		this.writer = writer;
	}

	/* (non-Javadoc)
	 * @see javax.faces.context.ResponseWriter#cloneWithWriter(java.io.Writer)
	 */
	@Override
	public ResponseWriter cloneWithWriter(Writer writer) {
		return new TextCssResponseWriter(writer);
	}

	/* (non-Javadoc)
	 * @see javax.faces.context.ResponseWriter#endDocument()
	 */
	@Override
	public void endDocument() throws IOException {
	}

	/* (non-Javadoc)
	 * @see javax.faces.context.ResponseWriter#endElement(java.lang.String)
	 */
	@Override
	public void endElement(String name) throws IOException {
	}

	/* (non-Javadoc)
	 * @see javax.faces.context.ResponseWriter#flush()
	 */
	@Override
	public void flush() throws IOException {
		writer.flush();
	}

	/* (non-Javadoc)
	 * @see javax.faces.context.ResponseWriter#getCharacterEncoding()
	 */
	@Override
	public String getCharacterEncoding() {
		return "UTF-8";
	}

	/* (non-Javadoc)
	 * @see javax.faces.context.ResponseWriter#getContentType()
	 */
	@Override
	public String getContentType() {
		return "text/css";
	}

	/* (non-Javadoc)
	 * @see javax.faces.context.ResponseWriter#startDocument()
	 */
	@Override
	public void startDocument() throws IOException {
	}

	/* (non-Javadoc)
	 * @see javax.faces.context.ResponseWriter#startElement(java.lang.String, javax.faces.component.UIComponent)
	 */
	@Override
	public void startElement(String name, UIComponent component)
			throws IOException {
	}

	/* (non-Javadoc)
	 * @see javax.faces.context.ResponseWriter#writeAttribute(java.lang.String, java.lang.Object, java.lang.String)
	 */
	@Override
	public void writeAttribute(String name, Object value, String property)
			throws IOException {
	}

	/* (non-Javadoc)
	 * @see javax.faces.context.ResponseWriter#writeComment(java.lang.Object)
	 */
	@Override
	public void writeComment(Object comment) throws IOException {
		if(null != comment){
			writer.write("/*");
			writer.write(comment.toString());
			writer.write("*/");
		}
	}

	/* (non-Javadoc)
	 * @see javax.faces.context.ResponseWriter#writeText(java.lang.Object, java.lang.String)
	 */
	@Override
	public void writeText(Object text, String property) throws IOException {
		if(null != text){
			writer.write(text.toString());
		}
	}

	/* (non-Javadoc)
	 * @see javax.faces.context.ResponseWriter#writeText(char[], int, int)
	 */
	@Override
	public void writeText(char[] text, int off, int len) throws IOException {
		writer.write(text, off, len);
	}

	/* (non-Javadoc)
	 * @see javax.faces.context.ResponseWriter#writeURIAttribute(java.lang.String, java.lang.Object, java.lang.String)
	 */
	@Override
	public void writeURIAttribute(String name, Object value, String property)
			throws IOException {
	}

	/* (non-Javadoc)
	 * @see java.io.Writer#close()
	 */
	@Override
	public void close() throws IOException {
		writer.close();
	}

	/* (non-Javadoc)
	 * @see java.io.Writer#write(char[], int, int)
	 */
	@Override
	public void write(char[] cbuf, int off, int len) throws IOException {
		writer.write(cbuf, off, len);
	}

	public void write(char[] cbuf) throws IOException {
		writer.write(cbuf);
	}

	public void write(int c) throws IOException {
		writer.write(c);
	}

	public void write(String str, int off, int len) throws IOException {
		writer.write(str, off, len);
	}

	public void write(String str) throws IOException {
		writer.write(str);
	}

}
