/**
 * License Agreement.
 *
 * Rich Faces - Natural Ajax for Java Server Faces (JSF)
 *
 * Copyright (C) 2007 Exadel, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 2.1 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
 */
/*

 * Created on 25.09.2004

 *

 * Copyright 1999-2004 The Apache Software Foundation.

 * 

 * Licensed under the Apache License, Version 2.0 (the "License");

 * you may not use this file except in compliance with the License.

 * You may obtain a copy of the License at

 * 

 *      http://www.apache.org/licenses/LICENSE-2.0

 * 

 * Unless required by applicable law or agreed to in writing, software

 * distributed under the License is distributed on an "AS IS" BASIS,

 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

 * See the License for the specific language governing permissions and

 * limitations under the License.

 */
package org.jboss.portletbridge.context;

import java.net.MalformedURLException;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Map;

import javax.faces.FacesException;
import javax.faces.application.ViewHandler;
import javax.faces.component.UIViewRoot;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.portlet.faces.Bridge;
import javax.servlet.http.HttpServletResponse;

import org.jboss.portletbridge.BridgeRequestScope;

/**
 * 
 * @author shura
 * 
 * 
 * 
 *         Cocoon specific implementation of <code>ExternalContext</code> Use
 *         cocoon
 * 
 *         <code>Context</code> for Implement JSF Servlet specific functions Do
 *         not
 * 
 *         perform redirect - but tell <code>Action</code> for internal pipeline
 * 
 *         redirect ? or do normal Cocoon redirect Via Http Environment do not
 *         dispanch -
 * 
 *         use Cocoon generator source parametr, but perform generation Full
 * 
 *         Cocoon-specific realization ;
 * 
 * 
 * 
 */
public abstract class AbstractExternalContext extends ExternalContext {

	public static final String WSRP_REWRITE = "wsrp_rewrite?";

	/**
	 * Request parameter to store current View Id.
	 */
	public static final String VIEW_ID_PARAMETER = "org.jboss.portletbridge.VIEWID";

	protected static final String[] EMPTY_STRING_ARRAY = new String[0];
	public static final String PORTLET_CONFIG_ATTRIBUTE = "org.jboss.portletbridge.CONFIG";
	public static final String INITIAL_REQUEST_ATTRIBUTES_NAMES = "org.jboss.portletbridge.REQUEST_PARAMETERS";
	public static final Object RENDER_POLICY_ATTRIBUTE = "org.jboss.portletbridge.RENDER_POLICY";
	public static final String PORTAL_USER_PRINCIPAL = "org.jboss.portletbridge.USER_PRINCIPAL";
	// TODO - optimization.
	private Map<String, Object> applicationMap;

	private Map<String, String> initParameterMap;

	private Map<String, String> requestHeaderMap = null;

	private Map<String, String[]> requestHeaderValues;

	private Map<String, Object> requestMap;

	private Map<String, String> requestParameterMap;

	private Map<String, String[]> requestParameterValuesMap;

	private Map<String, Object> sessionMap;

	private Object request;

	private Object response;

	// private Map<String,Object> actionSettings;

	private Object context;

	private boolean hasNavigationRedirect = false;
	protected PortletBridgeContext portletBridgeContext;
	public static final String CONVERSATION_ID_PARAMETER = "conversationId";

	/**
	 * @return the hasNavigationRedirect
	 */
	boolean isHasNavigationRedirect() {
		return hasNavigationRedirect;
	}

	/**
	 * @param hasNavigationRedirect
	 *            the hasNavigationRedirect to set
	 */
	void setHasNavigationRedirect(boolean hasNavigationRedirect) {
		this.hasNavigationRedirect = hasNavigationRedirect;
	}

	/**
	 * 
	 * @param context
	 * @param request
	 * @param response
	 * @param defaultContext
	 *            -
	 * 
	 *            default implementation of <code>ExternalFacesContext</code>.
	 * 
	 */
	public AbstractExternalContext(Object context, Object request,
			Object response) {
		super();
		this.context = context;
		this.request = request;
		this.response = response;
	}

	protected abstract String getNamespace();

	public String encodeNamespace(String name) {

		return getNamespace() + name;
	}

	/*
	 * 
	 * (non-Javadoc)
	 * 
	 * 
	 * 
	 * @see javax.faces.context.ExternalContext#dispatch(java.lang.String)
	 */
	public Map<String, Object> getApplicationMap() {
		if (this.applicationMap == null) {
			this.applicationMap = new ContextAttributesMap<Object>() {
				protected Enumeration<String> getEnumeration() {
					return getContextAttributeNames();
				}

				protected Object getAttribute(String name) {
					return getContextAttribute(name);
				}

				protected void setAttribute(String name, Object value) {
					setContextAttribute(name, value);
				}

				protected void removeAttribute(String name) {
					removeContextAttribute(name);
				}
			};
		}
		return this.applicationMap;
	}

	protected abstract void removeContextAttribute(String name);

	protected abstract void setContextAttribute(String name, Object value);

	protected abstract Object getContextAttribute(String name);

	protected abstract Enumeration<String> getContextAttributeNames();

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.faces.context.ExternalContext#getAuthType()
	 */
	public Object getContext() {
		return this.context;
	}

	/**
	 * @param context
	 */
	public void setContext(Object context) {
		this.context = context;
		this.applicationMap = null;
		this.initParameterMap = null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.faces.context.ExternalContext#getInitParameter(java.lang.String)
	 */
	@Override
	public Map<String, String> getInitParameterMap() {
		if (this.initParameterMap == null) {
			this.initParameterMap = new ContextAttributesMap<String>() {
				protected String getAttribute(String name) {
					return getInitParameter(name);
				}

				protected void setAttribute(String name, String value) {
					throw new UnsupportedOperationException();
				}

				protected Enumeration<String> getEnumeration() {
					return getInitParametersNames();
				}
			};
		}
		return this.initParameterMap;
	}

	/**
	 * Hoock method for initialization parameters.
	 * 
	 * @return
	 */
	protected abstract Enumeration<String> getInitParametersNames();

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.faces.context.ExternalContext#getRequest()
	 */
	public Object getRequest() {
		return this.request;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.faces.context.ExternalContext#setRequest(java.lang.Object)
	 */
	public void setRequest(Object request) {
		this.requestHeaderMap = null;
		this.requestHeaderValues = null;
		this.requestMap = null;
		this.requestParameterMap = null;
		this.requestParameterValuesMap = null;
		this.sessionMap = null;
		this.request = request;
	}

	public Map<String, Object> getRequestCookieMap() {
		// Portlet environment don't have methods to use cookies.
		return Collections.emptyMap();
	}

	/*
	 * 
	 * (non-Javadoc)
	 * 
	 * 
	 * 
	 * @see javax.faces.context.ExternalContext#getRequestHeaderMap()
	 */
	public Map<String, String> getRequestHeaderMap() {
		if (this.requestHeaderMap == null) {
			this.requestHeaderMap = new ContextAttributesMap<String>() {
				protected Enumeration<String> getEnumeration() {
					return getRequestHeaderNames();
				}

				protected String getAttribute(String name) {
					return getRequestHeader(name);
				}

				protected void setAttribute(String name, String value) {
					throw new UnsupportedOperationException();
				}
			};
		}
		return this.requestHeaderMap;
	}

	protected abstract String getRequestHeader(String name);

	protected abstract Enumeration<String> getRequestHeaderNames();

	public Map<String, String[]> getRequestHeaderValuesMap() {
		//
		if (this.requestHeaderValues == null) {
			this.requestHeaderValues = new ContextAttributesMap<String[]>() {
				protected Enumeration<String> getEnumeration() {
					return getRequestHeaderNames();
				}

				protected String[] getAttribute(String name) {
					return getRequestHeaderValues(name);
				}

				protected void setAttribute(String name, String[] value) {
					throw new UnsupportedOperationException();
				}
			};
		}
		return this.requestHeaderValues;
	}

	protected abstract String[] getRequestHeaderValues(String name);

	public Map<String, Object> getRequestMap() {
		if (this.requestMap == null) {
			this.requestMap = new ContextAttributesMap<Object>() {
				protected Enumeration<String> getEnumeration() {
					return getRequestAttributeNames();
				}

				protected Object getAttribute(String name) {
					return getRequestAttribute(name);
				}

				protected void setAttribute(String name, Object value) {
					setRequestAttribute(name, value);
				}

				protected void removeAttribute(String name) {
					removeRequestAttribute(name);
				}
			};
		}
		return this.requestMap;
	}

	protected abstract void removeRequestAttribute(String name);

	protected abstract void setRequestAttribute(String name, Object value);

	protected abstract Object getRequestAttribute(String name);

	protected abstract Enumeration<String> getRequestAttributeNames();

	public Map<String, String> getRequestParameterMap() {
		//
		if (this.requestParameterMap == null) {
			this.requestParameterMap = new ContextAttributesMap<String>() {
				protected Enumeration<String> getEnumeration() {
					return enumerateRequestParameterNames();
				}

				protected String getAttribute(String name) {
					return getRequestParameter(name);
				}

				protected void setAttribute(String name, String value) {
					throw new UnsupportedOperationException();
				}
			};
		}
		return this.requestParameterMap;
	}

	protected abstract String getRequestParameter(String name);

	protected abstract Enumeration<String> enumerateRequestParameterNames();

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.faces.context.ExternalContext#getRequestParameterNames()
	 */
	public Iterator<String> getRequestParameterNames() {
		return new EnumerationIterator<String>(enumerateRequestParameterNames());
	}

	/*
	 * 
	 * (non-Javadoc)
	 * 
	 * 
	 * 
	 * @see javax.faces.context.ExternalContext#getRequestParameterValuesMap()
	 */
	public Map<String, String[]> getRequestParameterValuesMap() {
		if (this.requestParameterValuesMap == null) {
			this.requestParameterValuesMap = new ContextAttributesMap<String[]>() {

				protected Enumeration<String> getEnumeration() {
					return enumerateRequestParameterNames();
				}

				protected String[] getAttribute(String name) {
					return getRequestParameterValues(name);
				}

				protected void setAttribute(String name, String[] value) {
					throw new UnsupportedOperationException();
				}
			};
		}
		return this.requestParameterValuesMap;
	}

	protected abstract String[] getRequestParameterValues(String name);

	/*
	 * 
	 * (non-Javadoc)
	 * 
	 * 
	 * 
	 * @see javax.faces.context.ExternalContext#getResponse()
	 */
	public void setResponse(Object response) {
		this.response = response;
	}

	public Object getResponse() {
		return this.response;
	}

	/*
	 * 
	 * (non-Javadoc)
	 * 
	 * 
	 * 
	 * @see javax.faces.context.ExternalContext#getSessionMap()
	 */
	public Map<String, Object> getSessionMap() {
		if (this.sessionMap == null) {
			this.sessionMap = new ContextAttributesMap<Object>() {

				protected Enumeration<String> getEnumeration() {
					return getSessionAttributeNames();
				}

				protected Object getAttribute(String name) {
					return getSessionAttribute(name);
				}

				protected void setAttribute(String name, Object value) {
					setSessionAttribute(name, value);
				}

				protected void removeAttribute(String name) {
					removeSessionAttribute(name);
				}

			};
		}
		return this.sessionMap;
	}

	protected abstract void removeSessionAttribute(String name);

	protected abstract void setSessionAttribute(String name, Object value);

	protected abstract Object getSessionAttribute(String name);

	protected abstract Enumeration<String> getSessionAttributeNames();

	protected abstract String createActionUrl(PortalActionURL url);

	public String encodeActionURL(String url) {
		if (null == url) {
			throw new NullPointerException();
		}
		String actionUrl = url;
		if (!isSpecialUrl(actionUrl)) {
			try {
				PortalActionURL portalUrl = new PortalActionURL(url);
				boolean inContext = isInContext(portalUrl);
				if (inContext) {
					actionUrl = createActionUrl(portalUrl);
				} else {
					return encodeURL(portalUrl.toString());
				}
			} catch (MalformedURLException e) {
				throw new FacesException(e);
			}
		}
		return fixUrl(actionUrl);
	}

	private String fixUrl(String actionUrl) {
		return actionUrl.replaceAll("\\&amp\\;", "&");
	}

	private boolean isSpecialUrl(String actionUrl) {
		return actionUrl.startsWith("#") || actionUrl.startsWith(WSRP_REWRITE);
	}

	protected abstract String encodeURL(String actionUrl);

	public String encodeResourceURL(String url) {
		if (null == url) {
			throw new NullPointerException();
		}
		if (!isSpecialUrl(url)) {
			try {
				PortalActionURL portalUrl = new PortalActionURL(url);
				// JSR-301 chapter 6.1.3.1 requirements:
				// 1) opaque URL
				String path = portalUrl.getPath();
				if (null != portalUrl.getProtocol() || !path.startsWith("/")) {
					return url;
				} else if (!isInContext(portalUrl)) {
					// 2) hierarchial url outside context.
					encodeBackLink(portalUrl);
					return encodeURL(portalUrl.toString());
				} else if ("true".equalsIgnoreCase(portalUrl
						.getParameter(Bridge.VIEW_LINK))) {
					// 3) hierarchical and targets a resource that is within
					// this application
					portalUrl.removeParameter(Bridge.VIEW_LINK);
					encodeBackLink(portalUrl);
					// 1. view link. TODO - would it better to create renderURL
					// ?
					return encodeActionURL(portalUrl.toString());
				} else {
					// For resources in the portletbridge application context
					// add
					// namespace as URL parameter, to restore portletbridge
					// session.
					// Remove context path from resource ID.
					// TODO detect jsf view reference, even for omited
					// "viewLink" parameter.
					if (path.startsWith("/")) {
						// absolute path, remove context path from ID.
						portalUrl.setPath(path
								.substring(getRequestContextPath().length()));

					} else {
						// resolve relative URL aganist current view.
						FacesContext facesContext = FacesContext
								.getCurrentInstance();
						UIViewRoot viewRoot = facesContext.getViewRoot();
						if (null != viewRoot && null != viewRoot.getViewId()
								&& viewRoot.getViewId().length() > 0) {
							String viewId = viewRoot.getViewId();
							int indexOfSlash = viewId.lastIndexOf('/');
							if (indexOfSlash >= 0) {
								portalUrl.setPath(viewId.substring(0,
										indexOfSlash + 1) + path);
							} else {
								portalUrl.setPath('/' + path);
							}
						} else {
							// No clue where we are
							portalUrl.setPath('/' + path);
						}
					}
					url = createResourceUrl(portalUrl);
				}
			} catch (MalformedURLException e) {
				throw new FacesException(e);
			}
		}
		return fixUrl(url);
	}

	protected boolean isInContext(PortalActionURL portalUrl) {
		String directLink = portalUrl.getParameter(Bridge.DIRECT_LINK);
		if (null != directLink) {
			portalUrl.removeParameter(Bridge.DIRECT_LINK);
			if (Boolean.parseBoolean(directLink)) {
				return false;
			}
		}
		return portalUrl.isInContext(getRequestContextPath());
	}

	protected void encodeBackLink(PortalActionURL portalUrl) {
		String backLink = portalUrl.getParameter(Bridge.BACK_LINK);
		if (null != backLink) {
			portalUrl.removeParameter(Bridge.BACK_LINK);
			FacesContext facesContext = FacesContext.getCurrentInstance();
			String viewId;
			if (null != facesContext.getViewRoot()
					&& null != (viewId = facesContext.getViewRoot().getViewId())) {
				ViewHandler viewHandler = facesContext.getApplication()
						.getViewHandler();
				String actionURL = viewHandler.getActionURL(facesContext,
						viewId);
				portalUrl.addParameter(backLink, encodeActionURL(actionURL));
			}
		}
	}

	protected abstract String createResourceUrl(PortalActionURL portalUrl);
}
