/******************************************************************************
 * $Id$
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.richfaces;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Set;

import org.ajax4jsf.resource.ResourceContext;

/**
 * @author asmirnov
 *
 */
public class ResourceContextWrapper extends ResourceContext {
	
	private final ResourceContext parent;
	private final OutputStream out;

	/**
	 * @param parent
	 */
	public ResourceContextWrapper(ResourceContext parent, OutputStream out) {
	    super();
	    this.parent = parent;
		this.out = out;
	}

	@Override
	public OutputStream getOutputStream() throws IOException {
	    return out;
	}
	/**
     * @param name
     * @return
     * @see org.ajax4jsf.resource.ResourceContext#getContextAttribute(java.lang.String)
     */
    public Object getContextAttribute(String name) {
	    return parent.getContextAttribute(name);
    }

	/**
     * @param name
     * @return
     * @see org.ajax4jsf.resource.ResourceContext#getInitParameter(java.lang.String)
     */
    public String getInitParameter(String name) {
	    return parent.getInitParameter(name);
    }

	/**
     * @return
     * @see org.ajax4jsf.resource.ResourceContext#getPathInfo()
     */
    public String getPathInfo() {
	    return parent.getPathInfo();
    }

	/**
     * @return
     * @see org.ajax4jsf.resource.ResourceContext#getQueryString()
     */
    public String getQueryString() {
	    return parent.getQueryString();
    }

	/**
     * @param dataParameter
     * @return
     * @see org.ajax4jsf.resource.ResourceContext#getRequestParameter(java.lang.String)
     */
    public String getRequestParameter(String dataParameter) {
	    return parent.getRequestParameter(dataParameter);
    }

	/**
     * @param path
     * @return
     * @throws MalformedURLException
     * @see org.ajax4jsf.resource.ResourceContext#getResource(java.lang.String)
     */
    public URL getResource(String path) throws MalformedURLException {
	    return parent.getResource(path);
    }

	/**
     * @param path
     * @return
     * @see org.ajax4jsf.resource.ResourceContext#getResourceAsStream(java.lang.String)
     */
    public InputStream getResourceAsStream(String path) {
	    return parent.getResourceAsStream(path);
    }

	/**
     * @return
     * @see org.ajax4jsf.resource.ResourceContext#getResourceData()
     */
    public Object getResourceData() {
	    return parent.getResourceData();
    }

	/**
     * @param path
     * @return
     * @see org.ajax4jsf.resource.ResourceContext#getResourcePaths(java.lang.String)
     */
    public Set<String> getResourcePaths(String path) {
	    return parent.getResourcePaths(path);
    }

	/**
     * @return
     * @see org.ajax4jsf.resource.ResourceContext#getServletPath()
     */
    public String getServletPath() {
	    return parent.getServletPath();
    }

	/**
     * @param name
     * @return
     * @see org.ajax4jsf.resource.ResourceContext#getSessionAttribute(java.lang.String)
     */
    public Object getSessionAttribute(String name) {
	    return parent.getSessionAttribute(name);
    }

	/**
     * @return
     * @throws IOException
     * @see org.ajax4jsf.resource.ResourceContext#getWriter()
     */
    public PrintWriter getWriter() throws IOException {
	    return parent.getWriter();
    }

	/**
     * @return
     * @see java.lang.Object#hashCode()
     */
    public int hashCode() {
	    return parent.hashCode();
    }

	/**
     * @return
     * @see org.ajax4jsf.resource.ResourceContext#isCacheEnabled()
     */
    public boolean isCacheEnabled() {
	    return parent.isCacheEnabled();
    }

	/**
     * 
     * @see org.ajax4jsf.resource.ResourceContext#release()
     */
    public void release() {
	    parent.release();
    }

	/**
     * @param cacheEnabled
     * @see org.ajax4jsf.resource.ResourceContext#setCacheEnabled(boolean)
     */
    public void setCacheEnabled(boolean cacheEnabled) {
	    parent.setCacheEnabled(cacheEnabled);
    }

	/**
     * @param contentLength
     * @see org.ajax4jsf.resource.ResourceContext#setContentLength(int)
     */
    public void setContentLength(int contentLength) {
	    parent.setContentLength(contentLength);
    }

	/**
     * @param contentType
     * @see org.ajax4jsf.resource.ResourceContext#setContentType(java.lang.String)
     */
    public void setContentType(String contentType) {
	    parent.setContentType(contentType);
    }

	/**
     * @param name
     * @param value
     * @see org.ajax4jsf.resource.ResourceContext#setDateHeader(java.lang.String, long)
     */
    public void setDateHeader(String name, long value) {
	    parent.setDateHeader(name, value);
    }

	/**
     * @param name
     * @param value
     * @see org.ajax4jsf.resource.ResourceContext#setHeader(java.lang.String, java.lang.String)
     */
    public void setHeader(String name, String value) {
	    parent.setHeader(name, value);
    }

	/**
     * @param name
     * @param value
     * @see org.ajax4jsf.resource.ResourceContext#setIntHeader(java.lang.String, int)
     */
    public void setIntHeader(String name, int value) {
	    parent.setIntHeader(name, value);
    }

	/**
     * @param data
     * @see org.ajax4jsf.resource.ResourceContext#setResourceData(java.lang.Object)
     */
    public void setResourceData(Object data) {
	    parent.setResourceData(data);
    }

}
