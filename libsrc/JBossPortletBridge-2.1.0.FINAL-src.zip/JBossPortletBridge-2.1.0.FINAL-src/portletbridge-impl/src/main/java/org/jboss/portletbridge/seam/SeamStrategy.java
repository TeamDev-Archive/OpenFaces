/******************************************************************************
 * $Id$
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.seam;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.logging.Level;

import javax.faces.FacesException;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;
import javax.faces.lifecycle.Lifecycle;
import javax.faces.render.RenderKitFactory;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceResponse;

import org.jboss.portletbridge.BridgeConfig;
import org.jboss.portletbridge.BridgeStrategy;
import org.jboss.portletbridge.BridgeStrategyWrapper;
import org.jboss.seam.Seam;
import org.jboss.seam.contexts.Contexts;
import org.jboss.seam.contexts.FacesLifecycle;
import org.jboss.seam.core.Init;
import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.jsf.SeamPhaseListener;
import org.jboss.seam.navigation.Pages;

/**
 * @author asmirnov
 *
 */
public class SeamStrategy extends BridgeStrategyWrapper {

	private final BridgeStrategy parent;
	private SeamPhaseListenerWrapper seamListenerWrapper;

	/**
	 * @param config
	 */
	public SeamStrategy(BridgeConfig config,BridgeStrategy parent) {
		super(config);
		// Assert Seam class.
		Seam.class.getName();
		this.parent = parent;
	}


	@Override
    public int getPortletSessionScopeForName(String name) {
		// TODO - cache results to speedup.
		if (Contexts.isApplicationContextActive()) {
			org.jboss.seam.Component component = org.jboss.seam.Component
			        .forName(name);
			if (null == component) {
				return parent.getPortletSessionScopeForName(name);
			}
			final PortletScope portletScope = component.getBeanClass()
			        .getAnnotation(PortletScope.class);

			return null != portletScope ? portletScope.value().getScopeType()
			        : parent.getPortletSessionScopeForName(name);

		} else {
			return parent.getPortletSessionScopeForName(name);
		}
	}


	@Override
    protected BridgeStrategy getWrapped() {
	    return parent;
    }
	
	@Override
	public void init(FacesContext context,
	        RenderKitFactory renderKitFactory) {
		// HACK for PBR-125, reset Seam Renderer field to default value.
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		if(null != classLoader){
			try {
	            Class<?> seamCommandClass = classLoader.loadClass("org.jboss.seam.ui.component.UISeamCommandBase");
	            Field portletRequestField = seamCommandClass.getDeclaredField("PORTLET_REQUEST");
	            if(Modifier.isStatic(portletRequestField.getModifiers())){
	            	portletRequestField.setAccessible(true);
	            	portletRequestField.set(null, null);
	            }
            } catch (ClassNotFoundException e) {
	            // Do nothing, no seam-ui.jar in application.
            } catch (SecurityException e) {
	            // Oops, hack does not work due to java security permissions.
	            log.severe("Security manager does not allow access to the org.jboss.seam.ui.component.UISeamCommandBase class. It is necessary to fix PBR-125 issue");
            } catch (NoSuchFieldException e) {
	            // Do nothing, probably it has been fixed in Seam.
            } catch (IllegalArgumentException e) {
	            // Oops, something unexpected for PORTLET_REQUEST field happens.
	            log.log(Level.SEVERE,"Error in attempt to set null value for org.jboss.seam.ui.component.UISeamCommandBase#PORTLET_REQUEST field. It is necessary to fix PBR-125 issue.",e);
            } catch (IllegalAccessException e) {
	            // Oops, hack does not work due to java security permissions.
	            log.log(Level.SEVERE,"Security manager does not allow access to the org.jboss.seam.ui.component.UISeamCommandBase class. It is necessary to fix PBR-125 issue",e);
            }
		}
		// Replace Seam phaseListener by the portlet version.
		Lifecycle lifecycle = getConfig().getFacesLifecycle();
		for (PhaseListener listener : lifecycle.getPhaseListeners()) {
	         if(SeamPhaseListener.class.equals(listener.getClass())){
	        	 	lifecycle.removePhaseListener(listener);
	                seamListenerWrapper = new SeamPhaseListenerWrapper(listener);
	                lifecycle.addPhaseListener(seamListenerWrapper);
	          }
        }
		if(null == seamListenerWrapper){
			seamListenerWrapper = new SeamPhaseListenerWrapper(null);
		}
	    parent.init(context, renderKitFactory);
	}
	
	@Override
	public void beforeActionRequest(FacesContext facesContext) {
		// Initialize Seam request.
		seamListenerWrapper.beginRequest(facesContext);
	    super.beforeActionRequest(facesContext);
	}

	@Override
	public void afterActionRequest(FacesContext facesContext) {
	    super.afterActionRequest(facesContext);
	    seamListenerWrapper.saveFacesMessages(facesContext);
	    seamListenerWrapper.finishRequest(facesContext);
	}
	
	@Override
	public void afterActionRequestExecute(FacesContext facesContext) {
	    // Perform page action after execute to do it in the Portlet Action request.
		performPageActions(facesContext);
	    super.afterActionRequestExecute(facesContext);
	}


	private void performPageActions(FacesContext facesContext) {
	    if(!facesContext.getResponseComplete() && !Pages.isDebugPage()){
			if (Init.instance().isTransactionManagementEnabled()) {
				seamListenerWrapper.begin("Page actions");
			}
			FacesLifecycle.setPhaseId(PhaseId.INVOKE_APPLICATION);
			boolean actionsWereCalled = false;
			try {
				actionsWereCalled = Pages.instance().preRender(facesContext);
			} finally {
				if (actionsWereCalled) {
					FacesMessages.afterPhase();
				}
				if (Init.instance().isTransactionManagementEnabled()) {
					seamListenerWrapper.commitOrRollback("After Page actions");
				}
				FacesLifecycle.clearPhaseId();
			}
		}
    }
	@Override
	public void beforeEventRequest(FacesContext facesContext) {
		// Initialize Seam request.
		seamListenerWrapper.beginRequest(facesContext);
	    super.beforeEventRequest(facesContext);
	}

	@Override
	public void afterEventRequest(FacesContext facesContext) {
	    super.afterEventRequest(facesContext);
	    seamListenerWrapper.finishRequest(facesContext);
	}

	@Override
	public void beforeResourceRequest(FacesContext facesContext) {
		// Initialize Seam request.
		seamListenerWrapper.beginRequest(facesContext);
	    super.beforeResourceRequest(facesContext);
	}
	
	@Override
	public void afterResourceRequestExecute(FacesContext facesContext) {
		performPageActions(facesContext);
		seamListenerWrapper.saveFacesMessages(facesContext);
	    super.afterResourceRequestExecute(facesContext);
	}

	@Override
	public void afterResourceRequest(FacesContext facesContext,
	        ResourceResponse wrappedResponse) {
	    super.afterResourceRequest(facesContext, wrappedResponse);
	    seamListenerWrapper.finishRequest(facesContext);
	}
	
	@Override
	public void beforeRenderRequest(FacesContext facesContext) {
		// Initialize Seam request.
		seamListenerWrapper.beginRequest(facesContext);
		if(null != facesContext.getViewRoot()){
			// Use JSF view saved in the ActionRequest.
			FacesLifecycle.setPhaseId(PhaseId.RENDER_RESPONSE);
			seamListenerWrapper.afterRestoreView(facesContext);
		}
	    super.beforeRenderRequest(facesContext);
//	    performPageActions(facesContext);
	}
	
	@Override
	public void afterRenderRequest(FacesContext facesContext,
	        RenderResponse wrappedResponse) {
	    super.afterRenderRequest(facesContext, wrappedResponse);
	    seamListenerWrapper.finishRequest(facesContext);
	}
}
