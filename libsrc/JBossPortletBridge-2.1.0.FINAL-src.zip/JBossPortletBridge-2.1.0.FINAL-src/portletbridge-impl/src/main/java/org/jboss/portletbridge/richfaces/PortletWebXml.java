/******************************************************************************
 * $Id$
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.richfaces;

import java.net.MalformedURLException;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.portlet.faces.Bridge;
import javax.portlet.faces.BridgeUtil;
import javax.servlet.http.HttpServletRequest;

import org.ajax4jsf.webapp.WebXml;
import org.jboss.portletbridge.context.PortalActionURL;

/**
 * @author asmirnov
 *
 */
public class PortletWebXml extends WebXml {

	private final WebXml parent;

	/**
     * @return
     * @see org.ajax4jsf.config.WebXMLParser#getFacesFilterPrefix()
     */
    public String getFacesFilterPrefix() {
	    return parent.getFacesFilterPrefix();
    }

	/**
     * @return
     * @see org.ajax4jsf.config.WebXMLParser#getFacesFilterSuffix()
     */
    public String getFacesFilterSuffix() {
	    return parent.getFacesFilterSuffix();
    }

	/**
     * @param request
     * @return
     * @see org.ajax4jsf.webapp.WebXml#getFacesResourceKey(javax.servlet.http.HttpServletRequest)
     */
    public String getFacesResourceKey(HttpServletRequest request) {
	    return parent.getFacesResourceKey(request);
    }

	/**
     * @param resourcePath
     * @return
     * @see org.ajax4jsf.webapp.WebXml#getFacesResourceKey(java.lang.String)
     */
    public String getFacesResourceKey(String resourcePath) {
	    return parent.getFacesResourceKey(resourcePath);
    }

	/**
     * @param context
     * @param Url
     * @param isGlobal
     * @return
     * @see org.ajax4jsf.webapp.WebXml#getFacesResourceURL(javax.faces.context.FacesContext, java.lang.String, boolean)
     */
    public String getFacesResourceURL(FacesContext context, String Url,
            boolean isGlobal) {
	    String facesResourceURL = parent.getFacesResourceURL(context, Url, isGlobal);
		return directLink(facesResourceURL);
    }

	private String directLink(String Url) {
	    if(BridgeUtil.isPortletRequest()){
	    	try {
	            PortalActionURL url = new PortalActionURL(Url);
	            url.addParameter(Bridge.DIRECT_LINK, "true");
	            return url.toString();
            } catch (MalformedURLException e) {
            }
	    }
	    return Url;
    }

	/**
     * @param context
     * @param Url
     * @return
     * @deprecated
     * @see org.ajax4jsf.webapp.WebXml#getFacesResourceURL(javax.faces.context.FacesContext, java.lang.String)
     */
    public String getFacesResourceURL(FacesContext context, String Url) {
	    return directLink(parent.getFacesResourceURL(context, Url));
    }

	/**
     * @return
     * @see org.ajax4jsf.config.WebXMLParser#getFacesServletMappings()
     */
    public List<String> getFacesServletMappings() {
	    return parent.getFacesServletMappings();
    }

	/**
     * @return
     * @see org.ajax4jsf.config.WebXMLParser#getFacesServletPrefix()
     */
    public String getFacesServletPrefix() {
	    return parent.getFacesServletPrefix();
    }

	/**
     * @return
     * @see org.ajax4jsf.config.WebXMLParser#getFacesServletSuffix()
     */
    public String getFacesServletSuffix() {
	    return parent.getFacesServletSuffix();
    }

	/**
     * @return
     * @see org.ajax4jsf.webapp.WebXml#getGlobalResourcePrefix()
     */
    public String getGlobalResourcePrefix() {
	    return parent.getGlobalResourcePrefix();
    }

	/**
     * @return
     * @deprecated
     * @see org.ajax4jsf.webapp.WebXml#getResourcePrefix()
     */
    public String getResourcePrefix() {
	    return parent.getResourcePrefix();
    }

	/**
     * @return
     * @see org.ajax4jsf.webapp.WebXml#getSessionResourcePrefix()
     */
    public String getSessionResourcePrefix() {
	    return parent.getSessionResourcePrefix();
    }

	/**
     * @param request
     * @return
     * @see org.ajax4jsf.webapp.WebXml#isFacesRequest(javax.servlet.http.HttpServletRequest)
     */
    public boolean isFacesRequest(HttpServletRequest request) {
	    return parent.isFacesRequest(request);
    }

	/**
     * @return
     * @see org.ajax4jsf.webapp.WebXml#isPrefixMapping()
     */
    public boolean isPrefixMapping() {
	    return parent.isPrefixMapping();
    }

	public PortletWebXml(WebXml parent) {
		this.parent = parent;
    }

}
