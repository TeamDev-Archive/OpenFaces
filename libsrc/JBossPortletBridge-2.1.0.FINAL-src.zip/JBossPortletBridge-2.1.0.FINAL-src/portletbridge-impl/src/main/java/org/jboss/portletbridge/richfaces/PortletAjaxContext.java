/**
 * 
 */
package org.jboss.portletbridge.richfaces;

import javax.faces.application.ViewHandler;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.portlet.faces.Bridge;
import javax.portlet.faces.BridgeUtil;

import org.ajax4jsf.context.AjaxContextImpl;

/**
 * @author asmirnov
 *
 */
public class PortletAjaxContext extends AjaxContextImpl {
	
	@Override
	public String getAjaxActionURL(FacesContext context) {
		// Check arguments
		if (null == context) {
			throw new NullPointerException(
					"Faces context for build AJAX Action URL is null");
		}
		UIViewRoot viewRoot = context.getViewRoot();
		if (null == viewRoot) {
			throw new NullPointerException(
					"Faces view tree for build AJAX Action URL is null");
		}
		String viewId = viewRoot.getViewId();
		if (null == viewId) {
			throw new NullPointerException(
					"View id for build AJAX Action URL is null");
		}
		if (!viewId.startsWith("/")) {
			throw new IllegalArgumentException(
					"Illegal view Id for build AJAX Action URL: " + viewId);
		}
		ViewHandler viewHandler = context.getApplication().getViewHandler();
		String actionURL = viewHandler.getActionURL(context, viewId);
		// HACK - check for a Jboss PortletBridge implementation. If present, append DirectLink attribute to url.
		// TODO - how to detect portlet application ?
		if (null != context.getExternalContext().getRequestMap().get(Bridge.PORTLET_LIFECYCLE_PHASE)) {
			// Mark Ajax action url as transparent with jsf-portlet bridge.
			actionURL = actionURL
					+ ((actionURL.lastIndexOf('?') > 0) ? "&" : "?")
					+ Bridge.FACES_VIEW_ID_PARAMETER+"="+viewId;
			return context.getExternalContext().encodeResourceURL(actionURL);
		} else {
			return context.getExternalContext().encodeActionURL(actionURL);
		}
	}

}
