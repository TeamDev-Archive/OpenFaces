/**
 * 
 */
package org.jboss.portletbridge.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

class FilterBean {
	
	private String className;
	private Map<String, String> initParams = new HashMap<String, String>();
	
	public FilterBean() {
	}
	/**
	 * @param name
	 * @param className
	 */
	public FilterBean(String className, Map<String, String> initParams) {
		super();
		this.className = className;
		this.initParams.putAll(initParams);
	}

	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public Map<String, String> getInitParams() {
		return initParams;
	}
}
