/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.renderkit.portlet;

import java.io.IOException;
import java.util.Map;

import javax.faces.component.UIComponent;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import javax.portlet.faces.BridgeUtil;

import org.ajax4jsf.application.AjaxViewHandler;
import org.ajax4jsf.context.AjaxContext;
import org.ajax4jsf.context.ViewResources;
import org.ajax4jsf.renderkit.AjaxContainerRenderer;
import org.ajax4jsf.renderkit.AjaxRendererUtils;
import org.ajax4jsf.renderkit.AjaxViewRootRenderer;
import org.ajax4jsf.renderkit.RendererUtils.HTML;
import org.w3c.dom.Node;

/**
 * @author asmirnov
 *
 */
public class PortletAjaxViewRootRenderer extends AjaxViewRootRenderer {

    protected void doEncodeBegin(ResponseWriter writer, FacesContext context, UIComponent component) throws IOException {
        ExternalContext externalContext = context.getExternalContext();
		Object namespace = externalContext.encodeNamespace("");
        AjaxContext ajaxContext = AjaxContext.getCurrentInstance(context);
        Map<String, Object> requestMap = externalContext.getRequestMap();
        if(requestMap.containsKey("javax.servlet.error.exception")||requestMap.containsKey("javax.servlet.error.status_code")){
        	// All error pages rendered as non-ajax.
        	ajaxContext.setAjaxRequest(false);
        }
        // encode portletbridge window marker
		writer.startElement(HTML.DIV_ELEM, component);
		writer.writeAttribute(HTML.id_ATTRIBUTE, namespace, HTML.id_ATTRIBUTE);
        super.doEncodeBegin(writer, context, component);
    }

    protected void doEncodeEnd(ResponseWriter writer, FacesContext context, UIComponent component) throws IOException {
        super.doEncodeEnd(writer, context, component);
        // Encode portletbridge window marker
        writer.endElement(HTML.DIV_ELEM);
        AjaxContext ajaxContext = AjaxContext.getCurrentInstance(context);
        Object namespace = context.getExternalContext().encodeNamespace("");
        Object ajaxRequestParameter = context.getExternalContext().getRequestParameterMap().get(AjaxContainerRenderer.AJAX_PARAMETER_NAME);
        if(!ajaxContext.isAjaxRequest() && null !=namespace && null != ajaxRequestParameter){
            // Navigation case, set response back to AJAX
            ajaxContext.setAjaxRequest(true);
            ajaxContext.addRenderedArea(namespace.toString());
            AjaxRendererUtils.encodeAreas(context, component);
        }
    }
}
