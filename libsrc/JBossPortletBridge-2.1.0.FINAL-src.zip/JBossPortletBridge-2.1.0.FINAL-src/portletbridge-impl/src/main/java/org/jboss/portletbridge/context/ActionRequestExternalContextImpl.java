/******************************************************************************
 * $Id$
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.context;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.faces.context.FacesContext;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.MimeResponse;
import javax.portlet.PortletContext;
import javax.portlet.PortletMode;
import javax.portlet.PortletModeException;
import javax.portlet.PortletRequest;
import javax.portlet.PortletResponse;
import javax.portlet.WindowState;
import javax.portlet.WindowStateException;
import javax.portlet.faces.Bridge;

/**
 * @author asmirnov
 * 
 */
public class ActionRequestExternalContextImpl extends
        PortletExternalContextImpl {

	// ============================================================
	// public constants

	// ============================================================
	// private constants

	// ============================================================
	// static variables

	// ============================================================
	// instance variables

	// ============================================================
	// constructors

	/**
	 * @param context
	 * @param request
	 * @param response
	 */
	public ActionRequestExternalContextImpl(PortletContext context,
	        ActionRequest request, ActionResponse response) {
		super(context, request, response);
	}

	// ============================================================
	// public methods
	public PortletContext getContext() {
		return (PortletContext) super.getContext();
	}

	public ActionRequest getRequest() {
		return (ActionRequest) super.getRequest();
	}

	public ActionResponse getResponse() {
		return (ActionResponse) super.getResponse();
	}

	public void setRequestCharacterEncoding(String encoding)
	        throws UnsupportedEncodingException {
		try {
			getRequest().setCharacterEncoding(encoding);
		} catch (IllegalStateException e) {
			// TODO: handle exception
		}
	}

	public String getRequestCharacterEncoding() {
		return getRequest().getCharacterEncoding();
	}

	/**
	 * @param url
	 * @return
	 */
	@Override
	protected String createActionUrl(PortalActionURL actionUrl) {
		String viewIdFromUrl = getViewIdFromUrl(actionUrl);
		actionUrl.setPath(getRequestContextPath() + ACTION_URL_DO_NOTHITG);
		actionUrl.setParameter(Bridge.FACES_VIEW_ID_PARAMETER, viewIdFromUrl);
		// Determine mode, window state or secure changes.
		String modeParameter = actionUrl
		        .getParameter(Bridge.PORTLET_MODE_PARAMETER);
		if (null != modeParameter) {
			PortletMode mode = new PortletMode(modeParameter);
			try {
				((ActionResponse) getResponse()).setPortletMode(mode);

			} catch (PortletModeException e) {
				// only valid modes supported.
			}
		}
		String windowStateParameter = actionUrl
		        .getParameter(Bridge.PORTLET_WINDOWSTATE_PARAMETER);
		if (null != windowStateParameter) {
			try {
				WindowState state = new WindowState(windowStateParameter);
				((ActionResponse) getResponse()).setWindowState(state);

			} catch (WindowStateException e) {
				// only valid modes supported.
			}
		}
		return actionUrl.toString();
	}

	
	public void redirect(String url) throws IOException {
		if (null == url || url.length() < 0) {
			throw new NullPointerException("Path to redirect is null");
		}
		PortalActionURL actionURL = new PortalActionURL(url);
		if (url.startsWith("#")
				|| (!actionURL.isInContext(getRequestContextPath()))
				|| "true".equalsIgnoreCase(actionURL
						.getParameter(Bridge.DIRECT_LINK))) {
			getResponse().sendRedirect(url);
         FacesContext.getCurrentInstance().responseComplete();
		} else {
			internalRedirect(actionURL);
		}
	}
	// ============================================================
	// non-public methods

	// ============================================================
	// inner classes

}
