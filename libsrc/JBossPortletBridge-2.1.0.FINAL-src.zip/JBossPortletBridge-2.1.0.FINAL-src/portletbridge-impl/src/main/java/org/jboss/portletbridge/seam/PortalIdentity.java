package org.jboss.portletbridge.seam;

import org.jboss.portletbridge.util.BridgeLogger;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Install;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Observer;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.Startup;
import org.jboss.seam.annotations.intercept.BypassInterceptors;
import org.jboss.seam.contexts.Contexts;
import org.jboss.seam.core.Events;
import org.jboss.seam.security.Credentials;
import org.jboss.seam.security.Identity;

import javax.faces.context.FacesContext;
import javax.portlet.faces.BridgeUtil;
import javax.security.auth.login.LoginException;
import java.io.Serializable;
import java.lang.reflect.Method;
import java.security.Principal;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

@SuppressWarnings("serial")
@Name("org.jboss.seam.security.identity")
@Scope(ScopeType.SESSION)
@BypassInterceptors
@Install(precedence = Install.FRAMEWORK, classDependencies = "javax.portlet.Portlet")
@Startup
public class PortalIdentity extends Identity {

	private static final Logger log = BridgeLogger.SEAM.getLogger();

	private JBossLoginDelegate loginDelegate = new JBossLoginDelegate();

	private boolean isPortletPhase() {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		return null != facesContext ? BridgeUtil.isPortletRequest()
				: false;
	}

	@Observer(Credentials.EVENT_INIT_CREDENTIALS)
	public void initCredentials(Credentials credentials) {
		if (isPortletPhase()) {
			FacesContext facesContext = FacesContext.getCurrentInstance();
			credentials.setUsername(facesContext.getExternalContext()
					.getRemoteUser());
		}
	}

	/**
	 * Attempts to authenticate the user. This method is distinct to the
	 * authenticate() method in that it raises events in response to whether
	 * authentication is successful or not. The following events may be raised
	 * by calling login():
	 * <p/>
	 * org.jboss.seam.security.loginSuccessful - raised when authentication is
	 * successful org.jboss.seam.security.loginFailed - raised when
	 * authentication fails org.jboss.seam.security.alreadyLoggedIn - raised if
	 * the user is already authenticated
	 * 
	 * @return String returns "loggedIn" if user is authenticated, or null if
	 *         not.
	 */
	@Override
	public String login() {
		if (isPortletPhase()) {
			try {
				authenticate();

				if (!isLoggedIn()) {
					throw new LoginException();
				}

				if (log.isLoggable(Level.FINE)) {
					log.fine("Login successful for: " + getUsername());
				}

				if (Events.exists()) {
					Events.instance().raiseEvent(EVENT_LOGIN_SUCCESSFUL);
				}
				return "loggedIn";
			} catch (LoginException ex) {
				getCredentials().invalidate();

				if (log.isLoggable(Level.FINE)) {
					log.log(Level.FINE,"Login failed for: " + getUsername(), ex);
				}
				if (Events.exists()) {
					Events.instance().raiseEvent(EVENT_LOGIN_FAILED, ex);
				}
			}

			return null;

		} else {
			return super.login();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jboss.seam.security.Identity#authenticate()
	 */
	@Override
	public void authenticate() throws LoginException {
		if (isPortletPhase() && null == getJaasConfigName()) {
			if (!isLoggedIn()) {
				preAuthenticate();
				loginDelegate.login(getCredentials().getUsername(), getCredentials().getPassword());
				postAuthenticate();
			}
		} else {
			super.authenticate();
		}
	}

	@Override
	public void logout() {
		loginDelegate.logout();
		super.logout();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jboss.seam.security.Identity#hasRole(java.lang.String)
	 */
	@Override
	public boolean hasRole(String role) {
		if (isPortletPhase()) {
			return FacesContext.getCurrentInstance().getExternalContext()
					.isUserInRole(role);
		} else {
			return super.hasRole(role);
		}
	}

	// @Override
	// public String getUsername()
	// {
	// if (isPortletPhase())
	// {
	// }
	// else
	// {
	// return super.getUsername();
	// String userName = null;
	// if (getRenderRequest() != null &&
	// getRenderRequest().getRealRequest().getUserPrincipal() != null)
	// {
	// userName = getRenderRequest().getRealRequest().getRemoteUser();
	// }
	// return userName;
	// }
	// }

	// private int counter = 0;

	public Principal getPrincipal() {
		if (isPortletPhase()) {
			Principal bridgePrincipal = FacesContext.getCurrentInstance()
					.getExternalContext().getUserPrincipal();
			if(null != bridgePrincipal){
				Set<Principal> principals = getSubject().getPrincipals();
				if(!principals.contains(bridgePrincipal)){
					principals.add(bridgePrincipal);
				}
			}
			return bridgePrincipal;
		} else {
			return super.getPrincipal();
		}
	}

	// =============================================================================
	// Portal engine or other portlets can access to Seam components outside of
	// context
	// ( Liferay portal does it, for example ), where authorization methods are
	// always failed.
	// To prevent such error we bypass authorization in that case. Interceptors
	// can't be used
	// in that case because they are required Seam context too.
	// TODO - design more convininient way.
	// =============================================================================

	@Override
	public void checkPermission(Object target, String action) {
		if (isContextActive()) {
			super.checkPermission(target, action);

		}
	}

	@Override
	public void checkPermission(String name, String action, Object... arg) {
		if (isContextActive()) {
			super.checkPermission(name, action, arg);

		}
	}

	@Override
	public void checkRestriction(String expr) {
		if (isContextActive()) {
			super.checkRestriction(expr);

		}
	}

	@Override
	public void checkRole(String role) {
		if (isContextActive()) {
			super.checkRole(role);

		}
	}

	private boolean isContextActive() {
		return Contexts.isApplicationContextActive() && null != FacesContext.getCurrentInstance();
	}

	/**
	 * jboss login delegate
	 * 
	 * @author Egor Kolesnikov
	 */
	private static class JBossLoginDelegate implements Serializable
   {
		private Class<?> authenticationClass;
		private Object jbossAuthentication;

		public JBossLoginDelegate(){
			try {
				authenticationClass = Class
						.forName("org.jboss.web.tomcat.security.login.WebAuthentication");
				try {
					jbossAuthentication = authenticationClass.newInstance();
				} catch (Exception e) {
					log.log(Level.SEVERE,"JBoss Web Authentication instantiation "
							+ "exception, Web Authentication disabled", e);
				}
			} catch (ClassNotFoundException ex) {
				log.info("JBoss Web Authentication is not available...");
			}
		}

		public void login(String username, String password) {
			if (jbossAuthentication != null) {
				try {
					Method m = authenticationClass.getMethod("login",
					        String.class, Object.class);
					m.invoke(jbossAuthentication, username, password);
				} catch (Exception ex) {
					log.log(Level.SEVERE,
					        "Error logging out with JBoss Web Authentication",
					        ex);
				}
			}
		}

		public void logout() {
			if (jbossAuthentication != null) {
				try {
					Method m = authenticationClass.getMethod("logout");
					m.invoke(jbossAuthentication);
				} catch (Exception ex) {
					log.log(Level.SEVERE,
					        "Error logging out with JBoss Web Authentication",
					        ex);
				}
			}
		}
	}

}
