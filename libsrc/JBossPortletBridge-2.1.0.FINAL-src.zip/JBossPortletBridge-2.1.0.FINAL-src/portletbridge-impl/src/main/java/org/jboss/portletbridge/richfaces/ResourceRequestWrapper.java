/******************************************************************************
 * $Id$
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.richfaces;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.security.Principal;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Map;

import javax.portlet.ResourceRequest;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletInputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * @author asmirnov
 *
 */
public class ResourceRequestWrapper implements HttpServletRequest {
	
	private final ResourceRequest resourceRequest;

	/**
	 * @param resourceRequest
	 */
	public ResourceRequestWrapper(ResourceRequest resourceRequest) {
	    this.resourceRequest = resourceRequest;
	}

	/**
     * @param arg0
     * @return
     * @see javax.portlet.PortletRequest#getAttribute(java.lang.String)
     */
    public Object getAttribute(String arg0) {
	    return resourceRequest.getAttribute(arg0);
    }

	/**
     * @return
     * @see javax.portlet.PortletRequest#getAttributeNames()
     */
    public Enumeration<String> getAttributeNames() {
	    return resourceRequest.getAttributeNames();
    }

	/**
     * @return
     * @see javax.portlet.PortletRequest#getAuthType()
     */
    public String getAuthType() {
	    return resourceRequest.getAuthType();
    }

	/**
     * @return
     * @see javax.portlet.ClientDataRequest#getCharacterEncoding()
     */
    public String getCharacterEncoding() {
	    return resourceRequest.getCharacterEncoding();
    }

	/**
     * @return
     * @see javax.portlet.ClientDataRequest#getContentLength()
     */
    public int getContentLength() {
	    return resourceRequest.getContentLength();
    }

	/**
     * @return
     * @see javax.portlet.ClientDataRequest#getContentType()
     */
    public String getContentType() {
	    return resourceRequest.getContentType();
    }

	/**
     * @return
     * @see javax.portlet.PortletRequest#getContextPath()
     */
    public String getContextPath() {
	    return resourceRequest.getContextPath();
    }

	/**
     * @return
     * @see javax.portlet.PortletRequest#getCookies()
     */
    public Cookie[] getCookies() {
	    return resourceRequest.getCookies();
    }

	/**
     * @return
     * @see javax.portlet.ResourceRequest#getETag()
     */
    public String getETag() {
	    return resourceRequest.getETag();
    }

	/**
     * @return
     * @see javax.portlet.PortletRequest#getLocale()
     */
    public Locale getLocale() {
	    return resourceRequest.getLocale();
    }

	/**
     * @return
     * @see javax.portlet.PortletRequest#getLocales()
     */
    public Enumeration<Locale> getLocales() {
	    return resourceRequest.getLocales();
    }

	/**
     * @return
     * @see javax.portlet.ClientDataRequest#getMethod()
     */
    public String getMethod() {
	    return resourceRequest.getMethod();
    }

	/**
     * @param arg0
     * @return
     * @see javax.portlet.PortletRequest#getParameter(java.lang.String)
     */
    public String getParameter(String arg0) {
	    return resourceRequest.getParameter(arg0);
    }

	/**
     * @return
     * @see javax.portlet.PortletRequest#getParameterMap()
     */
    public Map<String, String[]> getParameterMap() {
	    return resourceRequest.getParameterMap();
    }

	/**
     * @return
     * @see javax.portlet.PortletRequest#getParameterNames()
     */
    public Enumeration<String> getParameterNames() {
	    return resourceRequest.getParameterNames();
    }

	/**
     * @param arg0
     * @return
     * @see javax.portlet.PortletRequest#getParameterValues(java.lang.String)
     */
    public String[] getParameterValues(String arg0) {
	    return resourceRequest.getParameterValues(arg0);
    }

	/**
     * @return
     * @throws UnsupportedEncodingException
     * @throws IOException
     * @see javax.portlet.ClientDataRequest#getReader()
     */
    public BufferedReader getReader() throws UnsupportedEncodingException,
            IOException {
	    return resourceRequest.getReader();
    }

	/**
     * @return
     * @see javax.portlet.PortletRequest#getRemoteUser()
     */
    public String getRemoteUser() {
	    return resourceRequest.getRemoteUser();
    }

	/**
     * @return
     * @see javax.portlet.PortletRequest#getRequestedSessionId()
     */
    public String getRequestedSessionId() {
	    return resourceRequest.getRequestedSessionId();
    }

	/**
     * @return
     * @see javax.portlet.PortletRequest#getScheme()
     */
    public String getScheme() {
	    return resourceRequest.getScheme();
    }

	/**
     * @return
     * @see javax.portlet.PortletRequest#getServerName()
     */
    public String getServerName() {
	    return resourceRequest.getServerName();
    }

	/**
     * @return
     * @see javax.portlet.PortletRequest#getServerPort()
     */
    public int getServerPort() {
	    return resourceRequest.getServerPort();
    }

	/**
     * @return
     * @see javax.portlet.PortletRequest#getUserPrincipal()
     */
    public Principal getUserPrincipal() {
	    return resourceRequest.getUserPrincipal();
    }

	/**
     * @return
     * @see javax.portlet.PortletRequest#isRequestedSessionIdValid()
     */
    public boolean isRequestedSessionIdValid() {
	    return resourceRequest.isRequestedSessionIdValid();
    }

	/**
     * @return
     * @see javax.portlet.PortletRequest#isSecure()
     */
    public boolean isSecure() {
	    return resourceRequest.isSecure();
    }

	/**
     * @param arg0
     * @return
     * @see javax.portlet.PortletRequest#isUserInRole(java.lang.String)
     */
    public boolean isUserInRole(String arg0) {
	    return resourceRequest.isUserInRole(arg0);
    }

	/**
     * @param arg0
     * @see javax.portlet.PortletRequest#removeAttribute(java.lang.String)
     */
    public void removeAttribute(String arg0) {
	    resourceRequest.removeAttribute(arg0);
    }

	/**
     * @param arg0
     * @param arg1
     * @see javax.portlet.PortletRequest#setAttribute(java.lang.String, java.lang.Object)
     */
    public void setAttribute(String arg0, Object arg1) {
	    resourceRequest.setAttribute(arg0, arg1);
    }

	/**
     * @param arg0
     * @throws UnsupportedEncodingException
     * @see javax.portlet.ClientDataRequest#setCharacterEncoding(java.lang.String)
     */
    public void setCharacterEncoding(String arg0)
            throws UnsupportedEncodingException {
	    resourceRequest.setCharacterEncoding(arg0);
    }

	public long getDateHeader(String name) {
	    // TODO Auto-generated method stub
	    return 0;
    }

	public String getHeader(String name) {
	    if("Content-Length".equals(name)){
	    	return Integer.toString(resourceRequest.getContentLength());
	    }
	    return resourceRequest.getProperty(name);
    }

	public Enumeration getHeaderNames() {
	    return Collections.enumeration(Collections.singleton("Content-Length"));
    }

	public Enumeration getHeaders(String name) {
	    return Collections.enumeration(Collections.singleton(getHeader("Content-Length")));
    }

	public int getIntHeader(String name) {
	    if("Content-Length".equals(name)){
	    	return resourceRequest.getContentLength();
	    }
	    return 0;
    }

	public String getPathInfo() {
	    // TODO Auto-generated method stub
	    return null;
    }

	public String getPathTranslated() {
	    // TODO Auto-generated method stub
	    return null;
    }

	public String getQueryString() {
	    // TODO Auto-generated method stub
	    return null;
    }

	public String getRequestURI() {
	    // TODO Auto-generated method stub
	    return null;
    }

	public StringBuffer getRequestURL() {
	    // TODO Auto-generated method stub
	    return null;
    }

	public String getServletPath() {
	    // TODO Auto-generated method stub
	    return null;
    }

	public HttpSession getSession() {
	    // TODO Auto-generated method stub
	    return null;
    }

	public HttpSession getSession(boolean create) {
	    // TODO Auto-generated method stub
	    return null;
    }

	public boolean isRequestedSessionIdFromCookie() {
	    // TODO Auto-generated method stub
	    return true;
    }

	public boolean isRequestedSessionIdFromURL() {
	    // TODO Auto-generated method stub
	    return false;
    }

	public boolean isRequestedSessionIdFromUrl() {
	    // TODO Auto-generated method stub
	    return false;
    }

	public ServletInputStream getInputStream() throws IOException {

		final InputStream portletInputStream = resourceRequest.getPortletInputStream();

		return new ServletInputStream() {
			
			@Override
			public int read(byte[] b) throws IOException {
			    return portletInputStream.read(b);
			}
			
			@Override
			public int read(byte[] b, int off, int len) throws IOException {
			    return portletInputStream.read(b, off, len);
			}
			
			@Override
			public int read() throws IOException {
				return portletInputStream.read();
			}
		};
    }

	public String getLocalAddr() {
	    // TODO Auto-generated method stub
	    return null;
    }

	public String getLocalName() {
	    // TODO Auto-generated method stub
	    return null;
    }

	public int getLocalPort() {
	    // TODO Auto-generated method stub
	    return 0;
    }

	public String getProtocol() {
	    // TODO Auto-generated method stub
	    return null;
    }

	public String getRealPath(String path) {
	    // TODO Auto-generated method stub
	    return null;
    }

	public String getRemoteAddr() {
	    // TODO Auto-generated method stub
	    return null;
    }

	public String getRemoteHost() {
	    // TODO Auto-generated method stub
	    return null;
    }

	public int getRemotePort() {
	    // TODO Auto-generated method stub
	    return 0;
    }

	public RequestDispatcher getRequestDispatcher(String path) {
	    // TODO Auto-generated method stub
	    return null;
    }

}
