/**
 * 
 */
package org.jboss.portletbridge;

import java.util.logging.Logger;

import javax.faces.context.FacesContext;
import javax.faces.render.RenderKitFactory;
import javax.portlet.PortletSession;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;
import javax.portlet.faces.BridgeException;

import org.jboss.portletbridge.util.BridgeLogger;

/**
 * @author asmirnov
 * 
 */
public class PlainJsfStrategy extends BridgeStrategy {

	private static final Logger log = BridgeLogger.BRIDGE.getLogger();
	public PlainJsfStrategy(BridgeConfig config) {
		super(config);
	}

	public void init(FacesContext context,
			RenderKitFactory renderKitFactory) {
		// DO nothing
	}

	public void beforeRenderRequest(FacesContext facesContext) {
		// Do nothing

	}

	public RenderResponse createResponseWrapper(RenderResponse response) {
		return response;
	}

	public ResourceResponse createResponseWrapper(ResourceResponse response) {
		return response;
	}

	public void afterRenderRequest(FacesContext facesContext,
			RenderResponse wrappedResponse) {
		// DO nothing
		
	}

	@Override
    public void beforeResourceRequest(FacesContext facesContext) {
    	// DO nothing
    }
	
	@Override
	public void afterResourceRequestExecute(FacesContext facesContext) {
	    // TODO save portlet state
	}

	public void afterResourceRequest(FacesContext facesContext,
			ResourceResponse wrappedResponse) {
		// DO nothing
		
	}

	@Override
    public boolean serveResource(ResourceRequest request,
            ResourceResponse response) throws BridgeException {
	    // JSF has no resources service.
	    return false;
    }
	
	@Override
    public int getPortletSessionScopeForName(String name) {
	    return PortletSession.PORTLET_SCOPE;
    }

	@Override
    public void beforeActionRequest(FacesContext facesContext) {
		// DO nothing
	    
    }

	@Override
    public void afterActionRequestExecute(FacesContext facesContext) {
        // DO Nothing
        
    }

	@Override
    public void afterActionRequest(FacesContext facesContext) {
		// DO nothing
	    
    }

	@Override
    public void beforeEventRequest(FacesContext facesContext) {
		// DO nothing
    }

	@Override
    public void afterEventRequest(FacesContext facesContext) {
		// DO nothing
    }


}
