package org.jboss.portletbridge.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.portlet.MimeResponse;
import javax.portlet.ResourceURL;

public class PlatformUtil {

	public enum Platform {
		NA, GENERAL, LIFERAY
	};

	private static final Logger log = BridgeLogger.AJAX.getLogger();

	public static ResourceURL createResourceURL(MimeResponse response) {

		ResourceURL rurl = response.createResourceURL();

		Platform currentPlatform = getPlatform(response);
		if (currentPlatform == Platform.LIFERAY) {
			try {
				Method m = rurl.getClass().getMethod(
						"setCopyCurrentRenderParameters", boolean.class);

				m.invoke(rurl, false);
			} catch (SecurityException e) {
				// should never happen
				log.log(Level.SEVERE, "Cannot disable parameter copy"
						+ " inside Liferay", e);
			} catch (NoSuchMethodException e) {
				log.log(Level.SEVERE, "Cannot disable parameter copy"
						+ " inside Liferay", e);
			} catch (IllegalArgumentException e) {
				log.log(Level.SEVERE, "Cannot disable parameter copy"
						+ " inside Liferay", e);
			} catch (IllegalAccessException e) {
				log.log(Level.SEVERE, "Cannot disable parameter copy"
						+ " inside Liferay", e);
			} catch (InvocationTargetException e) {
				log.log(Level.SEVERE, "Cannot disable parameter copy"
						+ " inside Liferay", e);
			}
		}

		return rurl;

	}

	/**
	 * Getting the current platform based on the package name of the reponse.
	 * 
	 * @param response
	 *            The response that has a package name that contains the name of
	 *            the platform.
	 * @return The derivated platform.
	 */
	private static Platform getPlatform(MimeResponse response) {
      //TODO - this should be done using portletContext.getServerInfo()
      // need to test on LR to see what it returns
		if (response.getClass().getName().indexOf("liferay") > -1) {
			return Platform.LIFERAY;
		} else {
			return Platform.GENERAL;
		}
	}

}
