/******************************************************************************
 * $Id$
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.richfaces;

import java.io.CharArrayReader;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

import javax.faces.context.FacesContext;
import javax.portlet.MimeResponse;
import javax.portlet.PortletContext;
import javax.portlet.faces.BridgeException;
import javax.servlet.ServletException;

import org.ajax4jsf.application.AjaxViewHandler;
import org.ajax4jsf.context.AjaxContext;
import org.ajax4jsf.webapp.ConfigurableXMLFilter;
import org.ajax4jsf.webapp.HtmlParser;
import org.jboss.portletbridge.BufferedMimeResponseWrapper;
import org.jboss.portletbridge.io.FastPrintWriter;
import org.w3c.dom.Node;

/**
 * @author asmirnov
 *
 */
public class PortletXMLFilter extends ConfigurableXMLFilter {
	private static final String PARSERS_LIST_PARAMETER = null;
	//============================================================
	// public constants

	//============================================================
	// private constants

	//============================================================
	// static variables

	//============================================================
	// instance variables

	//============================================================
	// constructors
	public PortletXMLFilter() {
	    
    }
	//============================================================
	// public methods
	public void init(PortletContext context) throws BridgeException {
		ServletPortletContextWrapper wrappedContext = new ServletPortletContextWrapper(context);
		String parsersParameter = context
		.getInitParameter("org.ajax4jsf.xmlparser.ORDER");
	if (null != parsersParameter) {
	    try {
	        configureParsers(wrappedContext, parsersParameter);
        } catch (ServletException e) {
        	throw new BridgeException(e.getMessage());
        }
	}
	}
	
	
	/**
	 * @param wrappedResponse
	 * @throws IOException
	 */
	public void writeContent(FacesContext context, BufferedMimeResponseWrapper wrappedResponse) throws IOException {
    	MimeResponse response = wrappedResponse.getResponse();
    	if(wrappedResponse.isUseWriter()){
    		FastPrintWriter fastPrintWriter = wrappedResponse.getWriter();
    		Reader reader = new CharArrayReader(fastPrintWriter.toCharArray());
			HtmlParser htmlParser = null;
    		try {
    			// TODO - check viewId
				htmlParser = getParser("text/xml", true, context.getViewRoot().getViewId());
				// Setup scripts and styles
				Node[] headEvents = (Node[]) context.getExternalContext().getRequestMap()
			    .get(AjaxContext.HEAD_EVENTS_PARAMETER);
				htmlParser.setHeadNodes(headEvents);
				htmlParser.setDoctype(getPublicid());
				htmlParser.setViewState((String) context.getExternalContext().getRequestMap()
						.get(AjaxViewHandler.SERIALIZED_STATE_KEY));
				htmlParser.parseHtml(reader, response.getWriter());
    		} finally {
    			reuseParser(htmlParser);
    		}
    	}
    	// TODO - code for output stream.
    }
	//============================================================
	// non-public methods

	//============================================================
	// inner classes

}
