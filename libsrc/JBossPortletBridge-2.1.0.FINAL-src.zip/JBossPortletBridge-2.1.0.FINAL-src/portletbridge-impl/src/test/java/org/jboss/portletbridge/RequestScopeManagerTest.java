package org.jboss.portletbridge;

public class RequestScopeManagerTest extends AbstractAjax4jsfPortletTestCase {


	//============================================================
	// public constants

	//============================================================
	// private constants

	//============================================================
	// static variables

	//============================================================
	// instance variables

	//============================================================
	// constructors
	public RequestScopeManagerTest(String name) {
		super(name);
	}

	//============================================================
	// public methods

	public void setUp() throws Exception {
		super.setUp();
	}

	public void tearDown() throws Exception {
		super.tearDown();
	}

	public void testGetInstanceFacesContext() {
		RequestScopeManager requestScopeManager = RequestScopeManager.getInstance(facesContext);
		assertNotNull(requestScopeManager);
		RequestScopeManager requestScopeManager2 = RequestScopeManager.getInstance(facesContext);
		assertSame(requestScopeManager, requestScopeManager2);
	}

	public void testGetInstancePortletRequestInt() {
		this.setupActionRequest();
		RequestScopeManager requestScopeManager = RequestScopeManager.getInstance(actionRequest, 5);
		assertNotNull(requestScopeManager);
		RequestScopeManager requestScopeManager2 = RequestScopeManager.getInstance(actionRequest, 5);
		assertSame(requestScopeManager, requestScopeManager2);		
	}


	public void testGetStateIdActionRequestActionResponse() {
		this.setupActionRequest();
		RequestScopeManager requestScopeManager = RequestScopeManager.getInstance(actionRequest, 5);
		StateId stateId = requestScopeManager.getStateId(actionRequest, actionResponse);
		StateId stateId2 = requestScopeManager.getStateId(actionRequest, actionResponse);
		assertFalse(stateId.equals(stateId2));
	}

	public void testGetStateIdEventRequestEventResponse() {
		this.setupEventRequest();
		RequestScopeManager requestScopeManager = RequestScopeManager.getInstance(eventRequest, 5);
		StateId stateId = requestScopeManager.getStateId(eventRequest, eventResponse);
		StateId stateId2 = requestScopeManager.getStateId(eventRequest, eventResponse);
		assertFalse(stateId.equals(stateId2));
	}

	public void testGetStateIdRenderRequestRenderResponse() {
		this.setupRenderRequest();
		RequestScopeManager requestScopeManager = RequestScopeManager.getInstance(renderRequest, 5);
		StateId stateId = requestScopeManager.getStateId(renderRequest, renderResponse);
		StateId stateId2 = requestScopeManager.getStateId(renderRequest, renderResponse);
		assertTrue(stateId.equals(stateId2));
	}

	public void testGetStateIdResourceRequestResourceResponse() {
	}
	//============================================================
	// non-public methods

	//============================================================
	// inner classes

}
