/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.seam;

import static org.jboss.seam.annotations.Install.FRAMEWORK;

import javax.persistence.EntityManager;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.Status;
import javax.transaction.Synchronization;
import javax.transaction.SystemException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Install;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.intercept.BypassInterceptors;
import org.jboss.seam.transaction.AbstractUserTransaction;

/**
 * @author asmirnov
 *
 */
@Name("org.jboss.seam.transaction.transaction")
@Scope(ScopeType.EVENT)
@Install(value = false, precedence = FRAMEWORK)
@BypassInterceptors
public class MockUserTransaction extends AbstractUserTransaction {

   private static final Log _log = LogFactory.getLog(MockUserTransaction.class);

   private int status = Status.STATUS_NO_TRANSACTION;

   /* (non-Javadoc)
    * @see org.jboss.seam.transaction.AbstractUserTransaction#registerSynchronization(javax.transaction.Synchronization)
    */
   @Override
   public void registerSynchronization(Synchronization arg0) {
      _log.info("registerSyncronisation");
      // TODO Auto-generated method stub
   }

   /* (non-Javadoc)
    * @see javax.transaction.UserTransaction#begin()
    */
   public void begin() throws NotSupportedException, SystemException {
      _log.info("Transaction begin");
      if(status != Status.STATUS_NO_TRANSACTION){
         throw new SystemException("Transaction already active");
      }
      status = Status.STATUS_ACTIVE;
   }

   /* (non-Javadoc)
    * @see javax.transaction.UserTransaction#commit()
    */
   public void commit() throws RollbackException, HeuristicMixedException,
         HeuristicRollbackException, SecurityException,
         IllegalStateException, SystemException {
      _log.info("Transaction commit");
      if(status != Status.STATUS_ACTIVE){
         throw new SystemException("Transaction not active");
      }
      status = Status.STATUS_COMMITTED;
   }

   /* (non-Javadoc)
    * @see javax.transaction.UserTransaction#getStatus()
    */
   public int getStatus() throws SystemException {
      // TODO Auto-generated method stub
      return status;
   }

   /* (non-Javadoc)
    * @see javax.transaction.UserTransaction#rollback()
    */
   public void rollback() throws IllegalStateException, SecurityException,
         SystemException {
      _log.info("transaction rollback");
      if(status != Status.STATUS_ACTIVE){
         throw new SystemException("Transaction not active");
      }
      status = Status.STATUS_ROLLEDBACK;
   }

   /* (non-Javadoc)
    * @see javax.transaction.UserTransaction#setRollbackOnly()
    */
   public void setRollbackOnly() throws IllegalStateException, SystemException {
      _log.info("Transaction set to rollback only");
      status = Status.STATUS_MARKED_ROLLBACK;

   }

   /* (non-Javadoc)
    * @see javax.transaction.UserTransaction#setTransactionTimeout(int)
    */
   public void setTransactionTimeout(int arg0) throws SystemException {
      // TODO Auto-generated method stub

   }

   @Override
   public void enlist(EntityManager entityManager) throws SystemException {
      _log.info("Transaction enlist");
      // do nothing
   }
}
