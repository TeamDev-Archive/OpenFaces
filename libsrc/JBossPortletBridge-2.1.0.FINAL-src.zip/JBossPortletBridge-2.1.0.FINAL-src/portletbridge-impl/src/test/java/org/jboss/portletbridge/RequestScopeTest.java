/******************************************************************************
 * $Id$
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;

/**
 * @author asmirnov
 * 
 */
public class RequestScopeTest extends AbstractAjax4jsfPortletTestCase {

	private static final int NUMBER_OF_MESSAGES = 10;
	// ============================================================
	// public constants

	// ============================================================
	// private constants

	// ============================================================
	// static variables

	// ============================================================
	// instance variables
	private BridgeRequestScope requestScope;

	// ============================================================
	// constructors

	/**
	 * @param name
	 */
	public RequestScopeTest(String name) {
		super(name);
	}

	// ============================================================
	// public methods

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jboss.portletbridge.AbstractAjax4jsfPortletTestCase#setUp()
	 */
	public void setUp() throws Exception {
		super.setUp();
		requestScope = new BridgeRequestScope();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jboss.portletbridge.AbstractAjax4jsfPortletTestCase#tearDown()
	 */
	public void tearDown() throws Exception {
		requestScope = null;
		super.tearDown();
	}

	/**
	 * Test method for
	 * {@link org.jboss.portletbridge.BridgeRequestScope#restoreRequest(javax.faces.context.FacesContext, boolean)}
	 * .
	 */
	public void testRestoreRequest() {
		// fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for
	 * {@link org.jboss.portletbridge.BridgeRequestScope#saveRequest(javax.faces.context.FacesContext, boolean)}
	 * .
	 */
	public void testSaveRequest() {
		// fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for
	 * {@link org.jboss.portletbridge.BridgeRequestScope#saveMessages(javax.faces.context.FacesContext)}
	 * .
	 */
	public void testSaveMessages() {
		setFacesMessages();
		requestScope.saveMessages(facesContext);
		Map<String, List<FacesMessage>> messages = requestScope.getMessages();
		assertEquals(NUMBER_OF_MESSAGES, messages.size());
		assertEquals(2, messages.get("id0").size());
	}

	private void setFacesMessages() {
		for (int i = 0; i < NUMBER_OF_MESSAGES; i++) {
			FacesMessage msg = new FacesMessage("Message" + i);
			FacesMessage errmsg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Error" + i, "ErrorMessage");
			facesContext.addMessage("id" + i, msg);
			facesContext.addMessage("id" + i, errmsg);
		}
	}

	/**
	 * Test method for
	 * {@link org.jboss.portletbridge.BridgeRequestScope#restoreMessages(javax.faces.context.FacesContext)}
	 * .
	 */
	public void testRestoreMessages() {
		Map<String, List<FacesMessage>> messages = createMessagesMap();
		requestScope.setMessages(messages);
		requestScope.restoreMessages(facesContext);
		assertEquals(FacesMessage.SEVERITY_ERROR, facesContext
				.getMaximumSeverity());
		Iterator id5messages = facesContext.getMessages("id5");
		assertTrue(id5messages.hasNext());
		assertNotNull(id5messages.next());
		assertTrue(id5messages.hasNext());
		assertNotNull(id5messages.next());
		assertFalse(id5messages.hasNext());
	}

	private Map<String, List<FacesMessage>> createMessagesMap() {
		Map<String, List<FacesMessage>> messages = new HashMap<String, List<FacesMessage>>();
		for (int i = 0; i < NUMBER_OF_MESSAGES; i++) {
			ArrayList<FacesMessage> messagesList = new ArrayList<FacesMessage>(
					2);
			messagesList.add(new FacesMessage("Message" + i));
			messagesList.add(new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Error" + i, "ErrorMessage"));
			messages.put("id" + i, messagesList);
		}
		return messages;
	}

	/**
	 * Test method for
	 * {@link org.jboss.portletbridge.BridgeRequestScope#saveBeans(javax.faces.context.FacesContext)}
	 * .
	 */
	public void testSaveBeans() {
		// fail("Not yet implemented"); // TODO
	}

	private void createRequestScopeBeans() {

	}

	/**
	 * Test method for
	 * {@link org.jboss.portletbridge.BridgeRequestScope#saveSeamConversationId(javax.faces.context.FacesContext)}
	 * .
	 */
	public void testSaveSeamConversationId() {
		// fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for
	 * {@link org.jboss.portletbridge.BridgeRequestScope#restoreBeans(javax.faces.context.FacesContext)}
	 * .
	 */
	public void testRestoreBeans() {
		// fail("Not yet implemented"); // TODO
	}

	public void testReadWriteObject() throws Exception {
		ByteArrayOutputStream bos = new ByteArrayOutputStream(1024);
		ObjectOutputStream oos = new ObjectOutputStream(bos);
		requestScope.setMessages(createMessagesMap());
		HashMap<String, Object> beans = new HashMap<String, Object>(2);
		beans.put("foo", new SerializableBean("FOO"));
		beans.put("bar", new Bean("BAR"));
		requestScope.setBeans(beans);
		oos.writeObject(requestScope);
		oos.close();
		ByteArrayInputStream bis = new ByteArrayInputStream(bos.toByteArray());
		ObjectInputStream ois = new ObjectInputStream(bis);
		Object readObject = ois.readObject();
		assertTrue(readObject instanceof BridgeRequestScope);
		assertEquals(NUMBER_OF_MESSAGES, ((BridgeRequestScope) readObject).getMessages().size());
		Map<String, Object> beans2 = ((BridgeRequestScope) readObject).getBeans();
		assertEquals(1, beans2.size());
		assertTrue(beans2.containsKey("foo"));
		assertFalse(beans2.containsKey("bar"));
	}

	// ============================================================
	// non-public methods

	// ============================================================
	// inner classes
	public static class SerializableBean implements Serializable {
		/**
		 * 
		 */
		private static final long serialVersionUID = 3536638111140281215L;
		private String value;

		/**
		 * @param value
		 */
		public SerializableBean(String value) {
			this.value = value;
		}

		/**
		 * @return the value
		 */
		public String getValue() {
			return value;
		}

		/**
		 * @param value
		 *            the value to set
		 */
		public void setValue(String value) {
			this.value = value;
		}
	}

	public static class Bean {
		private String value;

		/**
		 * @param value
		 */
		public Bean(String value) {
			this.value = value;
		}

		/**
		 * @return the value
		 */
		public String getValue() {
			return value;
		}

		/**
		 * @param value
		 *            the value to set
		 */
		public void setValue(String value) {
			this.value = value;
		}
	}

}
