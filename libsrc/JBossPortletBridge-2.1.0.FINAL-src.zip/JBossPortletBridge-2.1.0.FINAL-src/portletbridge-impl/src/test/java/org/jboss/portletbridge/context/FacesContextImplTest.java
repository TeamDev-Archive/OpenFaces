/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.context;

import java.util.Iterator;

import javax.el.ELContext;
import javax.faces.application.FacesMessage;
import javax.faces.application.FacesMessage.Severity;
import javax.faces.context.FacesContext;

import org.ajax4jsf.tests.AbstractAjax4JsfTestCase;
import org.jboss.portletbridge.BridgeConfig;
import org.jboss.portletbridge.BridgeRequestScope;
import org.jboss.portletbridge.MockPortletContext;
import org.jboss.portletbridge.RequestScopeManager;
import org.jboss.portletbridge.StateId;

/**
 * @author asmirnov
 *
 */
public class FacesContextImplTest extends AbstractAjax4JsfTestCase {
    private static final StateId STATE_ID = new StateId("1234foo:edit:12345");
	private static final String ID0 = "_id0";
    protected FacesContextImpl portalFacesContext;
    protected AbstractExternalContext servletContextImpl;

    /**
     * @param arg0
     */
    public FacesContextImplTest(String arg0) {
   super(arg0);
    }

    /* (non-Javadoc)
     * @see org.ajax4jsf.tests.AbstractAjax4JsfTestCase#setUp()
     */
    public void setUp() throws Exception {
   super.setUp();
   RequestScopeManager portletStateHolder = RequestScopeManager.getInstance(facesContext);
   BridgeRequestScope portletState = new BridgeRequestScope(){
	   
   };
   portletStateHolder.saveRequestScope(STATE_ID, portletState);
   portalFacesContext = new FacesContextImpl(servletContextImpl,lifecycle);

    }

    /* (non-Javadoc)
     * @see org.ajax4jsf.tests.AbstractAjax4JsfTestCase#tearDown()
     */
    public void tearDown() throws Exception {
   super.tearDown();
//   portalFacesContext.release();
   servletContextImpl = null;
   portalFacesContext = null;
    }

    /**
     * Test method for {@link org.jboss.portletbridge.context.FacesContextImpl#release()}.
     */
    public void testRelease() {
   portalFacesContext.release();
   assertNull(FacesContext.getCurrentInstance());
   try {
       portalFacesContext.getLifecycle();
       fail("Context not released");
   } catch (Exception e) {
   }
    }

    /**
     * Test method for {@link org.jboss.portletbridge.context.FacesContextImpl#renderResponse()}.
     */
    public void testRenderResponse() {
   assertFalse(portalFacesContext.getRenderResponse());
   portalFacesContext.renderResponse();
   assertTrue(portalFacesContext.getRenderResponse());
    }

    /**
     * Test method for {@link org.jboss.portletbridge.context.FacesContextImpl#responseComplete()}.
     */
    public void testResponseComplete() {
   assertFalse(portalFacesContext.getResponseComplete());
   portalFacesContext.responseComplete();
   assertTrue(portalFacesContext.getResponseComplete());
    }

    /**
     * Test method for {@link org.jboss.portletbridge.context.FacesContextImpl#getELContext()}.
     */
    public void testGetELContext() {
   ELContext elContext = portalFacesContext.getELContext();
   assertSame(application.getELResolver(),elContext.getELResolver());
   assertSame(elContext,portalFacesContext.getELContext());
    }

    /**
     * Test method for {@link org.jboss.portletbridge.context.FacesContextImpl#getApplication()}.
     */
    public void testGetApplication() {
   assertSame(application,portalFacesContext.getApplication());
    }

    /**
     * Test method for {@link org.jboss.portletbridge.context.FacesContextImpl#getClientIdsWithMessages()}.
     */
    public void testGetClientIdsWithMessages() {
   portalFacesContext.addMessage(ID0, new FacesMessage());
   Iterator clientIdsWithMessages = portalFacesContext.getClientIdsWithMessages();
   assertTrue(clientIdsWithMessages.hasNext());
   assertEquals(ID0, clientIdsWithMessages.next());
   assertFalse(clientIdsWithMessages.hasNext());
    }

    /**
     * Test method for {@link org.jboss.portletbridge.context.FacesContextImpl#getMaximumSeverity()}.
     */
    public void testGetMaximumSeverity() {
   assertNull(portalFacesContext.getMaximumSeverity());
   portalFacesContext.addMessage(ID0, new FacesMessage());
   Severity maximumSeverity = portalFacesContext.getMaximumSeverity();
   assertEquals(0,maximumSeverity.compareTo(FacesMessage.SEVERITY_INFO));
   portalFacesContext.addMessage("_id1", new FacesMessage(FacesMessage.SEVERITY_ERROR,"error","error detail"));
   maximumSeverity = portalFacesContext.getMaximumSeverity();
   assertEquals(0,maximumSeverity.compareTo(FacesMessage.SEVERITY_ERROR));
    }

    /**
     * Test method for {@link org.jboss.portletbridge.context.FacesContextImpl#getMessages()}.
     */
    public void testGetMessages() {
   FacesMessage facesMessage = new FacesMessage();
   portalFacesContext.addMessage(ID0, facesMessage);
   Iterator messages = portalFacesContext.getMessages();
   assertTrue(messages.hasNext());
   assertSame(facesMessage, messages.next());
   assertFalse(messages.hasNext());
    }

    /**
     * Test method for {@link org.jboss.portletbridge.context.FacesContextImpl#getMessages(java.lang.String)}.
     */
    public void testGetMessagesString() {
   FacesMessage facesMessage = new FacesMessage();
   portalFacesContext.addMessage(ID0, facesMessage);
   portalFacesContext.addMessage("_id1", new FacesMessage());
   Iterator messages = portalFacesContext.getMessages(ID0);
   assertTrue(messages.hasNext());
   assertSame(facesMessage, messages.next());
   assertFalse(messages.hasNext());
    }

    /**
     * Test method for {@link org.jboss.portletbridge.context.FacesContextImpl#getRenderKit()}.
     */
    public void testGetRenderKit() {
   portalFacesContext.setViewRoot(null);
   assertNull(portalFacesContext.getRenderKit());
   portalFacesContext.setViewRoot(facesContext.getViewRoot());
   assertSame(renderKit, portalFacesContext.getRenderKit());
    }
}
