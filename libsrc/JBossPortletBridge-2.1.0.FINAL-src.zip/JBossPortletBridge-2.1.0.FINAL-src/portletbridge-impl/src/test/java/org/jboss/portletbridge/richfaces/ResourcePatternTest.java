package org.jboss.portletbridge.richfaces;

import java.util.regex.Matcher;

import junit.framework.TestCase;

public class ResourcePatternTest extends TestCase {
	
	private static final String FOO_BAR = "/foo/bar";

	public void testNotAresource() throws Exception {
		Matcher matcher = PortletResourceBuilder.RESOURCE_PATTERN.matcher("/foo/bar/DATA/bbb");
		assertFalse(matcher.matches());
	}

	
	public void testNotResourceWithCustomData() throws Exception {
		Matcher matcher = PortletResourceBuilder.RESOURCE_PATTERN.matcher(PortletResourceBuilder.RFRES+FOO_BAR + "/DA/1234");
		assertTrue(matcher.matches());
		assertEquals(3,matcher.groupCount());
		assertEquals(FOO_BAR, matcher.group(1));
		assertEquals("A",matcher.group(2));
		assertEquals("1234",matcher.group(3));
	}

	public void testNotResourceWithBinaryData() throws Exception {
		Matcher matcher = PortletResourceBuilder.RESOURCE_PATTERN.matcher(PortletResourceBuilder.RFRES+FOO_BAR + "/DB/1234");
		assertTrue(matcher.matches());
		assertEquals(3,matcher.groupCount());
		assertEquals(FOO_BAR, matcher.group(1));
		assertEquals("B",matcher.group(2));
		assertEquals("1234",matcher.group(3));
	}
}
