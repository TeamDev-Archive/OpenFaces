package org.jboss.portletbridge;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Locale;

import javax.el.ELContextListener;
import javax.portlet.PortletConfig;
import javax.portlet.faces.Bridge;

public class AjaxBridgeTest extends AbstractAjax4jsfPortletTestCase {

	public AjaxBridgeTest(String name) {
		super(name);
	}

	public void setUp() throws Exception {
		super.setUp();
		servletContext.setDocumentRoot(new File(getClass().getResource("/test/WEB-INF/web.xml").getFile()).getParentFile().getParentFile());
		portletConfig.addInitParameter(Bridge.BRIDGE_PACKAGE_PREFIX + ".defaultViewId.edit", "/foo.xhtml");
      portletConfig.addSupportedLocale(new Locale("en","EN"));
      portletConfig.addSupportedLocale(new Locale("fr","FR"));
		HashMap<String, String> viewIdMap = new HashMap<String, String>();
		viewIdMap.put("edit", "/foo.xml");
		portletContext.setAttribute(Bridge.BRIDGE_PACKAGE_PREFIX + portletConfig.getPortletName() +"."+ Bridge.DEFAULT_VIEWID_MAP, viewIdMap);
	}

	public void tearDown() throws Exception {
		super.tearDown();
	}


	public void testInit() {
		servletContext.addInitParameter("javax.faces.CONFIG_FILES", "/WEB-INF/a-faces-config.xml,/WEB-INF/b-faces-config.xml");
		AjaxPortletBridge bridge = new AjaxPortletBridge();
		bridge.init(portletConfig);
		assertTrue(bridge.isInitialized());
		assertSame(portletConfig, bridge.getPortletConfig());
		assertEquals(portletConfig.getPortletName(), bridge.getPortletName());
		assertEquals(2, bridge.getFacesServletMappings().size());
		assertEquals(6, bridge.getExcludedAttributes().size());
		bridge.destroy();
		assertFalse(bridge.isInitialized());
	}

	public void testInitFaces() throws Exception {
		AjaxPortletBridge bridge = new AjaxPortletBridge(){
			@Override
			public PortletConfig getPortletConfig() {
			    return portletConfig;
			}
		};
		bridge.initFaces(portletContext);
		assertSame(lifecycle, bridge.getFacesLifecycle());
	}
}
