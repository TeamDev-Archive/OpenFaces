/**
 * 
 */
package org.richfaces.test.staging;

/**
 * @author asmirnov
 *
 */
public class URLScanner {

}
