/**
 * Resources-handling functionality
 */
package org.ajax4jsf.resource;
