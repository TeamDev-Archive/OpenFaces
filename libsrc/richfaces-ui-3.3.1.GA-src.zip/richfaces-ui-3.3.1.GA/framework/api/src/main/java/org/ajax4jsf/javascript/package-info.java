/**
 * Classes and interfaces that ease creation of client-side Javascript code
 */
package org.ajax4jsf.javascript;
