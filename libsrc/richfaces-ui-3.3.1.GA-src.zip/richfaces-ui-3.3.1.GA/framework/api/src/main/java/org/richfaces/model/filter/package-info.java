/**
 * Model interfaces and classes of filterable RichFaces components
 */
package org.richfaces.model.filter;
