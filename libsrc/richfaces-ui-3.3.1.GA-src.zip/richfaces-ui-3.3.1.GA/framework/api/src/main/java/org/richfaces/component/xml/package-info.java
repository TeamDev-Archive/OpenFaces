/**
 * Classes that represent XML node data
 */
package org.richfaces.component.xml;
