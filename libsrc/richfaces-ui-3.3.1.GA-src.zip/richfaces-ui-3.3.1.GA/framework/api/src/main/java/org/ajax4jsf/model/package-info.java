/**
 * Various model objects APIs. Contains a set of extended data models classes
 */
package org.ajax4jsf.model;
