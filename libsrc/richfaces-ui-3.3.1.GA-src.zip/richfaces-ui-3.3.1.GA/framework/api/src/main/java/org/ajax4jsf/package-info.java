/**
 * Base package for AJAX classes
 */
package org.ajax4jsf;
