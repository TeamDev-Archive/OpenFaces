/**
 * Interfaces and classes representing selection in RichFaces components
 */
package org.richfaces.model.selection;
