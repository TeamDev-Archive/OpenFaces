/**
 * Cache APIs
 */
package org.ajax4jsf.cache;
