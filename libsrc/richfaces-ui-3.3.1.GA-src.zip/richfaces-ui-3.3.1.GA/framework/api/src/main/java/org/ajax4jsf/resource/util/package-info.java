/**
 * Helper classes for various purposes of resources handling
 */
package org.ajax4jsf.resource.util;
