/**
 * Framework utility classes to handle BASE64 encoding
 */
package org.ajax4jsf.util.base64;
