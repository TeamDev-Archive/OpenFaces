/**
 * Framework utility classes
 */
package org.ajax4jsf.util;
