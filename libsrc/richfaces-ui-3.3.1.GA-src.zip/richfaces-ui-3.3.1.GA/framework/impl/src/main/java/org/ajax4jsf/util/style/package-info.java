/**
 * CSS utility classes
 */
package org.ajax4jsf.util.style;
