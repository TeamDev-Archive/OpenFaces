/**
 * Javascript resource classes either as classes handling various aspects of Javascript processing
 */
package org.ajax4jsf.javascript;
