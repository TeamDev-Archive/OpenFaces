// make it nice to prototype
jQuery.noConflict();