/*
 * Prolog for avoid execute Prototype library twice.
 */

//if(!window.DnD){
