/**
 * Customized implementation of Tidy library
 */
package org.ajax4jsf.org.w3c.tidy;
