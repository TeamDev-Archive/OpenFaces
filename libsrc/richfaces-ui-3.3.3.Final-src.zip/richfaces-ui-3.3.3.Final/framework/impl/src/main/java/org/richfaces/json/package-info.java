/**
 * JSON handling classes. Contains <a href="http://www.json.org">implementation</a> of JSON library together with JSON-based basic container classes implementation
 */
package org.richfaces.json;
