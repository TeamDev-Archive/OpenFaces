/**
 * Implementation of RichFaces skinning
 */
package org.richfaces.skin;
