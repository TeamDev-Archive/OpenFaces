/**
 * Implementation of different supported models
 */
package org.richfaces.model.impl;
