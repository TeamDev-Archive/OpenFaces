/**
 * Custom XML namespace utility classes
 */
package org.richfaces.component.nsutils;
