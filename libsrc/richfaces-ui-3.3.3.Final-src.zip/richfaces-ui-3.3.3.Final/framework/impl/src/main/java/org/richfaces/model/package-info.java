/**
 * Models implementation classes
 */
package org.richfaces.model;
