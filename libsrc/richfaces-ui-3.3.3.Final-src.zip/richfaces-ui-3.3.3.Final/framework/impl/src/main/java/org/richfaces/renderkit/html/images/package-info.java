/**
 * Control and background images
 */
package org.richfaces.renderkit.html.images;
