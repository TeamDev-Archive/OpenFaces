/**
 * Expression-based model classes
 */
package org.richfaces.model.impl.expressive;
