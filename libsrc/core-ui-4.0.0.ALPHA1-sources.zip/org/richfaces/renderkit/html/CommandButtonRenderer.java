package org.richfaces.renderkit.html;

import java.io.IOException;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import javax.faces.render.Renderer;
import org.richfaces.renderkit.html.AjaxCommandButtonRendererBase;

public class CommandButtonRenderer extends AjaxCommandButtonRendererBase {


public void encodeEnd(FacesContext context, UIComponent uiComponent) throws IOException{
UIComponent component = (UIComponent) uiComponent;
ResponseWriter responseWriter = context.getResponseWriter();
responseWriter.startElement("input", component);

getUtils().encodePassThruWithExclusions(context, component, "name onclick type id class", null);

responseWriter.writeAttribute("id", component.getClientId(context), "id");

responseWriter.writeAttribute("name", component.getClientId(context), "name");

responseWriter.writeAttribute("value", component.getAttributes().get("value"), "value");

responseWriter.writeAttribute("class", component.getAttributes().get("styleClass"), "class");

responseWriter.writeAttribute("onclick", this.getOnClick(context,component), "onclick");

encodeTypeAndImage(context,component);
responseWriter.endElement("input");

}

protected Class getComponentClass(){
return UIComponent.class;

}

private String convertToString(Object obj){
return obj == null ? "" : obj.toString();

}

}
