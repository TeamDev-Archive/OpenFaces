package org.richfaces.renderkit.html;

import java.io.IOException;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import javax.faces.render.Renderer;
import org.richfaces.renderkit.AjaxFunctionRendererBase;

public class AjaxFunctionRenderer extends AjaxFunctionRendererBase {


public void encodeEnd(FacesContext context, UIComponent uiComponent) throws IOException{
UIComponent component = (UIComponent) uiComponent;
ResponseWriter responseWriter = context.getResponseWriter();
responseWriter.startElement("span", component);

responseWriter.writeAttribute("id", component.getClientId(context), "id");

responseWriter.writeAttribute("style", "display: none;", "style");

responseWriter.startElement("script", component);

responseWriter.writeAttribute("type", "text/javascript", "type");

responseWriter.writeText(convertToString(this.getFunction(context,component) + ";"), component, null);
responseWriter.endElement("script");
responseWriter.endElement("span");

}

protected Class getComponentClass(){
return UIComponent.class;

}

private String convertToString(Object obj){
return obj == null ? "" : obj.toString();

}

}
