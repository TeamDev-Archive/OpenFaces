package org.richfaces.renderkit.html;

import java.io.IOException;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import javax.faces.render.Renderer;
import org.richfaces.renderkit.AjaxCommandRendererBase;

public class CommandLinkRenderer extends AjaxCommandRendererBase {


public void encodeBegin(FacesContext context, UIComponent uiComponent) throws IOException{
UIComponent component = (UIComponent) uiComponent;
ResponseWriter responseWriter = context.getResponseWriter();
responseWriter.startElement("a", component);

getUtils().encodePassThruWithExclusions(context, component, "value name onclick href id", null);

responseWriter.writeAttribute("id", component.getClientId(context), "id");

responseWriter.writeAttribute("name", component.getClientId(context), "name");

responseWriter.writeAttribute("class", component.getAttributes().get("styleClass"), "class");

responseWriter.writeAttribute("onclick", this.getOnClick(context,component), "onclick");

responseWriter.writeAttribute("href", "#", "href");

responseWriter.writeText(convertToString(component.getAttributes().get("value")), component, null);

}

public void encodeChildren(FacesContext context, UIComponent uiComponent) throws IOException{
UIComponent component = (UIComponent) uiComponent;
ResponseWriter responseWriter = context.getResponseWriter();
renderChildren(context,component);

}

public void encodeEnd(FacesContext context, UIComponent uiComponent) throws IOException{
UIComponent component = (UIComponent) uiComponent;
ResponseWriter responseWriter = context.getResponseWriter();
responseWriter.endElement("a");

}

protected Class getComponentClass(){
return UIComponent.class;

}

private String convertToString(Object obj){
return obj == null ? "" : obj.toString();

}

}
