package org.richfaces.renderkit.html;

import java.io.IOException;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import javax.faces.render.Renderer;
import org.ajax4jsf.renderkit.RendererBase;
import org.richfaces.component.UIAjaxLog;

public class AjaxLogRenderer extends RendererBase {


public void encodeEnd(FacesContext context, UIComponent uiComponent) throws IOException{
UIAjaxLog component = (UIAjaxLog) uiComponent;
ResponseWriter responseWriter = context.getResponseWriter();
responseWriter.startElement("div", component);

getUtils().encodePassThruWithExclusions(context, component, "id class", null);

responseWriter.writeAttribute("id", "richfaces.log", "id");

responseWriter.writeAttribute("class", "rich-log " + component.getAttributes().get("styleClass"), "class");

responseWriter.startElement("script", component);

responseWriter.writeAttribute("type", "text/javascript", "type");

responseWriter.writeText(convertToString("RichFaces.log.setLevel(\"" + component.getAttributes().get("level") + "\");"), component, null);
responseWriter.endElement("script");
responseWriter.endElement("div");

}

protected Class getComponentClass(){
return UIAjaxLog.class;

}

private String convertToString(Object obj){
return obj == null ? "" : obj.toString();

}

}
