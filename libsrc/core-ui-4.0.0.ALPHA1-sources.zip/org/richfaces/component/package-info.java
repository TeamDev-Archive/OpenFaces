/**
 * Fundamental APIs for user interface components
 */
package org.richfaces.component;
