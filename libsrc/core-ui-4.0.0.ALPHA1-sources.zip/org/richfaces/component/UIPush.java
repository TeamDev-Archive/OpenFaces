/**
 * License Agreement.
 *
 * Rich Faces - Natural Ajax for Java Server Faces (JSF)
 *
 * Copyright (C) 2007 Exadel, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 2.1 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
 */

package org.richfaces.component;

import java.io.IOException;

import javax.el.MethodExpression;
import javax.faces.component.NamingContainer;
import javax.faces.component.UICommand;
import javax.faces.context.FacesContext;
import javax.faces.event.BehaviorEvent;
import javax.faces.event.FacesEvent;
import javax.servlet.http.HttpSession;

/**
 * Component for periodically call AJAX events on server ( poll actions )
 * @author shura
 *
 */
public class UIPush extends UICommand {

	public static final String COMPONENT_TYPE = "org.richfaces.Push";

	public final static  String COMPONENT_FAMILY = "org.richfaces.Push";

	private transient boolean hasActiveBehavior = false;
	
	private static enum PropertyKeys {
		eventProducer, enabled, interval
	}
	
	public void encodeBegin(FacesContext context) throws IOException {
		MethodExpression producer = getEventProducer();
		// Subscribe events producer to push status listener.
		if (null != producer) {
			producer.invoke(context.getELContext(), new Object[]{getListener(context)});
		}
		
		super.encodeBegin(context);
	}

	private PushEventTracker getListener(FacesContext context) {
		PushListenersManager pushListenersManager = PushListenersManager.getInstance(context);
		return pushListenersManager.getListener(getListenerId(context));
	}

	public String getListenerId(FacesContext context){
		Object session = context.getExternalContext().getSession(false);
		StringBuffer id = new StringBuffer();
		if(null != session && session instanceof HttpSession){
			HttpSession httpSession = (HttpSession) session;
			id.append(httpSession.getId());
		}
		id.append(context.getViewRoot().getViewId());
		id.append(NamingContainer.SEPARATOR_CHAR);
		id.append(getClientId(context));
		return id.toString();
	}

	public MethodExpression getEventProducer() {
		return (MethodExpression) getStateHelper().get(PropertyKeys.eventProducer);
	}

	public void setEventProducer(MethodExpression producer) {
		getStateHelper().put(PropertyKeys.eventProducer, producer);
	}
	
	/**
	 * @return time in mc for polling interval.
	 */
	public int getInterval() {
		return (Integer) getStateHelper().eval(PropertyKeys.interval, 1000);
	}

	/**
	 * @param interval time in mc for polling interval.
	 */
	public void setInterval(int interval) {
		getStateHelper().put(PropertyKeys.interval, interval);
	}

	public boolean isEnabled() {
		return Boolean.valueOf(getStateHelper().eval(PropertyKeys.enabled, Boolean.TRUE).toString());        
	}

	public void setEnabled(boolean enable) {
		getStateHelper().put(PropertyKeys.enabled, enable);
	}

	@Override
	public String getFamily() {
		return COMPONENT_FAMILY;
	}

	@Override
	public void queueEvent(FacesEvent e) {
		if (e instanceof BehaviorEvent) {
			hasActiveBehavior = true;
		}
		
		super.queueEvent(e);
	}
	
	/**
	 * @return the hasActiveBehavior
	 */
	public boolean isHasActiveBehavior() {
		return hasActiveBehavior;
	}
}
