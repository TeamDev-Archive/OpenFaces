/**
 * License Agreement.
 *
 * Rich Faces - Natural Ajax for Java Server Faces (JSF)
 *
 * Copyright (C) 2007 Exadel, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 2.1 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
 */

package org.richfaces.component.html;

/**
 * @author Nick Belaevski
 * 
 */

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;

import javax.faces.component.behavior.ClientBehaviorHolder;

import org.richfaces.component.UIPush;

public class HtmlPush extends UIPush implements ClientBehaviorHolder {

	public final static String COMPONENT_FAMILY = "org.richfaces.Push";

	public final static String COMPONENT_TYPE = "org.richfaces.Push";

	public static final String ON_DATA_AVAILABLE = "ondataavailable";

	public static final String DATA_AVAILABLE = "dataAvailable";

	private static final Collection<String> EVENT_NAMES = Collections.unmodifiableCollection(
		new LinkedHashSet<String>(Arrays.asList(DATA_AVAILABLE, "begin", "beforedomupdate", "complete")));	

	private static enum PropertyKeys {
		ondataavailable, onbegin, onbeforedomupdate, oncomplete
	}
	
	public HtmlPush(){
		setRendererType("org.richfaces.PushRenderer");
	}

	public String getFamily(){
		return COMPONENT_FAMILY;
	}

	@Override
	public String getDefaultEventName() {
		return DATA_AVAILABLE;
	}

	@Override
	public Collection<String> getEventNames() {
		return EVENT_NAMES;
	}

	public String getOndataavailable() {
		return (String) getStateHelper().eval(PropertyKeys.ondataavailable);
	}
	
	public void setOndataavailable(String ondataavailable) {
		getStateHelper().put(PropertyKeys.ondataavailable, ondataavailable);
	}
	
	public String getOnbegin() {
		return (String) getStateHelper().eval(PropertyKeys.onbegin);
	}
	
	public void setOnbegin(String onbegin) {
		getStateHelper().put(PropertyKeys.onbegin, onbegin);
	}
	
	public String getOnbeforedomupdate() {
		return (String) getStateHelper().eval(PropertyKeys.onbeforedomupdate);
	}
	
	public void setOnbeforedomupdate(String onbeforedomupdate) {
		getStateHelper().put(PropertyKeys.onbeforedomupdate, onbeforedomupdate);
	}
	
	public String getOncomplete() {
		return (String) getStateHelper().eval(PropertyKeys.oncomplete);
	}
	
	public void setOncomplete(String oncomplete) {
		getStateHelper().put(PropertyKeys.oncomplete, oncomplete);
	}
}
