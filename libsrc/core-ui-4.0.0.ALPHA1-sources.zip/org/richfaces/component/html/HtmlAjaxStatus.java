/**
 * License Agreement.
 *
 * Rich Faces - Natural Ajax for Java Server Faces (JSF)
 *
 * Copyright (C) 2007 Exadel, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 2.1 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
 */

package org.richfaces.component.html;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;

import javax.faces.component.behavior.ClientBehaviorHolder;

import org.richfaces.component.UIAjaxStatus;

/**
 * @author Nick Belaevski
 * 
 */
public class HtmlAjaxStatus extends UIAjaxStatus implements ClientBehaviorHolder {

	public static final String COMPONENT_TYPE = "org.richfaces.Status";

	public static final String COMPONENT_FAMILY = "org.richfaces.Status";
	
	private static final Collection<String> EVENT_NAMES = Collections.unmodifiableCollection(
		new LinkedHashSet<String>(
			Arrays.asList("start", "stop", "error", "success"))
	);
			
	private static enum PropertyKeys {
		onstart, onstop, onerror, onsuccess
	}
	
	public HtmlAjaxStatus() {
		setRendererType("org.richfaces.StatusRenderer");
	}
	
	public String getFamily() {
		return COMPONENT_FAMILY;
	}
	
	@Override
	public Collection<String> getEventNames() {
		return EVENT_NAMES;
	}
	
	public String getOnstart() {
		return (String) getStateHelper().eval(PropertyKeys.onstart);
	}
	
	public void setOnstart(String onstart) {
		getStateHelper().put(PropertyKeys.onstart, onstart);
	}
	
	public String getOnstop() {
		return (String) getStateHelper().eval(PropertyKeys.onstop);
	}
	
	public void setOnstop(String onstop) {
		getStateHelper().put(PropertyKeys.onstop, onstop);
	}
	
	public String getOnerror() {
		return (String) getStateHelper().eval(PropertyKeys.onerror);
	}
	
	public void setOnerror(String onerror) {
		getStateHelper().put(PropertyKeys.onerror, onerror);
	}
	
	public String getOnsuccess() {
		return (String) getStateHelper().eval(PropertyKeys.onsuccess);
	}

	public void setOnsuccess(String onsuccess) {
		getStateHelper().put(PropertyKeys.onsuccess, onsuccess);
	}
}
