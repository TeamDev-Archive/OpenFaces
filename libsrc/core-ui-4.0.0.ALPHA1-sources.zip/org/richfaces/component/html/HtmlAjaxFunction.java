package org.richfaces.component.html;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;

import javax.faces.component.UICommand;
import javax.faces.component.behavior.ClientBehaviorHolder;

public class HtmlAjaxFunction extends UICommand implements ClientBehaviorHolder {

	public final static  String COMPONENT_FAMILY = "javax.faces.Command";

	public final static  String COMPONENT_TYPE = "org.richfaces.Function";

	private static final Collection<String> EVENT_NAMES = Collections.unmodifiableCollection(
		new LinkedHashSet<String>(Arrays.asList("begin", "complete", "beforedomupdate"))
	);

	private static enum PropertyKeys {
		limitRender, name, onbeforedomupdate, onbegin, oncomplete, execute, render, status
	}
	
	public HtmlAjaxFunction() {
		setRendererType("org.richfaces.FunctionRenderer");
	}
	
	public boolean isLimitRender() {
		return Boolean.parseBoolean(getStateHelper().eval(PropertyKeys.limitRender, 
			Boolean.FALSE).toString());
	}
	
	public void setLimitRender(boolean limitRenderValue) {
		getStateHelper().put(PropertyKeys.limitRender, limitRenderValue);
	}
	
	public String getName() {
		//TODO required attribute
		return (String) getStateHelper().eval(PropertyKeys.name);
	}
	
	public void setName(String name) {
		getStateHelper().put(PropertyKeys.name, name);
	}
	
	public String getOnbegin() {
		return (String) getStateHelper().eval(PropertyKeys.onbegin);
	}
	
	public void setOnbegin(String onbegin) {
		getStateHelper().put(PropertyKeys.onbegin, onbegin);
	}
	
	public String getOnbeforedomupdate() {
		return (String) getStateHelper().eval(PropertyKeys.onbeforedomupdate);
	}

	public void setOnbeforedomupdate(String onbeforedomupdate) {
		getStateHelper().put(PropertyKeys.onbeforedomupdate, onbeforedomupdate);
	}

	public String getOncomplete() {
		return (String) getStateHelper().eval(PropertyKeys.oncomplete);
	}

	public void setOncomplete(String oncomplete) {
		getStateHelper().put(PropertyKeys.oncomplete, oncomplete);
	}

	public Object getExecute() {
		return getStateHelper().eval(PropertyKeys.execute);
	}
	
	public void setExecute(Object execute) {
		getStateHelper().put(PropertyKeys.execute, execute);
	}
	
	public Object getRender() {
		return getStateHelper().eval(PropertyKeys.render);
	}

	public void setRender(Object render) {
		getStateHelper().put(PropertyKeys.render, render);
	}
	
	public String getStatus() {
		return (String) getStateHelper().eval(PropertyKeys.status);
	}

	public void setStatus(String status) {
		getStateHelper().put(PropertyKeys.status, status);
	}
	
	@Override
	public Collection<String> getEventNames() {
		return EVENT_NAMES;
	}
	
}
