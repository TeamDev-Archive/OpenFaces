package org.richfaces.component.html;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashSet;

import javax.el.MethodExpression;
import javax.faces.component.behavior.ClientBehaviorHolder;

import org.richfaces.component.UIMediaOutput;

public class HtmlMediaOutput extends UIMediaOutput implements ClientBehaviorHolder {

	static public final String COMPONENT_FAMILY = "org.richfaces.MediaOutput";

	static public final String COMPONENT_TYPE = "org.richfaces.MediaOutput";

	private static enum PropertyKeys {
		onblur, onclick, ondblclick, onfocus, onkeydown, onkeypress, onkeyup, onmousedown, 
		onmousemove, onmouseout, onmouseover, onmouseup, rel, rev, type, title, target, 
		tabindex, styleClass, vspace, usemap, shape, standby, style, uriAttribute, accesskey, 
		align, archive, border, element, declare, coords, hreflang, hspace, dir, codetype, codebase, 
		charset, classid, lang, mimeType, lastModified, cacheable, createContentExpression, ismap, 
		session, expires
	}

	private static final Collection<String> EVENT_NAMES = Collections.unmodifiableCollection(
		new LinkedHashSet<String>(
			Arrays.asList("click", "mousemove", "dblclick", "keydown", "keypress",
				"keyup", "mousedown", "mouseout", "mouseover", "mouseup"))
	);
					
	public HtmlMediaOutput() {
		setRendererType("org.richfaces.MediaOutputRenderer");
	}

	public String getAccesskey() {
		return (String) getStateHelper().eval(PropertyKeys.accesskey);
	}

	public void setAccesskey(String accesskey) {
		getStateHelper().put(PropertyKeys.accesskey, accesskey);
	}

	public String getAlign() {
		return (String) getStateHelper().eval(PropertyKeys.align);
	}

	public void setAlign(String align) {
		getStateHelper().put(PropertyKeys.align, align);
	}

	public String getArchive() {
		return (String) getStateHelper().eval(PropertyKeys.archive);
	}

	public void setArchive(String archive) {
		getStateHelper().put(PropertyKeys.archive, archive);
	}

	public String getBorder() {
		return (String) getStateHelper().eval(PropertyKeys.border);
	}

	public void setBorder(String border) {
		getStateHelper().put(PropertyKeys.border, border);
	}

	public boolean isCacheable() {
		return Boolean.parseBoolean(getStateHelper().eval(PropertyKeys.cacheable, 
			Boolean.FALSE).toString());
	}

	public void setCacheable(boolean cacheable) {
		getStateHelper().put(PropertyKeys.cacheable, cacheable);
	}

	public String getCharset() {
		return (String) getStateHelper().eval(PropertyKeys.charset);
	}

	public void setCharset(String charset) {
		getStateHelper().put(PropertyKeys.charset, charset);
	}

	public String getClassid() {
		return (String) getStateHelper().eval(PropertyKeys.classid);
	}

	public void setClassid(String classid) {
		getStateHelper().put(PropertyKeys.classid, classid);
	}

	public String getCodebase() {
		return (String) getStateHelper().eval(PropertyKeys.codebase);
	}

	public void setCodebase(String codebase) {
		getStateHelper().put(PropertyKeys.codebase, codebase);
	}

	public String getCodetype() {
		return (String) getStateHelper().eval(PropertyKeys.codetype);
	}

	public void setCodetype(String codetype) {
		getStateHelper().put(PropertyKeys.codetype, codetype);
	}

	public String getCoords() {
		return (String) getStateHelper().eval(PropertyKeys.coords);
	}

	public void setCoords(String coords) {
		getStateHelper().put(PropertyKeys.coords, coords);
	}

	public MethodExpression getCreateContentExpression() {
		return (MethodExpression) getStateHelper().get(PropertyKeys.createContentExpression);
	}

	public void setCreateContentExpression(
			MethodExpression createContentExpression) {
		getStateHelper().put(PropertyKeys.createContentExpression,
				createContentExpression);
	}

	public String getDeclare() {
		return (String) getStateHelper().eval(PropertyKeys.declare);
	}

	public void setDeclare(String declare) {
		getStateHelper().put(PropertyKeys.declare, declare);
	}

	public String getDir() {
		return (String) getStateHelper().eval(PropertyKeys.dir);
	}

	public void setDir(String dir) {
		getStateHelper().put(PropertyKeys.dir, dir);
	}

	public String getElement() {
		return (String) getStateHelper().eval(PropertyKeys.element);
	}

	public void setElement(String element) {
		getStateHelper().put(PropertyKeys.element, element);
	}

	public Date getExpires() {
		return (Date) getStateHelper().eval(PropertyKeys.expires);
	}

	public void setExpires(Date expires) {
		getStateHelper().put(PropertyKeys.expires, expires);
	}

	public String getHreflang() {
		return (String) getStateHelper().eval(PropertyKeys.hreflang);
	}

	public void setHreflang(String hreflang) {
		getStateHelper().put(PropertyKeys.hreflang, hreflang);
	}

	public String getHspace() {
		return (String) getStateHelper().eval(PropertyKeys.hspace);
	}

	public void setHspace(String hspace) {
		getStateHelper().put(PropertyKeys.hspace, hspace);
	}

	public boolean isIsmap() {
		return Boolean.parseBoolean(getStateHelper().eval(PropertyKeys.ismap, Boolean.FALSE).toString());
	}

	public void setIsmap(boolean ismap) {
		getStateHelper().put(PropertyKeys.ismap, ismap);
	}

	public String getLang() {
		return (String) getStateHelper().eval(PropertyKeys.lang);
	}

	public void setLang(String lang) {
		getStateHelper().put(PropertyKeys.lang, lang);
	}

	public Date getLastModified() {
		return (Date) getStateHelper().eval(PropertyKeys.lastModified);
	}

	public void setLastModified(Date lastModified) {
		getStateHelper().put(PropertyKeys.lastModified, lastModified);
	}

	public String getMimeType() {
		return (String) getStateHelper().eval(PropertyKeys.mimeType);
	}

	public void setMimeType(String mimeType) {
		getStateHelper().put(PropertyKeys.mimeType, mimeType);
	}

	public String getOnblur() {
		return (String) getStateHelper().eval(PropertyKeys.onblur);
	}

	public void setOnblur(String onblur) {
		getStateHelper().put(PropertyKeys.onblur, onblur);
	}

	public String getOnclick() {
		return (String) getStateHelper().eval(PropertyKeys.onclick);
	}

	public void setOnclick(String onclick) {
		getStateHelper().put(PropertyKeys.onclick, onclick);
	}

	public String getOndblclick() {
		return (String) getStateHelper().eval(PropertyKeys.ondblclick);
	}

	public void setOndblclick(String ondblclick) {
		getStateHelper().put(PropertyKeys.ondblclick, ondblclick);
	}

	public String getOnfocus() {
		return (String) getStateHelper().eval(PropertyKeys.onfocus);
	}

	public void setOnfocus(String onfocus) {
		getStateHelper().put(PropertyKeys.onfocus, onfocus);
	}

	public String getOnkeydown() {
		return (String) getStateHelper().eval(PropertyKeys.onkeydown);
	}

	public void setOnkeydown(String onkeydown) {
		getStateHelper().put(PropertyKeys.onkeydown, onkeydown);
	}

	public String getOnkeypress() {
		return (String) getStateHelper().eval(PropertyKeys.onkeypress);
	}

	public void setOnkeypress(String onkeypress) {
		getStateHelper().put(PropertyKeys.onkeypress, onkeypress);
	}

	public String getOnkeyup() {
		return (String) getStateHelper().eval(PropertyKeys.onkeyup);
	}

	public void setOnkeyup(String onkeyup) {
		getStateHelper().put(PropertyKeys.onkeyup, onkeyup);
	}

	public String getOnmousedown() {
		return (String) getStateHelper().eval(PropertyKeys.onmousedown);
	}

	public void setOnmousedown(String onmousedown) {
		getStateHelper().put(PropertyKeys.onmousedown, onmousedown);
	}

	public String getOnmousemove() {
		return (String) getStateHelper().eval(PropertyKeys.onmousemove);
	}

	public void setOnmousemove(String onmousemove) {
		getStateHelper().put(PropertyKeys.onmousemove, onmousemove);
	}

	public String getOnmouseout() {
		return (String) getStateHelper().eval(PropertyKeys.onmouseout);
	}

	public void setOnmouseout(String onmouseout) {
		getStateHelper().put(PropertyKeys.onmouseout, onmouseout);
	}

	public String getOnmouseover() {
		return (String) getStateHelper().eval(PropertyKeys.onmouseover);
	}

	public void setOnmouseover(String onmouseover) {
		getStateHelper().put(PropertyKeys.onmouseover, onmouseover);
	}

	public String getOnmouseup() {
		return (String) getStateHelper().eval(PropertyKeys.onmouseup);
	}

	public void setOnmouseup(String onmouseup) {
		getStateHelper().put(PropertyKeys.onmouseup, onmouseup);
	}

	public String getRel() {
		return (String) getStateHelper().eval(PropertyKeys.rel);
	}

	public void setRel(String rel) {
		getStateHelper().put(PropertyKeys.rel, rel);
	}

	public String getRev() {
		return (String) getStateHelper().eval(PropertyKeys.rev);
	}

	public void setRev(String rev) {
		getStateHelper().put(PropertyKeys.rev, rev);
	}

	@Deprecated
	public boolean isSession() {
		return true;
	}

	@Deprecated
	public void setSession(boolean session) {
		if (!session) {
			//TODO: log
		}
	}

	public String getShape() {
		return (String) getStateHelper().eval(PropertyKeys.shape);
	}

	public void setShape(String shape) {
		getStateHelper().put(PropertyKeys.shape, shape);
	}

	public String getStandby() {
		return (String) getStateHelper().eval(PropertyKeys.standby);
	}

	public void setStandby(String standby) {
		getStateHelper().put(PropertyKeys.standby, standby);
	}

	public String getStyle() {
		return (String) getStateHelper().eval(PropertyKeys.style);
	}

	public void setStyle(String style) {
		getStateHelper().put(PropertyKeys.style, style);
	}

	public String getStyleClass() {
		return (String) getStateHelper().eval(PropertyKeys.styleClass);
	}

	public void setStyleClass(String styleClass) {
		getStateHelper().put(PropertyKeys.styleClass, styleClass);
	}

	public String getTabindex() {
		return (String) getStateHelper().eval(PropertyKeys.tabindex);
	}

	public void setTabindex(String tabindex) {
		getStateHelper().put(PropertyKeys.tabindex, tabindex);
	}

	public String getTarget() {
		return (String) getStateHelper().eval(PropertyKeys.target);
	}

	public void setTarget(String target) {
		getStateHelper().put(PropertyKeys.target, target);
	}

	public String getTitle() {
		return (String) getStateHelper().eval(PropertyKeys.title);
	}

	public void setTitle(String title) {
		getStateHelper().put(PropertyKeys.title, title);
	}

	public String getType() {
		return (String) getStateHelper().eval(PropertyKeys.type);
	}

	public void setType(String type) {
		getStateHelper().put(PropertyKeys.type, type);
	}

	public String getUriAttribute() {
		return (String) getStateHelper().eval(PropertyKeys.uriAttribute);
	}

	public void setUriAttribute(String uriAttribute) {
		getStateHelper().put(PropertyKeys.uriAttribute, uriAttribute);
	}

	public String getUsemap() {
		return (String) getStateHelper().eval(PropertyKeys.usemap);
	}

	public void setUsemap(String usemap) {
		getStateHelper().put(PropertyKeys.usemap, usemap);
	}

	public String getVspace() {
		return (String) getStateHelper().eval(PropertyKeys.vspace);
	}

	public void setVspace(String vspace) {
		getStateHelper().put(PropertyKeys.vspace, vspace);
	}

	public String getFamily() {
		return COMPONENT_FAMILY;
	}
	
	@Override
	public Collection<String> getEventNames() {
		return EVENT_NAMES;
	}
}
