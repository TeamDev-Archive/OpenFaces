/**
 * License Agreement.
 *
 * Rich Faces - Natural Ajax for Java Server Faces (JSF)
 *
 * Copyright (C) 2007 Exadel, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 2.1 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
 */

package org.richfaces.component.html;

/**
 * @author Konstantin Mishin
 * 
 */

import org.richfaces.component.UIAjaxLog;

public class HtmlAjaxLog extends UIAjaxLog {

	public final static  String COMPONENT_TYPE = "org.richfaces.AjaxLog";

	private static enum PropertyKeys {
		style, level, styleClass
	}

	public HtmlAjaxLog(){
		setRendererType("org.richfaces.AjaxLogRenderer");
	}
	
	public String getStyle() {
		return (String) getStateHelper().eval(PropertyKeys.style, "");
	}

	public void setStyle(String style) {
		getStateHelper().put(PropertyKeys.style, style);
	}
	
	public String getLevel() {
		return (String) getStateHelper().eval(PropertyKeys.level, "");
	}

	public void setLevel(String level) {
		getStateHelper().put(PropertyKeys.level, level);
	}
	
	public String getStyleClass() {
		return (String) getStateHelper().eval(PropertyKeys.styleClass, "");
	}

	public void setStyleClass(String styleClass) {
		getStateHelper().put(PropertyKeys.styleClass, styleClass);
	}
}
