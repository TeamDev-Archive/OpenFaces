package org.richfaces.component.html;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;

import javax.faces.component.behavior.ClientBehaviorHolder;

import org.richfaces.component.UIAjaxOutputPanel;

public class HtmlOutputPanel extends UIAjaxOutputPanel implements ClientBehaviorHolder {

	static final public String COMPONENT_FAMILY = "javax.faces.Panel";

	static final public String COMPONENT_TYPE = "org.richfaces.OutputPanel";

	private static enum PropertyKeys {
		dir, lang, layout, onclick, onmousemove, ondblclick, onkeydown, onkeypress, 
		onkeyup, onmousedown, title, style, onmouseout, onmouseover, onmouseup, styleClass
	}

	private static final Collection<String> EVENT_NAMES = Collections.unmodifiableCollection(
		new LinkedHashSet<String>(
			Arrays.asList("click", "mousemove", "dblclick", "keydown", "keypress",
				"keyup", "mousedown", "mouseout", "mouseover", "mouseup"))
	);
	
	public HtmlOutputPanel() {
		super();
		setRendererType("org.richfaces.OutputPanelRenderer");
	}

	public String getDir() {
		return (String) getStateHelper().eval(PropertyKeys.dir);
	}

	public void setDir(String dir) {
		getStateHelper().put(PropertyKeys.dir, dir);
	}

	public String getLang() {
		return (String) getStateHelper().eval(PropertyKeys.lang);
	}

	public void setLang(String lang) {
		getStateHelper().put(PropertyKeys.lang, lang);
	}

	public String getLayout() {
		return (String) getStateHelper().eval(PropertyKeys.layout, "inline");
	}

	public void setLayout(String layout) {
		getStateHelper().put(PropertyKeys.layout, layout);
	}

	public String getOnclick() {
		return (String) getStateHelper().eval(PropertyKeys.onclick);
	}

	public void setOnclick(String onclick) {
		getStateHelper().put(PropertyKeys.onclick, onclick);
	}

	public String getOndblclick() {
		return (String) getStateHelper().eval(PropertyKeys.ondblclick);
	}

	public void setOndblclick(String ondblclick) {
		getStateHelper().put(PropertyKeys.ondblclick, ondblclick);
	}

	public String getOnkeydown() {
		return (String) getStateHelper().eval(PropertyKeys.onkeydown);
	}

	public void setOnkeydown(String onkeydown) {
		getStateHelper().put(PropertyKeys.onkeydown, onkeydown);
	}

	public String getOnkeypress() {
		return (String) getStateHelper().eval(PropertyKeys.onkeypress);
	}

	public void setOnkeypress(String onkeypress) {
		getStateHelper().put(PropertyKeys.onkeypress, onkeypress);
	}

	public String getOnkeyup() {
		return (String) getStateHelper().eval(PropertyKeys.onkeyup);
	}

	public void setOnkeyup(String onkeyup) {
		getStateHelper().put(PropertyKeys.onkeyup, onkeyup);
	}

	public String getOnmousedown() {
		return (String) getStateHelper().eval(PropertyKeys.onmousedown);
	}

	public void setOnmousedown(String onmousedown) {
		getStateHelper().put(PropertyKeys.onmousedown, onmousedown);
	}

	public String getOnmousemove() {
		return (String) getStateHelper().eval(PropertyKeys.onmousemove);
	}

	public void setOnmousemove(String onmousemove) {
		getStateHelper().put(PropertyKeys.onmousemove, onmousemove);
	}

	public String getOnmouseout() {
		return (String) getStateHelper().eval(PropertyKeys.onmouseout);
	}

	public void setOnmouseout(String onmouseout) {
		getStateHelper().put(PropertyKeys.onmouseout, onmouseout);
	}

	public String getOnmouseover() {
		return (String) getStateHelper().eval(PropertyKeys.onmouseover);
	}

	public void setOnmouseover(String onmouseover) {
		getStateHelper().put(PropertyKeys.onmouseover, onmouseover);
	}

	public String getOnmouseup() {
		return (String) getStateHelper().eval(PropertyKeys.onmouseup);
	}

	public void setOnmouseup(String onmouseup) {
		getStateHelper().put(PropertyKeys.onmouseup, onmouseup);
	}

	public String getStyle() {
		return (String) getStateHelper().eval(PropertyKeys.style);
	}

	public void setStyle(String style) {
		getStateHelper().put(PropertyKeys.style, style);
	}

	public String getStyleClass() {
		return (String) getStateHelper().eval(PropertyKeys.styleClass);
	}

	public void setStyleClass(String styleClass) {
		getStateHelper().put(PropertyKeys.styleClass, styleClass);
	}

	public String getTitle() {
		return (String) getStateHelper().eval(PropertyKeys.title);
	}

	public void setTitle(String title) {
		getStateHelper().put(PropertyKeys.title, title);
	}

	public String getFamily() {
		return COMPONENT_FAMILY;
	}

	@Override
	public Collection<String> getEventNames() {
		return EVENT_NAMES;
	}
}
