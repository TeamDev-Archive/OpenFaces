/**
 * License Agreement.
 *
 * Rich Faces - Natural Ajax for Java Server Faces (JSF)
 *
 * Copyright (C) 2007 Exadel, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 2.1 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
 */

package org.richfaces.component.html;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;

import javax.faces.component.UICommand;
import javax.faces.component.behavior.ClientBehaviorHolder;

/**
 * @author Konstantin Mishin
 * 
 */


public class HtmlCommandLink extends UICommand implements ClientBehaviorHolder {

	public final static String COMPONENT_TYPE = "org.richfaces.CommandLink";

	private static enum PropertyKeys {
		style, styleClass, limitRender
	}

	private static final Collection<String> EVENT_NAMES = Collections.unmodifiableCollection(
		new LinkedHashSet<String>(
			Arrays.asList("click", "mousemove", "dblclick", "keydown", "keypress",
				"keyup", "mousedown", "mouseout", "mouseover", "mouseup", "action"))
	);
				
	public HtmlCommandLink() {
		setRendererType("org.richfaces.CommandLinkRenderer");
	}

	public String getStyle() {
		return (String) getStateHelper().eval(PropertyKeys.style, "");
	}

	public void setStyle(String style) {
		getStateHelper().put(PropertyKeys.style, style);
	}

	public String getStyleClass() {
		return (String) getStateHelper().eval(PropertyKeys.styleClass, "");
	}

	public void setStyleClass(String styleClass) {
		getStateHelper().put(PropertyKeys.styleClass, styleClass);
	}
	
	public boolean isLimitRender() {
		return Boolean.valueOf(getStateHelper().eval(PropertyKeys.limitRender, Boolean.FALSE).toString());
	}

	public void setLimitRender(boolean limitRender) {
		getStateHelper().put(PropertyKeys.limitRender, limitRender);
	}
	
	@Override
	public Collection<String> getEventNames() {
		return EVENT_NAMES;
	}
	
	@Override
    public String getDefaultEventName() {
        return "action";
    }
}
