package org.ajax4jsf.facelets.tag;

import java.io.IOException;
import java.util.Collection;

import javax.el.ELContext;
import javax.el.MethodExpression;
import javax.faces.application.Application;
import javax.faces.component.UIComponent;
import javax.faces.component.behavior.ClientBehaviorHolder;
import javax.faces.context.FacesContext;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.event.AjaxBehaviorListener;
import javax.faces.view.BehaviorHolderAttachedObjectHandler;
import javax.faces.view.facelets.BehaviorConfig;
import javax.faces.view.facelets.ComponentHandler;
import javax.faces.view.facelets.CompositeFaceletHandler;
import javax.faces.view.facelets.FaceletContext;
import javax.faces.view.facelets.TagAttribute;
import javax.faces.view.facelets.TagException;
import javax.faces.view.facelets.TagHandler;

import org.ajax4jsf.component.behavior.AjaxBehavior;


public class AjaxHandler extends TagHandler implements BehaviorHolderAttachedObjectHandler {

	private final TagAttribute event;
	private final TagAttribute execute;
	private final TagAttribute render;
	private final TagAttribute disabled;
	private final TagAttribute immediate;
	private final TagAttribute listener;
	private final TagAttribute limitRender;
	private final TagAttribute queueId;
	private final TagAttribute statusId;
	private final TagAttribute similarityGroupingId;
	private final TagAttribute onevent;
	private final TagAttribute onerror;
	private final TagAttribute onbegin;
	private final TagAttribute oncomplete;
	private final TagAttribute onbeforedomupdate;
    private final boolean wrapping;

	
	public AjaxHandler(BehaviorConfig config) {
		super(config);
		this.event = this.getAttribute("event");
		this.execute = this.getAttribute("execute");
		this.render = this.getAttribute("render");
		this.disabled = this.getAttribute("disabled");
		this.immediate = this.getAttribute("immediate");
		this.listener = this.getAttribute("listener");
		this.limitRender = this.getAttribute("limitRender");
		this.queueId = this.getAttribute("queueId");
		this.statusId = this.getAttribute("status");
		this.similarityGroupingId = this.getAttribute("similarityGroupingId");
		this.onevent = this.getAttribute("onevent");
		this.onerror = this.getAttribute("onerror");
		this.onbegin = this.getAttribute("onbegin");
		this.oncomplete = this.getAttribute("oncomplete");
		this.onbeforedomupdate = this.getAttribute("onbeforedomupdate");
		this.wrapping = isWrapping();
	}

	public void apply(FaceletContext fContext, UIComponent parent) throws IOException {
        String eventName = getEventName();
        if(this.wrapping) {
        	nextHandler.apply(fContext, parent);
        } else {
        	applyNested(fContext, parent, eventName);
        }
	}
	
	private void applyNested(FaceletContext ctx, UIComponent parent, String eventName) {

		if (!ComponentHandler.isNew(parent)) {
			return;
		}

		if (UIComponent.isCompositeComponent(parent)) {
			throw new UnsupportedOperationException("This type of configuration is not supported!");
			/*
			BeanInfo componentBeanInfo = (BeanInfo) parent.getAttributes().get(UIComponent.BEANINFO_KEY);
			if (null == componentBeanInfo) {
				throw new TagException(tag, "Error: enclosing composite component does not have BeanInfo attribute");
			}
			BeanDescriptor componentDescriptor = componentBeanInfo.getBeanDescriptor();
			if (null == componentDescriptor) {
				throw new TagException(tag, "Error: enclosing composite component BeanInfo does not have BeanDescriptor");
			}
			
			List<AttachedObjectTarget> targetList = (List<AttachedObjectTarget>) componentDescriptor.getValue(AttachedObjectTarget.ATTACHED_OBJECT_TARGETS_KEY);
	
			if (null == targetList) {
				throw new TagException(tag, "Error: enclosing composite component does not support behavior events");
			}
			
			boolean supportedEvent = false;
			for (AttachedObjectTarget target : targetList) {
				if (target instanceof BehaviorHolderAttachedObjectTarget) {
				   BehaviorHolderAttachedObjectTarget behaviorTarget = (BehaviorHolderAttachedObjectTarget) target;
				   if ((null != eventName && eventName.equals(behaviorTarget.getName()))
				       || (null == eventName && behaviorTarget.isDefaultEvent())) {
				       supportedEvent = true;
				       break;
				   }
				}
			}
			
			if (supportedEvent) {
				CompositeComponentTagHandler.getAttachedObjectHandlers(parent).add(this);
			} else {
				throw new TagException(tag, "Error: enclosing composite component does not support event " + eventName);
			}*/ 
		} else if (parent instanceof ClientBehaviorHolder) {
			applyAttachedObject(ctx, parent, eventName);
		} else {
			throw new TagException(this.tag,"Unable to attach <a4j:ajax> to non-ClientBehaviorHolder parent");
		}
	}

	
/*	private void applyWrapping(FaceletContext ctx, UIComponent parent, String eventName) throws IOException {
		AjaxBehavior ajaxBehavior = createAjaxBehavior(ctx, eventName);

		FacesContext context = ctx.getFacesContext();
		AjaxBehaviors ajaxBehaviors = AjaxBehaviors.getAjaxBehaviors(context, true);
		ajaxBehaviors.pushBehavior(context, ajaxBehavior, eventName); 

		nextHandler.apply(ctx, parent);

		ajaxBehaviors.popBehavior();
	} */ 
	
	
	public void applyAttachedObject(FaceletContext fContext, UIComponent parent, String eventName) {
	     ClientBehaviorHolder bHolder = (ClientBehaviorHolder) parent;
	     if (null == eventName) {
	    	 eventName = bHolder.getDefaultEventName();
	    	 if (null == eventName) {
	    		 throw new TagException(this.tag, "Event attribute could not be determined: " + eventName);
	    	 }
	     } else {
	    	 Collection<String> eventNames = bHolder.getEventNames();
	    	 if (!eventNames.contains(eventName)) {
	    		  throw new TagException(this.tag, eventName + "event is not supported for the " + parent.getClass().getSimpleName());
	    	 }
	     }
	     AjaxBehavior ajaxBehavior = createAjaxBehavior(fContext, eventName);
	     bHolder.addClientBehavior(eventName, ajaxBehavior);
	}
	
	
	public AjaxBehavior createAjaxBehavior(FaceletContext fContext, String eventName) {
		Application application = fContext.getFacesContext().getApplication();
		AjaxBehavior ajaxBehavior = (AjaxBehavior)application.createBehavior(AjaxBehavior.BEHAVIOR_ID);
		
		setBehaviorAttribute(fContext, ajaxBehavior, this.disabled, Boolean.class);
		setBehaviorAttribute(fContext, ajaxBehavior, this.immediate, Boolean.class);
		setBehaviorAttribute(fContext, ajaxBehavior, this.execute, Object.class);
		setBehaviorAttribute(fContext, ajaxBehavior, this.render, Object.class);
		setBehaviorAttribute(fContext, ajaxBehavior, this.limitRender, Boolean.class);
		setBehaviorAttribute(fContext, ajaxBehavior, this.queueId, String.class);
		setBehaviorAttribute(fContext, ajaxBehavior, this.statusId, String.class);
		setBehaviorAttribute(fContext, ajaxBehavior, this.similarityGroupingId, String.class);
		setBehaviorAttribute(fContext, ajaxBehavior, this.onevent, String.class);
		setBehaviorAttribute(fContext, ajaxBehavior, this.onerror, String.class);
		setBehaviorAttribute(fContext, ajaxBehavior, this.onbegin, String.class);
		setBehaviorAttribute(fContext, ajaxBehavior, this.oncomplete, String.class);
		setBehaviorAttribute(fContext, ajaxBehavior, this.onbeforedomupdate, String.class);
		
		registerBehaviorListener(fContext, ajaxBehavior, listener);

		return ajaxBehavior;
	}
	
	public void applyAttachedObject(FacesContext context, UIComponent parent) {
		FaceletContext ctx = (FaceletContext) context.getAttributes().get(FaceletContext.FACELET_CONTEXT_KEY);
		applyAttachedObject(ctx, parent, getEventName());
	}
	
	private void setBehaviorAttribute(FaceletContext ctx, AjaxBehavior behavior, TagAttribute attr, Class<?> type) {
		if (attr != null) {
			behavior.setValueExpression(attr.getLocalName(),
			attr.getValueExpression(ctx, type));
		}    
	}
	 
	public String getEventName() {
		return (this.event != null) ? this.event.getValue() : null;
	}

	public String getFor() {
		return null;
	}
	
    private boolean isWrapping() {
        return ((this.nextHandler instanceof TagHandler) || (this.nextHandler instanceof CompositeFaceletHandler));
    }
    
    public void registerBehaviorListener(FaceletContext fContext, AjaxBehavior behavior, TagAttribute listenerAttr) {
    	if(listenerAttr != null) {
    		MethodExpression mExpression = listenerAttr.getMethodExpression(fContext, Object.class, new Class[]{AjaxBehaviorEvent.class});
    		behavior.addAjaxBehaviorListener(new AjaxBehaviorListenerImpl(mExpression));
    	}
    }
    
    public class AjaxBehaviorListenerImpl implements AjaxBehaviorListener {
    	
    	private MethodExpression methodExpression;
    	
    	public AjaxBehaviorListenerImpl() {};
    	
    	public AjaxBehaviorListenerImpl(MethodExpression expression) {
    		this.methodExpression = expression;
    	}
    	
		public void processAjaxBehavior(AjaxBehaviorEvent event) throws AbortProcessingException {
			if(methodExpression != null) {
				ELContext elContext = FacesContext.getCurrentInstance().getELContext();
			
				try {
					methodExpression.invoke(elContext, new Object[] {event});
				} catch (Exception e) {
					//TODO: log or message ??
					throw new AbortProcessingException(e);
				}
			}
		}
    	
    }

}
