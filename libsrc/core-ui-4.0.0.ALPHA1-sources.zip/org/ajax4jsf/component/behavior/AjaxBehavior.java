package org.ajax4jsf.component.behavior;

import java.util.Collection;
import java.util.Set;

import javax.el.ELContext;
import javax.el.ValueExpression;
import javax.faces.component.behavior.FacesBehavior;
import javax.faces.context.FacesContext;

import org.ajax4jsf.component.AjaxClientBehavior;
import org.ajax4jsf.renderkit.AjaxRendererUtils;

/**
 * @author Anton Belevich
 *
 */
@FacesBehavior(value="org.ajax4jsf.behavior.Ajax")
public class AjaxBehavior extends javax.faces.component.behavior.AjaxBehavior implements AjaxClientBehavior{
    
	public static final String BEHAVIOR_ID = "org.ajax4jsf.behavior.Ajax";
	
	private static enum Attributes {
		
		limitRender, queueId, status, render, execute, similarityGroupingId, oncomplete, onbegin, onbeforedomupdate, other;		
		
		public static Attributes toAttribute(String name) {
			
			try {
				return valueOf(name);
			} catch (Exception ex) {
				return other;
			}
		}
	};
	
	private Boolean limitRender;
  
	private String queueId;
	
	private String statusId;

	private String similarityGroupingId;
	
	private Set <String> render;
	
	private Set <String> execute;
	
	private String oncomplete;
	
	private String onbeforedomupdate;
	
	private String onbegin;
	
	protected Set<String> asSet(Object render) {
		return AjaxRendererUtils.asSet(render);
	}
	
	public void setOnbegin(String onbegin) {
		this.onbegin = onbegin;
		clearInitialState();
	}
	
	public String getOnbegin() {
		if(this.onbegin != null) {
			return this.onbegin;
		}
		
		ValueExpression ve = getValueExpression(Attributes.onbegin.toString());
		if(ve != null) {
			ELContext elContext = FacesContext.getCurrentInstance().getELContext();
			String value = ((String)ve.getValue(elContext));
			return value;
		}
		
		return this.onbegin;
	}
	
	public void setOnbeforedomupdate(String onbeforedomupdate) {
		this.onbeforedomupdate = onbeforedomupdate;
		clearInitialState();
	}
	
	public String getOnbeforedomupdate() {
		if(this.onbeforedomupdate != null) {
			return this.onbeforedomupdate;
		}
		
		ValueExpression ve = getValueExpression(Attributes.onbeforedomupdate.toString());
		if(ve != null) {
			ELContext elContext = FacesContext.getCurrentInstance().getELContext();
			String value = ((String)ve.getValue(elContext));
			return value;
		}
		
		return this.onbeforedomupdate;
	}

	
	public void setOncomplete(String oncomplete) {
		this.oncomplete = oncomplete;
		clearInitialState();
	}
	
	public String getOncomplete() {
		if(this.oncomplete != null) {
			return this.oncomplete;
		}
		
		ValueExpression ve = getValueExpression(Attributes.oncomplete.toString());
		if(ve != null) {
			ELContext elContext = FacesContext.getCurrentInstance().getELContext();
			String value = ((String)ve.getValue(elContext));
			return value;
		}
		
		return this.oncomplete;
	}
	
	public void setRender(Collection<String> render) {
		this.render = asSet(render);
		clearInitialState();
	}
		
	public Collection<String> getRender() {
		return getCollectionValue(render, "RENDER");
 	}
	
	public void setExecute(Collection<String> execute) {
		this.execute = asSet(execute);
		clearInitialState();
	}
	
	public Collection<String> getExecute() {
		return getCollectionValue(execute, Attributes.execute.toString());
	}
			
	protected Collection<String> getCollectionValue(Collection<String> collection, String attribute) {
		if(collection != null) {
			return collection;
		}
		
		ValueExpression ve = getValueExpression(attribute) ;
		if(ve != null) {
			FacesContext context = FacesContext.getCurrentInstance();
			Object value = ve.getValue(context.getELContext());
			return asSet(value);
		}
		
		return this.render;
	}
		
	public String getSimilarityGroupingId() {
		if(this.similarityGroupingId != null) {
			return this.similarityGroupingId;
		}
		
		ValueExpression ve = getValueExpression(Attributes.similarityGroupingId.toString());
		if(ve != null) {
			ELContext elContext = FacesContext.getCurrentInstance().getELContext();
			String value = ((String)ve.getValue(elContext));
			return value;
		}
		
		return this.similarityGroupingId;
	}

	public void setSimilarityGroupingId(String similarityGroupingId) {
		this.similarityGroupingId = similarityGroupingId;
		clearInitialState();
	}
	
	public String getStatus() {
		if(this.statusId != null) {
			return this.statusId;
		}
		
		ValueExpression ve = getValueExpression(Attributes.status.toString());
		if(ve != null) {
			ELContext elContext = FacesContext.getCurrentInstance().getELContext();
			String value = ((String)ve.getValue(elContext));
			return value;
		}
		
		return this.statusId;
	}

	public void setStatus(String statusId) {
		this.statusId = statusId;
		clearInitialState();
	}

	public String getQueueId() {
		if(this.queueId != null) {
			return this.queueId;
		}
		
		ValueExpression ve = getValueExpression(Attributes.queueId.toString());
		if(ve != null) {
			ELContext elContext = FacesContext.getCurrentInstance().getELContext();
			String value = ((String)ve.getValue(elContext));
			return value;
		}
		
		return this.queueId;
	}


	public void setQueueId(String queueId) {
		this.queueId = queueId;
		clearInitialState();
	}


	public boolean isLimitRender() {
		if(this.limitRender != null) {
			return this.limitRender.booleanValue();
		}
		
		ValueExpression ve = getValueExpression(Attributes.limitRender.toString());
		if(ve != null) {
			ELContext elContext = FacesContext.getCurrentInstance().getELContext();
			Boolean value = ((Boolean)ve.getValue(elContext));
			return value != null ? value.booleanValue() : false;
		}
		
		return false;
	}


	public void setLimitRender(boolean limitRender) {
		this.limitRender = limitRender;
		clearInitialState();
	}

	@Override
	public String getRendererType() {
		return BEHAVIOR_ID;
	}
	
	@Override
	public void setValueExpression(String name, ValueExpression expression) {
		if(expression != null && expression.isLiteralText()) {
			Object value = getExpressionLiteralValue(expression);
			switch(Attributes.toAttribute(name)) {
				
				case limitRender: 
					this.limitRender =  value != null ? (Boolean)value : Boolean.FALSE ; break;
				
				case execute :
					this.execute =  value != null ? asSet(value) : null; break;
					
				case render :
					this.render =  value != null ? asSet(value) : null; break;
					
				case queueId : 
					this.queueId =  value != null ? (String)value : null; break;
					
				case status :
					this.statusId =  value != null ? (String)value : null; break;
				
				case similarityGroupingId : 
					this.similarityGroupingId = value != null ? (String)value: null; break;
				
				case onbeforedomupdate : 
					this.onbeforedomupdate = value != null ? (String)value : null; break; 
				
				case onbegin : 
					this.onbegin = value != null ? (String)value : null; break;
					
				case oncomplete : 
					this.oncomplete = value != null ? (String)value : null; break;	
				default: break;	
				
			}
		}
		super.setValueExpression(name, expression);
	}
	
	protected Object getExpressionLiteralValue(ValueExpression expression) {
		return expression != null ? expression.getValue(FacesContext.getCurrentInstance().getELContext()) : null;
	}
	
	@Override
	public Object saveState(FacesContext context) {
		Object superState = super.saveState(context);
		Object[] values;
		
		if (initialStateMarked()) {
			if (superState == null) {
				values = null;
			} else {
				values = new Object[] { superState };
			}
		} else {
			values = new Object[10];
			values[0] = superState;
			values[1] = limitRender;
			values[2] = execute;
			values[3] = render;
			values[4] = queueId;
			values[5] = statusId;
			values[6] = similarityGroupingId;
			values[7] = onbeforedomupdate;
			values[8] = onbegin;
			values[9] = oncomplete;
		}

		return values;
	}
		
	@Override
	public void restoreState(FacesContext context, Object state) {
		if (state != null) {
			
			Object[] values = (Object[]) state;
			super.restoreState(context, values[0]);
			
			if (values.length != 1) {
				this.limitRender = ((Boolean)values[1]).booleanValue();
				this.execute = asSet(values[2]);
				this.render = asSet(values[3]);
				this.queueId = (String)values[4];
				this.statusId = (String)values[5];
				this.similarityGroupingId = (String)values[6];
				this.onbeforedomupdate = (String)values[7];
				this.onbegin = (String)values[8];
				this.oncomplete = (String)values[9];
	            clearInitialState();
			}
		}
	}
}