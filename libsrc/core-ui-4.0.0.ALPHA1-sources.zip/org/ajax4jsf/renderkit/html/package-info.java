/**
 * Tag library contains facelets tag handlers that are useful in creating dynamic reusable components
 */
package org.ajax4jsf.renderkit.html;
