/**
 * Skin functionality APIs
 */
package org.richfaces.skin;
