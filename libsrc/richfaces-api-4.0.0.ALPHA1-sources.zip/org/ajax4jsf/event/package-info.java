/**
 * Interfaces and classes of events and listeners of basic AJAX components
 */
package org.ajax4jsf.event;
