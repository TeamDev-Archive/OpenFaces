package com.sun.facelets;

public class BrokenTestCase extends FaceletTestCase {

    public void testBroken() throws Exception {
        
    }

}
