package com.sun.facelets.tag.jsf.core;

import javax.faces.event.AbortProcessingException;
import javax.faces.event.ActionEvent;
import javax.faces.event.ActionListener;

public class ActionListenerImpl implements ActionListener {
    
    public ActionListenerImpl() {
    }

    public void processAction(ActionEvent e) throws AbortProcessingException {

    }
}
