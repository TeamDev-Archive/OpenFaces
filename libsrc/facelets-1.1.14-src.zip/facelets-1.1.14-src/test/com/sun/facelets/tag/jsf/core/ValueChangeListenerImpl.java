package com.sun.facelets.tag.jsf.core;

import javax.faces.event.AbortProcessingException;
import javax.faces.event.ValueChangeEvent;
import javax.faces.event.ValueChangeListener;

public class ValueChangeListenerImpl implements ValueChangeListener {

    public ValueChangeListenerImpl() {
        super();
        // TODO Auto-generated constructor stub
    }

    public void processValueChange(ValueChangeEvent event)
            throws AbortProcessingException {
        // TODO Auto-generated method stub

    }

}
