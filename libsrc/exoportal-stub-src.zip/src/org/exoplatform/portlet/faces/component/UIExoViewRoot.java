/*
 * Copyright (c) 1998-2007 TeamDev Ltd. All Rights Reserved.
 * Use is subject to license terms.
 */
package org.exoplatform.portlet.faces.component;

import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import java.io.IOException;

/**
 * @author Dmitry Pikhulya
 */
public class UIExoViewRoot extends UIViewRoot {
    public UIExoViewRoot(String viewId) {
    }

    public boolean isComponentView() {
        return false;
    }

    public void renderChildren(FacesContext context) throws IOException {
    }

}
