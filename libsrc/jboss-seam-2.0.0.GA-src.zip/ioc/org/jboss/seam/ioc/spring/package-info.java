@Namespace(value="http://jboss.com/products/seam/spring", prefix="org.jboss.seam.ioc.spring")
package org.jboss.seam.ioc.spring;

import org.jboss.seam.annotations.*;
