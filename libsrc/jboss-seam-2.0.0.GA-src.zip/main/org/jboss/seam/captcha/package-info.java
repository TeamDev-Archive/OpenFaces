/**
 * Integration with jcaptcha.
 */
package org.jboss.seam.captcha;
