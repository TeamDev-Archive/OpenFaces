/**
 * Implementation of pages.xml based navigation
 */
@Namespace(value="http://jboss.com/products/seam/navigation", prefix="org.jboss.seam.navigation")
package org.jboss.seam.navigation;

import org.jboss.seam.annotations.Namespace;
