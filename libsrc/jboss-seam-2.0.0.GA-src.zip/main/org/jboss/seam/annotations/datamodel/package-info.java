/**
 * A set of annotations that simplifies the job of 
 * working with JSF DataModels.
 */
package org.jboss.seam.annotations.datamodel;

