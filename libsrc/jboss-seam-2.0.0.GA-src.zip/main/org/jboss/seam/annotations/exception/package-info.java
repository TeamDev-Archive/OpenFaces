/**
 * Annotations for JSF exception handling.
 */
package org.jboss.seam.annotations.exception;

