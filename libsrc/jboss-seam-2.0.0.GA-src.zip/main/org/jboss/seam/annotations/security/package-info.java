/**
 * Annotations (well, one annotation) for use with Seam security.
 * 
 * @see org.jboss.seam.security.Identity
 */
package org.jboss.seam.annotations.security;

