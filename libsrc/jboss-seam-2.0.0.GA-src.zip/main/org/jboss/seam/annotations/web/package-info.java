/**
 * Annotations for use in a servlet environment
 * 
 */
package org.jboss.seam.annotations.web;

