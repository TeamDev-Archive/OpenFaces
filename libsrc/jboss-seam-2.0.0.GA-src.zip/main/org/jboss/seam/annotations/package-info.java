/**
 * Annotations for defining Seam components.
 * (You need to get to know these guys.)
 */
package org.jboss.seam.annotations;

