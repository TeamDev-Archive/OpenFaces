/**
 * Annotations for controlling the business process
 * and business process context.
 *
 * @see org.jboss.seam.bpm
 * @see org.jboss.seam.bpm.BusinessProcess
 */
package org.jboss.seam.annotations.bpm;

