/**
 * Annotations for defining Seam interceptors.
 */
package org.jboss.seam.annotations.intercept;

