/**
 * Annotations for use with Seam asynchronicity.
 */
package org.jboss.seam.annotations.async;

