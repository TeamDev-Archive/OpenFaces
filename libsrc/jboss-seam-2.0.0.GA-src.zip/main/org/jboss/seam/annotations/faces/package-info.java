/**
 * Annotations for defining JSF converters and validators.
 */
package org.jboss.seam.annotations.faces;

