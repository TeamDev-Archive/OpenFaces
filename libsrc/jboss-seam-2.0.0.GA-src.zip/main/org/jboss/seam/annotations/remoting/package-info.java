/**
 * Annotations (well, one annotation) for use with Seam remoting.
 */
package org.jboss.seam.annotations.remoting;

