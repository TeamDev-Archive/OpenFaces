/**
 * The Seam component meta-model.
 */
package org.jboss.seam;

