/**
 * The Seam Context API and implementations.
 */
package org.jboss.seam.contexts;

