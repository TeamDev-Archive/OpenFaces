/**
 * Integration with JBoss EL.
 */
package org.jboss.seam.el;

