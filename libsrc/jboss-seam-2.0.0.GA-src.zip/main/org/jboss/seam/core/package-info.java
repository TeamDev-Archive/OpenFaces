/**
 * A set of Seam components that implement Seam.
 * This is where the magic happens.
 */
@Namespace(value="http://jboss.com/products/seam/core", prefix="org.jboss.seam.core")
@AutoCreate
package org.jboss.seam.core;

import org.jboss.seam.annotations.AutoCreate;
import org.jboss.seam.annotations.Namespace;
