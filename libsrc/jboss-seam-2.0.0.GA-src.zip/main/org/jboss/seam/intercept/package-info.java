/**
 * Implementation of the Seam interceptor
 * stack.
 * 
 * @see org.jboss.seam.annotations.intercept
 */
package org.jboss.seam.intercept;
