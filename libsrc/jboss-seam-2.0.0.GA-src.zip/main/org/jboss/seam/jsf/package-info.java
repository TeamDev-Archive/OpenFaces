/**
 * Integration with the JSF implementation.
 * You're not really interested in the classes
 * in this package.
 */
package org.jboss.seam.jsf;