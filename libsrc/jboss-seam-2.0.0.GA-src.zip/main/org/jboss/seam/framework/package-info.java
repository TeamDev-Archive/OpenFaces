/**
 * A framework for data access in Seam. Components in
 * this package my be reused either by extension or
 * by configuration.
 */
@Namespace(value="http://jboss.com/products/seam/framework", prefix="org.jboss.seam.core.framework")
package org.jboss.seam.framework;

import org.jboss.seam.annotations.Namespace;
