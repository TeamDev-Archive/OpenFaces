/**
 * Implementation of Seam exception handling for JSF.
 * 
 * @see org.jboss.seam.annotations.exception
 */
package org.jboss.seam.exception;

