package org.jboss.seam.mock;

import javax.faces.application.NavigationHandler;
import javax.faces.context.FacesContext;

public class MockNavigationHandler extends NavigationHandler
{

   @Override
   public void handleNavigation(FacesContext context, String action, String outcome)
   {

   }

}
