/**
 * Seam components for internationalition of JSF applications.
 */
@Namespace(value="http://jboss.com/products/seam/international", prefix="org.jboss.seam.international")
@AutoCreate
package org.jboss.seam.international;

import org.jboss.seam.annotations.AutoCreate;
import org.jboss.seam.annotations.Namespace;
