/**
 * Support for jPDL-based pageflows.
 */
@AutoCreate
package org.jboss.seam.pageflow;

import org.jboss.seam.annotations.AutoCreate;
