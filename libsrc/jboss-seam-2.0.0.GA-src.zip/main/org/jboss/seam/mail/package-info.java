/**
 * Seam components for sending email.
 */
@Namespace(value="http://jboss.com/products/seam/mail",prefix="org.jboss.seam.mail")
@AutoCreate
package org.jboss.seam.mail;

import org.jboss.seam.annotations.AutoCreate;
import org.jboss.seam.annotations.Namespace;
