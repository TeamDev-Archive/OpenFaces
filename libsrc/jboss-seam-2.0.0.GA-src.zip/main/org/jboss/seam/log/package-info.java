/**
 * The Seam logging API (just what the world needed)
 */
package org.jboss.seam.log;