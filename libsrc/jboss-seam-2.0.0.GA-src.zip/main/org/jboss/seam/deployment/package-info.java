/**
 * Scanners for automatically loading components
 * from deployed archives. Internal implementation
 * stuff.
 */
package org.jboss.seam.deployment;

