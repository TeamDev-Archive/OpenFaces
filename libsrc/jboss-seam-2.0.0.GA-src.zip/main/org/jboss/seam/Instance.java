package org.jboss.seam;

public interface Instance
{
   public Component getComponent();
}
