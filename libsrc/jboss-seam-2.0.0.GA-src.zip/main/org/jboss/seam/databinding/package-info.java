/**
 * Implementation of @DataModel and friends.
 */
package org.jboss.seam.databinding;