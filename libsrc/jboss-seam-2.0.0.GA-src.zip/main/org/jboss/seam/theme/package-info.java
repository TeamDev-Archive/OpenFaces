/**
 * Support for themes in JSF applications.
 * You know you want it.
 */
@Namespace(value="http://jboss.com/products/seam/theme", prefix="org.jboss.seam.theme")
@AutoCreate
package org.jboss.seam.theme;

import org.jboss.seam.annotations.AutoCreate;
import org.jboss.seam.annotations.Namespace;
