/**
 * Seam components for working with JPA or Hibernate3.
 */
@Namespace(value="http://jboss.com/products/seam/persistence", prefix="org.jboss.seam.persistence")
package org.jboss.seam.persistence;

import org.jboss.seam.annotations.Namespace;
