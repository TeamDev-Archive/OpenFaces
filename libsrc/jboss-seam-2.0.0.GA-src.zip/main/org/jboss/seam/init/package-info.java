/**
 * Stuff for starting and initializing Seam in 
 * a servlet environment. You don't need to 
 * call this stuff yourself.
 */
package org.jboss.seam.init;
