//$Id: NoHotRedeployable.java,v 1.4 2007/06/20 21:12:46 gavin Exp $
package org.jboss.seam.init;

import java.io.File;

import org.jboss.seam.deployment.ComponentScanner;

/**
 * No hot deployment environment
 * 
 * @author Emmanuel Bernard
 */
class NoHotRedeployable implements RedeployableStrategy
{
   public NoHotRedeployable(File resource) {}
   
   public NoHotRedeployable() {}

   public ClassLoader getClassLoader()
   {
      return null;
   }

   public File[] getPaths()
   {
      return null;
   }

   public ComponentScanner getScanner()
   {
      return null;
   }

   public boolean isFromHotDeployClassLoader(Class componentClass)
   {
      return false;
   }
}
