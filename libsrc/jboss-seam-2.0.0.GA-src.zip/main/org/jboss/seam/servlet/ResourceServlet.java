package org.jboss.seam.servlet;

/**
 * @author Shane Bryzak
 * @deprecated use SeamResourceServlet
 */
public class ResourceServlet extends SeamResourceServlet
{

}
