/**
 * Integration with the servlet API.
 */
package org.jboss.seam.servlet;
