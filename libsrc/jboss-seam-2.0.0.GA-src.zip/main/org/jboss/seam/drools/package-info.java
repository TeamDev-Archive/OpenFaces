/**
 * Seam components for integrating Drools.
 */
@Namespace(value="http://jboss.com/products/seam/drools", prefix="org.jboss.seam.drools")
package org.jboss.seam.drools;

import org.jboss.seam.annotations.Namespace;
