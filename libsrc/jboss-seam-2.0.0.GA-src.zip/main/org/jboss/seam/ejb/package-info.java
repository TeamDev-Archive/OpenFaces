/**
 * Integration with EJB 3.0. Nothing
 * interesting here.
 */
package org.jboss.seam.ejb;

