
Project Deployment Examples:

You have 2 options for deploying this project using Maven. You can let the project download,run, and deploy
JBoss AS and Portal automatically with the first option . Or you can use your own local install of JBoss AS
and Portal to deploy this project with the second option.

prerequisites: Maven 2.1.0 (http://maven.apache.org/download.html)
For full details, see the bridge documentation at:
http://www.jboss.org/files/portletbridge/docs/1.0.0.B6/en/html_single/index.html#archetypes

*******************************************
*    Auto Download and Install            *
*******************************************

JBoss Portal 2.7.2.GA + JBoss AS 4.2.3 (Bundled download)
run the following from a command line:
=========
mvn install
mvn -Plocal-portal cargo:start
(In second terminal window) mvn cargo:deploy -Plocal-portal
- visit http://localhost:8080/portal

*******************************************
*    Locally Installed Bundle             *
*******************************************

*Note - the variable for JBOSS_HOME_DIR is related to how you zip the server directory. If you zip the files
under JBOSS_HOME/* then it will only be the name of your archive. But if you zip the actual folder JBOSS_HOME then
JBOSS_HOME_DIR must be defined as 'zip file name/JBOSS_HOME folder name' as shown above.

So basically, just zip up your local install of JBoss AS and portal (or download the bundle from sourceforge) if
you want to use this option.

JBoss Portal 2.7.2.GA + JBoss AS 4.2.3 (Downloaded and stored locally)
run the following from a command line:
-----------------------
mvn install
mvn cargo:start -Dlocal -Plocal-portal -DJBOSS_ZIP_HOME=/{path to zipped portal + JBoss AS}/jboss-portal-2.7.2-bundled.zip -DJBOSS_HOME_DIR=jboss-portal-2.7.2-bundled/jboss-portal-2.7.2
(In second terminal window) mvn cargo:deploy -Plocal-portal
- visit http://localhost:8080/portal

