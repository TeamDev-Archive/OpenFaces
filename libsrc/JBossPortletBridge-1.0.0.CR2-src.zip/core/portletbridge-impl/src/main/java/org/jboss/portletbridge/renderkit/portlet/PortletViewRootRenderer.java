/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.renderkit.portlet;

import java.io.IOException;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import javax.faces.render.Renderer;


/**
 * @author <a href="mailto:whales@redhat.com">Wesley Hales</a>
 * @version $Revision: 630 $
 */
public class PortletViewRootRenderer extends Renderer {

	private Renderer ajaxRenderer;

	public PortletViewRootRenderer() {
		try {
//			ajaxRenderer = new PortletAjaxViewRootRenderer();
		} catch (NoClassDefFoundError e) {
			ajaxRenderer = null;
		}
	}
	
	@Override
	public void decode(FacesContext context, UIComponent component) {
		if(null!=ajaxRenderer){
			ajaxRenderer.decode(context, component);
		}
	}

	@Override
	public void encodeBegin(FacesContext context, UIComponent component)
			throws IOException {
		if (null == ajaxRenderer) {
			ResponseWriter writer = context.getResponseWriter();
			Object namespace = component.getClientId(context);
			// encode portletbridge window marker
			writer.startElement("div", component);
			writer.writeAttribute("id", namespace, "id");

		} else {
			ajaxRenderer.encodeBegin(context, component);
		}
	}
	
	@Override
	public void encodeChildren(FacesContext context, UIComponent component)
			throws IOException {
		if(null!=ajaxRenderer){
			ajaxRenderer.encodeChildren(context, component);
		}
	}

	@Override
	public void encodeEnd(FacesContext context, UIComponent component)
			throws IOException {
		if (null == ajaxRenderer) {
			// Encode portletbridge window marker
			ResponseWriter writer = context.getResponseWriter();
			writer.endElement("div");

		} else {
			ajaxRenderer.encodeEnd(context, component);
		}
	}
	
	@Override
	public boolean getRendersChildren() {
		if(null!=ajaxRenderer){
			return ajaxRenderer.getRendersChildren();
		}
		return super.getRendersChildren();
	}
}
