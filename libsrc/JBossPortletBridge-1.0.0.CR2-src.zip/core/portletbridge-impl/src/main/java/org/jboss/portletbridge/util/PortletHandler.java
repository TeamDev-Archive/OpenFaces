/**
 * 
 */
package org.jboss.portletbridge.util;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

/**
 * @author asmirnov
 * 
 */
public class PortletHandler extends DefaultHandler {



	private static final String PORTLET_ELEMENT = "portlet";

	private static final String PORTLET_NAME_ELEMENT = "portlet-name";

	private static final String SEQURITY_ROLE_REF_ELEMENT = "security-role-ref";

	private static final String ROLE_NAME_ELEMENT = "role-name";


	private Map<String, Set<String>> portletRoles = new HashMap<String, Set<String>>();

	private XMLReader xmlReader;


	public PortletHandler(XMLReader reader) {
		this.xmlReader = reader;
	}

	@Override
	public void startElement(String uri, String localName, String name,
			Attributes attributes) throws SAXException {
		if (PORTLET_ELEMENT.equals(localName)) {
			xmlReader.setContentHandler(new PortletElementHandler());
		}
	}

	@Override
	public void endDocument() throws SAXException {
	}
	
    @Override
    public InputSource resolveEntity(String publicId, String systemId) throws SAXException
    {
      // Do nothing, to avoid network requests to external DTD/Schema
      return new InputSource(new StringReader(""));
    }


	final class PortletElementHandler extends StateHandler {

		private StringBuilder portletName = new StringBuilder();
		private Set<String> userRoles = new HashSet<String>();


		public PortletElementHandler() {
			super(xmlReader, PortletHandler.this);
		}

		@Override
		protected ContentHandler getNextHandler(String uri, String localName,
				Attributes attributes) {
			ContentHandler nextHandler = null;
			if (PORTLET_NAME_ELEMENT.equals(localName)) {
				nextHandler = new StringContentHandler(getReader(), this,
						portletName);
			} else if (SEQURITY_ROLE_REF_ELEMENT.equals(localName)) {
				nextHandler = new RolesHandler(this,userRoles);
			}
			return nextHandler;
		}

		@Override
		protected void endLastElement() {
			String name = portletName.toString().trim();
			if(name.length()>0 ){
				portletRoles.put(name, userRoles);
			}
		}
	}

	final class RolesHandler extends StateHandler {


		private StringBuilder roleName = null;
		private final Set<String> userRoles;

		public RolesHandler(ContentHandler parent, Set<String> userRoles) {
			super(xmlReader, parent);
			this.userRoles = userRoles;
		}

		@Override
		protected ContentHandler getNextHandler(String uri, String localName,
				Attributes attributes) {
			ContentHandler nextHandler = null;
			if (ROLE_NAME_ELEMENT.equals(localName)) {
				addRoleName();
				roleName = new StringBuilder();
				nextHandler = new StringContentHandler(getReader(), this,
						roleName);
			}
			return nextHandler;
		}

		private void addRoleName() {
			if(null != roleName && roleName.toString().trim().length()>0){
				userRoles.add(roleName.toString().trim());
				roleName = null;
			}
		}

		@Override
		protected void endLastElement() {
			addRoleName();
		}
	}

	public XMLReader getXmlReader() {
		return xmlReader;
	}

	/**
	 * @return the portletRoles
	 */
	public Map<String, Set<String>> getPortletRoles() {
		return portletRoles;
	}

}
