/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.application;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.faces.FacesException;
import javax.faces.component.UIComponent;

import org.apache.commons.collections.Transformer;
import org.apache.commons.collections.map.LazyMap;

/**
 * @author asmirnov
 * 
 */
public class ComponentsLoaderImpl implements Transformer, ComponentsLoader {

    private Map classes;

    private ClassLoader loader;

    public ComponentsLoaderImpl() {
   classes = Collections.synchronizedMap(LazyMap.decorate(new HashMap(),
      this));
    }

    /*
         * (non-Javadoc)
         * 
         * @see org.jboss.portletbridge.application.ComponentsLoader#createComponent(java.lang.String)
         */
    public UIComponent createComponent(String type) {
   // Classes is a lazy Map, new object will be create on the fly.
   Class componentClass = (Class) classes.get(type);
   try {
       return (UIComponent) componentClass.newInstance();
   } catch (InstantiationException e) {
       throw new FacesException(
          "Error on create new instance of the component with class "
             + type, e);
   } catch (IllegalAccessException e) {
       throw new FacesException(
          "IllegalAccess on attempt to create new instance of the component with class "
             + type, e);
   }
    }

    public Object transform(Object input) {
   if (null == input) {
       throw new NullPointerException(
          "Name for a UIComponent class to restore is null");
   }
   ClassLoader loader = getClassLoader();
   Class componentClass = null;
   try {
       componentClass = loader.loadClass(input.toString());
   } catch (ClassNotFoundException e) {
       throw new FacesException("Can't load class " + input.toString(), e);
   }
   return componentClass;
    }

    /**
     * lazy create ClassLoader instance.
         * @return
         */
    private ClassLoader getClassLoader() {
   if (loader == null) {
       loader = Thread.currentThread().getContextClassLoader();
       if (loader == null) {
      loader = this.getClass().getClassLoader();
       }

   }
   return loader;
    }
}
