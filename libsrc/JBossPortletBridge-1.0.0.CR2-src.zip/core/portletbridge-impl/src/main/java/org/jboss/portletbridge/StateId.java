/**
 * 
 */
package org.jboss.portletbridge;

import java.io.Serializable;

import javax.portlet.PortletMode;
import javax.portlet.faces.BridgeException;

/**
 * @author asmirnov
 *
 */
@SuppressWarnings("serial")
public class StateId implements Serializable {
	
	private final String scopeId;
	
	private PortletMode mode;
	
	private final String uuid ;

	/**
	 * @param scopeId
	 * @param mode
	 * @param uuid
	 */
	public StateId(String scopeId, PortletMode mode, String uuid) {
		this.scopeId = scopeId;
		this.mode = mode;
		this.uuid = uuid;
	}
	
	public StateId(String stateId) {
		int modeStart = stateId.indexOf(':');
		if(modeStart >= 0){
			int modeEnd = stateId.indexOf(':', modeStart+1);
			if(modeEnd >modeStart){
				scopeId = stateId.substring(0, modeStart);
				mode = new PortletMode(stateId.substring(modeStart+1, modeEnd));
				uuid = stateId.substring(modeEnd+1);
			} else {
				throw new BridgeException("Invalid StateId format");
			}
		} else {
			throw new BridgeException("Invalid StateId format");
		}
	}

	/**
	 * @return the mode
	 */
	public PortletMode getMode() {
		return mode;
	}

	/**
	 * @param mode the mode to set
	 */
	public void setMode(PortletMode mode) {
		this.mode = mode;
	}

	/**
	 * @return the scopeId
	 */
	public String getScopeId() {
		return scopeId;
	}

	/**
	 * @return the uuid
	 */
	public String getUuid() {
		return uuid;
	}

	@Override
	public String toString() {
		return scopeId+':'+mode.toString()+':'+uuid;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((mode == null) ? 0 : mode.hashCode());
		result = prime * result + ((scopeId == null) ? 0 : scopeId.hashCode());
		result = prime * result + ((uuid == null) ? 0 : uuid.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StateId other = (StateId) obj;
		if (mode == null) {
			if (other.mode != null)
				return false;
		} else if (!mode.equals(other.mode))
			return false;
		if (scopeId == null) {
			if (other.scopeId != null)
				return false;
		} else if (!scopeId.equals(other.scopeId))
			return false;
		if (uuid == null) {
			if (other.uuid != null)
				return false;
		} else if (!uuid.equals(other.uuid))
			return false;
		return true;
	}

}
