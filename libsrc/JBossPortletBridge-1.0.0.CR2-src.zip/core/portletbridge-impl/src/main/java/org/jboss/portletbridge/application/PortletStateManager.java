/**
 * 
 */
package org.jboss.portletbridge.application;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.application.StateManager;
import javax.faces.application.StateManagerWrapper;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import javax.faces.render.ResponseStateManager;
import javax.portlet.faces.BridgeUtil;

import org.jboss.portletbridge.context.PortletBridgeContext;

/**
 * @author asmirnov
 * 
 */
public class PortletStateManager extends StateManagerWrapper {

	private StateManager parent;
	
	static final 		Pattern PATTERN = Pattern.compile(".*<input.*(?:\\svalue=[\"\'](.*)[\"\']\\s).*name=[\"']"+ResponseStateManager.VIEW_STATE_PARAM+"[\"'].*>");
	static final 		Pattern PATTERN2 = Pattern.compile(".*<input .*name=[\"']"+ResponseStateManager.VIEW_STATE_PARAM+"[\"'].*(?:\\svalue=[\"\'](.*)[\"\']\\s).*>");

	public PortletStateManager(StateManager parent) {
		super();
		this.parent = parent;
	}

	@Override
	public void writeState(FacesContext context, Object state)
			throws IOException {
		if (BridgeUtil.isPortletRequest()) {
			// Capture writed state into string.
			ResponseWriter originalWriter = context.getResponseWriter();
			StringWriter buff = new StringWriter(128);
			try {
				ResponseWriter stateResponseWriter = originalWriter
						.cloneWithWriter(buff);
				context.setResponseWriter(stateResponseWriter);
				super.writeState(context, state);
				stateResponseWriter.flush();
				String stateString = buff.toString();
				originalWriter.write(stateString);
				String stateValue = getStateValue(stateString);
					PortletBridgeContext bridgeContext = (PortletBridgeContext) context.getExternalContext().getRequestMap().get(PortletBridgeContext.REQUEST_PARAMETER_NAME);
					if(null != bridgeContext){
						Map<String, String[]> requestParameters = bridgeContext.getWindowState().getRequestParameters();
						if(null != stateValue){
						requestParameters.put(ResponseStateManager.VIEW_STATE_PARAM, new String[]{stateValue});
					} else {
						requestParameters.remove(ResponseStateManager.VIEW_STATE_PARAM);
					}
				}
			} finally {
				context.setResponseWriter(originalWriter);
			}
		} else {
			super.writeState(context, state);
		}
	}

	private String getStateValue(String input) {
		Matcher matcher = PortletStateManager.PATTERN.matcher(input);
		if(!matcher.matches()){
			matcher = PortletStateManager.PATTERN2.matcher(input);
			if(!matcher.matches()){
				return null;
			}
		}
		return matcher.group(1);
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.faces.application.StateManagerWrapper#getWrapped()
	 */
	@Override
	protected StateManager getWrapped() {
		return this.parent;
	}

}
