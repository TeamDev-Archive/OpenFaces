/**
 * 
 */
package org.jboss.portletbridge.context;

import java.util.Enumeration;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.jboss.portletbridge.StateId;
import org.jboss.portletbridge.application.PortletWindowState;

/**
 * This is a special request-scope bean to hold all Bridge-related information,
 * instead of using a lot of separate parameters.
 * @author asmirnov
 *
 */
public abstract class PortletBridgeContext {
	
	public static final String REQUEST_PARAMETER_NAME = PortletBridgeContext.class.getName();
	
	
	/*============================================================================
	 * Context methods
	 */
	
	private Set<String> initialRequestAttributeNames;
	
	private String redirectViewId;
	
	private Map<String, String[]> redirectRequestParameters;
	
	private StateId stateId;
	
	/**
	 * @return the initialRequestAttributeNames
	 */
	public Set<String> getInitialRequestAttributeNames() {
		return initialRequestAttributeNames;
	}

	/**
	 * @param names the initialRequestAttributeNames to set
	 */
	@SuppressWarnings("unchecked")
	public void setInitialRequestAttributeNames(
			Enumeration names) {		
		this.initialRequestAttributeNames = new HashSet<String>();
		while (names.hasMoreElements()) {
			String name = (String) names.nextElement();
			this.initialRequestAttributeNames.add(name);
		}
	}
	
	/**
	 * @return the redirectViewId
	 */
	public String getRedirectViewId() {
		return redirectViewId;
	}

	/**
	 * @param redirectViewId the redirectViewId to set
	 */
	public void setRedirectViewId(String redirectViewId) {
		this.redirectViewId = redirectViewId;
	}

	/**
	 * @return the redirectRequestParameters
	 */
	public Map<String, String[]> getRedirectRequestParameters() {
		return redirectRequestParameters;
	}

	/**
	 * @param redirectRequestParameters the redirectRequestParameters to set
	 */
	public void setRedirectRequestParameters(
			Map<String, String[]> redirectRequestParameters) {
		this.redirectRequestParameters = redirectRequestParameters;
	}

	public abstract PortletWindowState getWindowState();

	/**
	 * @return the stateId
	 */
	public StateId getStateId() {
		return stateId;
	}

	/**
	 * @param stateId the stateId to set
	 */
	public void setStateId(StateId stateId) {
		this.stateId = stateId;
	}
}
