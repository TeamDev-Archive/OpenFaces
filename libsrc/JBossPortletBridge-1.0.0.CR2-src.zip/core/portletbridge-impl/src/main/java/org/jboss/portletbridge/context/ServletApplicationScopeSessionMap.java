package org.jboss.portletbridge.context;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.jboss.portletbridge.application.PortletStateHolder.WindowIDRetriver;

public class ServletApplicationScopeSessionMap extends ContextAttributesMap<Object> {
	
	private static final class SessionAttributesNamesExtension extends
			SessionAttributesNames {
		private SessionAttributesNamesExtension(Enumeration<String> names, String prefix) {
			super(names, prefix);
		}

		@Override
		protected String checkName(String name, String prefix) {
			if(!name.startsWith(WindowIDRetriver.PORTLET_SCOPE_PREFIX)){
			return name;
			} else {
				return null;
			}
		}
	}

	private HttpSession session;
	
	public ServletApplicationScopeSessionMap(HttpServletRequest req) {
		session = req.getSession(true);
	}

	@Override
	protected Object getAttribute(String name) {
		return session.getAttribute(name);
	}

	@Override
	protected void setAttribute(String name, Object value) {
		session.setAttribute(name, value);
		
	}
	
	@Override
	protected void removeAttribute(String name) {
		session.removeAttribute(name);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected Enumeration<String> getEnumeration() {		
		return new SessionAttributesNamesExtension(session.getAttributeNames(), null);
	}


}
