/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.lifecycle;

import javax.faces.FacesException;
import javax.faces.event.PhaseListener;

import org.jboss.seam.jsf.SeamPhaseListenerWrapper;

/**
 * @author asmirnov
 *
 */
public class SeamPortletLifecycle extends PortletLifecycle {

   public static final String SEAM_PORTLET_LIFECYCLE = "SEAM_PORTLET";
   public static final String SEAM_PHASE_LISTENER_CLASS = "org.jboss.seam.jsf.SeamPhaseListener";


   private PhaseListener seamListener;

   private SeamPhaseListenerWrapper seamListenerWrapper;


    /**
     * @param listener
     * @see javax.faces.lifecycle.Lifecycle#addPhaseListener(javax.faces.event.PhaseListener)
     */
    public void addPhaseListener(PhaseListener listener) {
         // Existing Seam 2.0 releases hack - replace SeamPhaseListener by our bridge-compatible version.
         if(SEAM_PHASE_LISTENER_CLASS.equals(listener.getClass().getName())){
            if(null == seamListener){
               seamListener = listener;
               seamListenerWrapper = new SeamPhaseListenerWrapper(listener);
               addPhaseListener(0, seamListenerWrapper);
            } else {
               throw new FacesException("Attempt to register second SeamPhaseListener");
            }
         } else {
            super.addPhaseListener(listener);
         }
    }





   /**
    * @param listener
    * @see javax.faces.lifecycle.Lifecycle#removePhaseListener(javax.faces.event.PhaseListener)
    */
   public void removePhaseListener(PhaseListener listener) {
      if(listener == this.seamListener){
         listener = seamListenerWrapper;
         seamListener = seamListenerWrapper = null;
      }
      super.removePhaseListener(listener);
   }



    
}
