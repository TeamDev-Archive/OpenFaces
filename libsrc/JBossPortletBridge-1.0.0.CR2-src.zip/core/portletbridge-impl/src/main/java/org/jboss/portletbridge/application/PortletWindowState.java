/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.application;

import org.ajax4jsf.renderkit.AjaxContainerRenderer;
import org.jboss.portletbridge.BridgeConfig;
import org.jboss.portletbridge.ExcludedRequestAttribute;
import org.jboss.portletbridge.AjaxPortletBridge;
import org.jboss.portletbridge.context.AbstractExternalContext;
import org.jboss.portletbridge.context.PortalActionURL;
import org.jboss.portletbridge.context.PortletBridgeContext;
import org.jboss.portletbridge.seam.ConversationIdRetriver;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIViewRoot;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.render.ResponseStateManager;
import javax.portlet.PortletConfig;
import javax.portlet.faces.Bridge;
import javax.portlet.faces.annotation.ExcludeFromManagedRequestScope;
import java.util.*;
import java.util.Map.Entry;

/**
 * @author asmirnov
 */
public abstract class PortletWindowState {

   private static ConversationIdRetriver conversationIdRetriver;

   public static final String AJAX_PARAMETER_NAME = "AJAXREQUEST";
   
   public static final String REDIRECT_REQUEST_PARAMETERS_ATTRIBUTE = PortletWindowState.class
           .getName()
           + "REDIRECT_REQUEST_PARAMS";

   static {
      try {
         conversationIdRetriver = new ConversationIdRetriver();
      } catch (NoClassDefFoundError e) {
         // Do nothing, no seam classes available.
         conversationIdRetriver = null;
      }
   }

   /**
    *
    */
   private static final long serialVersionUID = 5630637804542426709L;

   private static final Class<?>[] excludedClasses = {
           javax.portlet.PortletConfig.class,
           javax.portlet.PortletContext.class,
           javax.portlet.PortletRequest.class,
           javax.portlet.PortletResponse.class,
           javax.portlet.PortletSession.class,
           javax.portlet.PortletPreferences.class,
           javax.portlet.PortalContext.class,
           javax.faces.context.FacesContext.class,
           javax.faces.context.ExternalContext.class,
           javax.servlet.ServletConfig.class,
           javax.servlet.ServletContext.class,
           javax.servlet.ServletRequest.class,
           javax.servlet.ServletResponse.class,
           javax.servlet.http.HttpSession.class};
   //TODO - add AjaxContext.class to excluded based on bridge mode

   private static final String[] excludedRequestAttributes = {"ajaxContext",
           "javax.servlet.include", ResponseStateManager.VIEW_STATE_PARAM,
           AbstractExternalContext.INITIAL_REQUEST_ATTRIBUTES_NAMES};

   private Map<String, List<FacesMessage>> messages;

   private Map<String, Object> beans;

   private Object treeStructure;

   private Object componentsState;

   private UIViewRoot viewRoot;

   private String viewId;

   private Map<String, String[]> requestParameters;

   private String namespace;

   private PortalActionURL portalActionURL;

   private PortalActionURL portalRenderURL;

   private String windowId;

   private String conversationIdParameter = "conversationId";

   private String conversationId;

   private Map<String, Object> portletPreferencesMap;
   
   private Locale portletLocale;


   public PortletWindowState() {
   }

   /**
    * @return the windowId
    */
   public String getWindowId() {
      return windowId;
   }

   /**
    * @param windowId the windowId to set
    */
   public void setWindowId(String windowId) {
      this.windowId = windowId;
   }

   /**
    * @return the viewId
    */
   public String getViewId() {
      return viewId;
   }

   /**
    * @param viewId the viewId to set
    */
   public void setViewId(String viewId) {
      this.viewId = viewId;
   }

   /**
    * @param facesContext
    */
   public void saveMessages(FacesContext facesContext) {
      messages = new HashMap<String, List<FacesMessage>>();
      Iterator<String> idsWithMessages = facesContext
              .getClientIdsWithMessages();
      while (idsWithMessages.hasNext()) {
         String id = idsWithMessages.next();
         Iterator<FacesMessage> messages = facesContext.getMessages(id);
         while (messages.hasNext()) {
            FacesMessage message = messages.next();
            addMessage(id, message);
         }
      }
   }

   /**
    * @param facesContext
    */
   public void restoreMessages(FacesContext facesContext) {
      if (null != messages) {
         Iterator<String> idsWithMessages = getClientIdsWithMessages();
         while (idsWithMessages.hasNext()) {
            String id = idsWithMessages.next();
            Iterator<FacesMessage> messages = getMessages(id);
            while (messages.hasNext()) {
               FacesMessage message = messages.next();
               facesContext.addMessage(id, message);
            }
         }

      }
   }

   /**
    * @return the _messages
    */
   Map<String, List<FacesMessage>> getMessages() {
      return messages;
   }

   /**
    * @param _messages the _messages to set
    */
   public void setMessages(Map<String, List<FacesMessage>> _messages) {
      this.messages = _messages;
   }

   /**
    * @return the _viewRoot
    */
   public UIViewRoot getViewRoot() {
      return viewRoot;
   }

   /**
    * @param root the _viewRoot to set
    */
   public void setViewRoot(UIViewRoot root) {
      viewRoot = root;
   }

   private void addMessage(String clientId, FacesMessage message) {
      List<FacesMessage> list = messages.get(clientId);
      if (list == null) {
         list = new ArrayList<FacesMessage>();
         messages.put(clientId, list);
      }
      list.add(message);
   }

   private Iterator<String> getClientIdsWithMessages() {
      return (messages.keySet().iterator());
   }

   private Iterator<FacesMessage> getMessages(String clientId) {
      List<FacesMessage> list = messages.get(clientId);
      if (list != null) {
         return (list.iterator());
      } else {
         return Collections.<FacesMessage>emptyList().iterator();
      }
   }

   /**
    * @return the componentsState
    */
   public Object getComponentsState() {
      return componentsState;
   }

   /**
    * @param componentsState the componentsState to set
    */
   public void setComponentsState(Object componentsState) {
      this.componentsState = componentsState;
   }

   /**
    * @return the treeStructure
    */
   public Object getTreeStructure() {
      return treeStructure;
   }

   /**
    * @param treeStructure the treeStructure to set
    */
   public void setTreeStructure(Object treeStructure) {
      this.treeStructure = treeStructure;
   }

   /**
    * Save request-scope beans, as described in the JSR-301 5.1
    *
    * @param facesContext
    */
   public void saveBeans(FacesContext facesContext) {
      beans = null;
      ExternalContext externalContext = facesContext.getExternalContext();
      Map<String, Object> requestMap = externalContext.getRequestMap();
      PortletBridgeContext bridgeContext = (PortletBridgeContext) requestMap
              .get(PortletBridgeContext.REQUEST_PARAMETER_NAME);
      Set<String> existingAttributes = null;
      if (null != bridgeContext) {
         existingAttributes = bridgeContext
                 .getInitialRequestAttributeNames();
      }
      if (null == existingAttributes) {
         existingAttributes = new HashSet<String>();
      } else {
         // Create local copy for merge with initial parameters.
         existingAttributes = new HashSet<String>(existingAttributes);
      }
//		String portletName = "";
//		if (null != portletConfig) {
//			portletName = portletConfig.getPortletName();
//		}
      // Get list of request attributes preventing to save.
      // in the JSR 301 PLT 5.1
      Set<ExcludedRequestAttribute> excluded = getBridgeConfig()
              .getExcludedAttributes();
      for (Iterator<Entry<String, Object>> iterator = requestMap.entrySet()
              .iterator(); iterator.hasNext();) {
         Entry<String, Object> entry = iterator.next();
         boolean include = true;
         String attributeName = entry.getKey();
         if (existingAttributes.contains(attributeName)) {
            include = false;
         }
         Object bean = entry.getValue();
         if (null != bean) {
            if (bean.getClass().isAnnotationPresent(
                    ExcludeFromManagedRequestScope.class)) {
               include = false;
            }
            for (int i = 0; (i < excludedClasses.length) && include; i++) {
               if (excludedClasses[i].isInstance(bean)) {
                  include = false;
                  break;
               }
            }
            for (int i = 0; (i < excludedRequestAttributes.length)
                    && include; i++) {
               if (attributeName.startsWith(excludedRequestAttributes[i])) {
                  include = false;
                  break;
               }
            }
            if (include && null != excluded) {
               for (ExcludedRequestAttribute excludedRequestAttribute : excluded) {
                  if (excludedRequestAttribute.match(attributeName)) {
                     include = false;
                     break;
                  }
               }
            }

            if (include) {
               if (null == beans) {
                  beans = new HashMap<String, Object>();
               }
               beans.put(attributeName, bean);
            }

         }
      }
      // Save request parameters ( all or a View state only ) restored as
      // requered
      // in the JSR 301 PLT 5.1
      boolean preserveActionParam = getBridgeConfig()
              .isPreserveActionParams();
      if (preserveActionParam) {
         requestParameters = new HashMap<String, String[]>(externalContext
                 .getRequestParameterValuesMap());

         requestParameters.remove(AJAX_PARAMETER_NAME);

         requestParameters.remove(ResponseStateManager.VIEW_STATE_PARAM);
      } else {
         requestParameters = new HashMap<String, String[]>();
      }
      saveSeamConversationId(facesContext);
   }

   /**
    * @param facesContext
    */
   public void saveSeamConversationId(FacesContext facesContext) {
      // Seam hack - save conversation Id for a request parameter.
      if (null != conversationIdRetriver) {
         conversationIdRetriver.setConversationIdParameter(this);
      }
   }

   public void restoreBeans(FacesContext facesContext) {
      Map<String, Object> requestMap = facesContext.getExternalContext()
              .getRequestMap();
      if (null != beans) {
         requestMap.putAll(beans);
      }
      Map<String, String[]> requestParameters = getRequestParameters();
      if (requestParameters
              .containsKey(ResponseStateManager.VIEW_STATE_PARAM)) {
         requestMap.put(Bridge.IS_POSTBACK_ATTRIBUTE, Boolean.TRUE);
      }
      if (null != conversationId) {
         requestParameters.put(conversationIdParameter,
                 new String[]{conversationId});
      }
   }

   public void restoreRequest(FacesContext facesContext, boolean b) {
//		ExternalContext externalContext = facesContext.getExternalContext();
//		Map<String, Object> requestMap = externalContext.getRequestMap();
      if (b) {
         facesContext.setViewRoot(getViewRoot());
         setViewRoot(null);
         restoreMessages(facesContext);
         restoreBeans(facesContext);
      }
   }

   public void saveRequest(FacesContext facesContext) {
      UIViewRoot root = facesContext.getViewRoot();
      setViewRoot(root);
      if (null != root) {
         setViewId(root.getViewId());
      }
      saveBeans(facesContext);
      saveMessages(facesContext);
   }

   /**
    * @return the namespace
    */
   public String getNamespace() {
      return namespace;
   }

   /**
    * @param namespace the namespace to set
    */
   public void setNamespace(String namespace) {
      this.namespace = namespace;
   }

   /**
    * @return the portalActionURL
    */
   public PortalActionURL getPortalActionURL() {
      return portalActionURL;
   }

   /**
    * @param portalActionURL the portalActionURL to set
    */
   public void setPortalActionURL(PortalActionURL actionURL) {
      this.portalActionURL = actionURL;
   }

   /**
    * @return the portalRenderURL
    */
   public PortalActionURL getPortalRenderURL() {
      return portalRenderURL;
   }

   /**
    * @param portalRenderURL the portalRenderURL to set
    */
   public void setPortalRenderURL(PortalActionURL portalURL) {
      this.portalRenderURL = portalURL;
   }

   public void reset() {
      this.requestParameters = null;
      this.beans = null;
      this.componentsState = null;
      this.messages = null;
      this.portalActionURL = null;
      this.portalRenderURL = null;
      this.treeStructure = null;
      this.viewRoot = null;
      this.viewId = null;
      this.conversationId = null;
   }

   /**
    * @return the conversationIdParameter
    */
   public String getConversationIdParameter() {
      return conversationIdParameter;
   }

   /**
    * @param conversationIdParameter the conversationIdParameter to set
    */
   public void setConversationIdParameter(String conversationIdParameter) {
      this.conversationIdParameter = conversationIdParameter;
   }

   /**
    * @return the conversationId
    */
   public String getConversationId() {
      return conversationId;
   }

   /**
    * @param conversationId the conversationId to set
    */
   public void setConversationId(String conversationId) {
      this.conversationId = conversationId;
   }

   public Map<String, String[]> getRequestParameters() {
      if (null == requestParameters) {
         requestParameters = new HashMap<String, String[]>(4);
      }
      return requestParameters;
   }

   public void setRequestParameters(Map<String, String[]> requestParameters) {
      this.requestParameters = requestParameters;
   }

   public Map<String, Object> getPortletPreferencesMap() {
      return portletPreferencesMap;
   }

   public void setPortletPreferencesMap(
           Map<String, Object> portletPreferencesMap) {
      this.portletPreferencesMap = portletPreferencesMap;
   }

   public PortletBridgeContext createBridgeContext() {
      return new PortletBridgeContext() {

         @Override
         public PortletWindowState getWindowState() {
            return PortletWindowState.this;
         }

      };
   }

   public abstract BridgeConfig getBridgeConfig();

/**
 * @return the portletLocale
 */
public Locale getPortletLocale() {
	return portletLocale;
}

/**
 * @param portletLocale the portletLocale to set
 */
public void setPortletLocale(Locale portletLocale) {
	this.portletLocale = portletLocale;
}

}
