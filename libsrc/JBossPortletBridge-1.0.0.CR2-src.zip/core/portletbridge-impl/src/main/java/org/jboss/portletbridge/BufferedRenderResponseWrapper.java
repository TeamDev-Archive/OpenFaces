/**
 *
 */
package org.jboss.portletbridge;

import org.jboss.portletbridge.io.FastBufferWriter;
import org.jboss.portletbridge.io.FastBufferOutputStream;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.Locale;

import javax.portlet.PortletURL;
import javax.portlet.RenderResponse;

public class BufferedRenderResponseWrapper implements RenderResponse {

	private static class FastPrintWriter extends PrintWriter {

		private final FastBufferWriter fastBufferWriter;

		public FastPrintWriter() {
			this(new FastBufferWriter());
		}

		/**
		 * This is to call only by public default constructor
		 * @param writer
		 */
		private FastPrintWriter(FastBufferWriter writer) {
			super(writer);

			this.fastBufferWriter = writer;
		}

		public void reset() {
			fastBufferWriter.reset();
		}

		public void writeTo(Writer writer) throws IOException {
			fastBufferWriter.writeTo(writer);
		}
	}

	private final RenderResponse renderResponse;

	private FastBufferOutputStream fastBufferStream = null;

	private BufferedRenderResponseWrapper.FastPrintWriter fastPrintWriter = null;

	public BufferedRenderResponseWrapper(RenderResponse renderResponse) {
		super();
		this.renderResponse = renderResponse;
	}

	/**
	 * Jboss portal workaround, implementation of the Dispatcher needs this method
	 * to get original request.
	 * @return the renderResponse
	 */
	public RenderResponse getResponse() {
		return renderResponse;
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @see javax.portlet.PortletResponse#addProperty(java.lang.String, java.lang.String)
	 */
	public void addProperty(String arg0, String arg1) {
		renderResponse.addProperty(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @see javax.portlet.PortletResponse#setProperty(java.lang.String, java.lang.String)
	 */
	public void setProperty(String arg0, String arg1) {
		renderResponse.setProperty(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @see javax.portlet.RenderResponse#setTitle(java.lang.String)
	 */
	public void setTitle(String arg0) {
		renderResponse.setTitle(arg0);
	}

	/**
	 * @return
	 * @see javax.portlet.RenderResponse#createActionURL()
	 */
	public PortletURL createActionURL() {
		return renderResponse.createActionURL();
	}

	/**
	 * @return
	 * @see javax.portlet.RenderResponse#createRenderURL()
	 */
	public PortletURL createRenderURL() {
		return renderResponse.createRenderURL();
	}

	/**
	 * @param arg0
	 * @return
	 * @see javax.portlet.PortletResponse#encodeURL(java.lang.String)
	 */
	public String encodeURL(String arg0) {
		return renderResponse.encodeURL(arg0);
	}

	/**
	 * @return
	 * @see javax.portlet.RenderResponse#getCharacterEncoding()
	 */
	public String getCharacterEncoding() {
		return renderResponse.getCharacterEncoding();
	}

	/**
	 * @return
	 * @see javax.portlet.RenderResponse#getContentType()
	 */
	public String getContentType() {
		return renderResponse.getContentType();
	}

	/**
	 * @param arg0
	 * @see javax.portlet.RenderResponse#setContentType(java.lang.String)
	 */
	public void setContentType(String arg0) {
		renderResponse.setContentType(arg0);
	}

	/**
	 * @return
	 * @see javax.portlet.RenderResponse#getLocale()
	 */
	public Locale getLocale() {
		return renderResponse.getLocale();
	}

	/**
	 * @return
	 * @see javax.portlet.RenderResponse#getNamespace()
	 */
	public String getNamespace() {
		return renderResponse.getNamespace();
	}

	/**
	 * @return
	 * @throws IOException
	 * @see javax.portlet.RenderResponse#getPortletOutputStream()
	 */
	public OutputStream getPortletOutputStream() throws IOException {
		if (fastBufferStream == null) {
			fastBufferStream = new FastBufferOutputStream();
		}

		return fastBufferStream;
	}

	/**
	 * @return
	 * @throws IOException
	 * @see javax.portlet.RenderResponse#getWriter()
	 */
	public PrintWriter getWriter() throws IOException {
		if (fastPrintWriter == null) {
			fastPrintWriter = new FastPrintWriter();
		}

		return fastPrintWriter;
	}

	/**
	 * @return
	 * @see javax.portlet.RenderResponse#isCommitted()
	 */
	public boolean isCommitted() {
		return renderResponse.isCommitted();
	}

	private void resetBuffers() {
		if (fastBufferStream != null) {
			fastBufferStream.reset();
		}

		if (fastPrintWriter != null) {
			fastPrintWriter.reset();
		}
	}

	/**
	 *
	 * @see javax.portlet.RenderResponse#reset()
	 */
	public void reset() {
		renderResponse.reset();

		resetBuffers();
	}

	/**
	 *
	 * @see javax.portlet.RenderResponse#resetBuffer()
	 */
	public void resetBuffer() {
		renderResponse.resetBuffer();

		resetBuffers();
	}

	/**
	 * @throws IOException
	 * @see javax.portlet.RenderResponse#flushBuffer()
	 */
	public void flushBuffer() throws IOException {
		renderResponse.flushBuffer();
	}

	/**
	 * @param arg0
	 * @see javax.portlet.RenderResponse#setBufferSize(int)
	 */
	public void setBufferSize(int arg0) {
		renderResponse.setBufferSize(arg0);
	}

	/**
	 * @return
	 * @see javax.portlet.RenderResponse#getBufferSize()
	 */
	public int getBufferSize() {
		return renderResponse.getBufferSize();
	}

	public void writeBufferedData() throws IOException {
		if (fastBufferStream != null) {
			fastBufferStream.writeTo(renderResponse.getPortletOutputStream());
		} else if (fastPrintWriter != null) {
			fastPrintWriter.writeTo(renderResponse.getWriter());
		}
	}

	public boolean isUseWriter() {
		return fastBufferStream == null;
	}
}