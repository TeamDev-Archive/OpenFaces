/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.context;

import java.util.Enumeration;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionContext;

/**
 * @author asmirnov
 *
 */
public class ServletSessionWrapper implements HttpSession {
    
    private HttpSession wrapped;

    private String prefix;
    /**
     * @param wrapped
     */
    public ServletSessionWrapper(HttpSession wrapped,String prefix) {
   this.wrapped = wrapped;
   this.prefix = prefix;
    }

    /**
     * @param arg0
     * @return
     * @see javax.servlet.http.HttpSession#getAttribute(java.lang.String)
     */
    public Object getAttribute(String arg0) {
   return wrapped.getAttribute(prefix+arg0);
    }

    /**
     * @return
     * @see javax.servlet.http.HttpSession#getAttributeNames()
     */
    public Enumeration getAttributeNames() {
   return new SessionAttributesNames(wrapped.getAttributeNames(),prefix);
    }

    /**
     * @return
     * @see javax.servlet.http.HttpSession#getCreationTime()
     */
    public long getCreationTime() {
   return wrapped.getCreationTime();
    }

    /**
     * @return
     * @see javax.servlet.http.HttpSession#getId()
     */
    public String getId() {
   return wrapped.getId();
    }

    /**
     * @return
     * @see javax.servlet.http.HttpSession#getLastAccessedTime()
     */
    public long getLastAccessedTime() {
   return wrapped.getLastAccessedTime();
    }

    /**
     * @return
     * @see javax.servlet.http.HttpSession#getMaxInactiveInterval()
     */
    public int getMaxInactiveInterval() {
   return wrapped.getMaxInactiveInterval();
    }

    /**
     * @return
     * @see javax.servlet.http.HttpSession#getServletContext()
     */
    public ServletContext getServletContext() {
   return wrapped.getServletContext();
    }

    /**
     * @return
     * @deprecated
     * @see javax.servlet.http.HttpSession#getSessionContext()
     */
    public HttpSessionContext getSessionContext() {
   return wrapped.getSessionContext();
    }

    /**
     * @param arg0
     * @return
     * @deprecated
     * @see javax.servlet.http.HttpSession#getValue(java.lang.String)
     */
    public Object getValue(String arg0) {
   return wrapped.getValue(prefix+arg0);
    }

    /**
     * @return
     * @deprecated
     * @see javax.servlet.http.HttpSession#getValueNames()
     */
    public String[] getValueNames() {
   return wrapped.getValueNames();
    }

    /**
     * 
     * @see javax.servlet.http.HttpSession#invalidate()
     */
    public void invalidate() {
   wrapped.invalidate();
    }

    /**
     * @return
     * @see javax.servlet.http.HttpSession#isNew()
     */
    public boolean isNew() {
   return wrapped.isNew();
    }

    /**
     * @param arg0
     * @param arg1
     * @deprecated
     * @see javax.servlet.http.HttpSession#putValue(java.lang.String, java.lang.Object)
     */
    public void putValue(String arg0, Object arg1) {
   wrapped.putValue(prefix+arg0, arg1);
    }

    /**
     * @param arg0
     * @see javax.servlet.http.HttpSession#removeAttribute(java.lang.String)
     */
    public void removeAttribute(String arg0) {
   wrapped.removeAttribute(prefix+arg0);
    }

    /**
     * @param arg0
     * @deprecated
     * @see javax.servlet.http.HttpSession#removeValue(java.lang.String)
     */
    public void removeValue(String arg0) {
   wrapped.removeValue(prefix+arg0);
    }

    /**
     * @param arg0
     * @param arg1
     * @see javax.servlet.http.HttpSession#setAttribute(java.lang.String, java.lang.Object)
     */
    public void setAttribute(String arg0, Object arg1) {
   wrapped.setAttribute(prefix+arg0, arg1);
    }

    /**
     * @param arg0
     * @see javax.servlet.http.HttpSession#setMaxInactiveInterval(int)
     */
    public void setMaxInactiveInterval(int arg0) {
   wrapped.setMaxInactiveInterval(arg0);
    }
    
}
