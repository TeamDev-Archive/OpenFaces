/**
 * 
 */
package org.jboss.portletbridge.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import javax.faces.FacesException;
import javax.faces.application.ViewHandler;
import javax.faces.webapp.FacesServlet;
import javax.portlet.PortletContext;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

/**
 * This class reads content of the portlet application config file and collects
 * information about faces servlet mappings and error pages configuration.
 * @author asmirnov
 * 
 */
public class PortletXML {

	/**
	 * location of web application config.
	 */
	private static final String PORTLET_XML = "/WEB-INF/portlet.xml";
	private Map<String, Set<String>> portletRoles = new HashMap<String, Set<String>>();
	/**
	 * Parse web.xml file from input stream.
	 * @param webXml
	 */
	public void parse(InputStream webXml) {
		try {
			// Prepare SAX parser for a web-xml.
			SAXParserFactory factory = SAXParserFactory.newInstance();
			factory.setValidating(false);
			factory.setNamespaceAware(true);
			SAXParser parser = factory.newSAXParser();
			//WL 10.3 parser returns new instance of XMLReader everytime
			XMLReader reader = parser.getXMLReader();
			
			// Parse web.xml with state-avare content handler.
			PortletHandler portletHandler = new PortletHandler(reader);
            
			reader.setContentHandler(portletHandler);
            reader.setEntityResolver(WebXML.NULL_RESOLVER);
            reader.setErrorHandler(portletHandler);
            reader.setDTDHandler(portletHandler);

			reader.parse(new InputSource(webXml));
			
			portletRoles = portletHandler.getPortletRoles();
		} catch (Exception e) {
			throw new FacesException("XML parsing error", e);
		}
	}

	/**
	 * getter for the list contains {@link FacesServlet} mappings. 
	 * @return 
	 */
	public Set<String> getUserRoles(String portletName) {
		return portletRoles.get(portletName);
	}

	/**
	 * Parse application config file /WEB-INF/web.xml in the application
	 * context.
	 * 
	 * @param portletContext
	 */
	public void parse(PortletContext portletContext) {
		InputStream inputStream = portletContext
				.getResourceAsStream(PORTLET_XML);
		if (null != inputStream) {
			parse(inputStream);
			try {
				inputStream.close();
			} catch (IOException e) {
				portletContext.log("Error close portlet.xml stream", e);
			}
		}
	}
}
