/**
 * 
 */
package org.jboss.portletbridge.richfaces;

import java.net.MalformedURLException;
import java.util.Map;
import java.util.Map.Entry;

import javax.faces.FacesException;
import javax.faces.context.FacesContext;
import javax.portlet.faces.BridgeUtil;

import org.ajax4jsf.context.AjaxContext;
import org.ajax4jsf.resource.InternetResource;
import org.ajax4jsf.resource.ResourceBuilderImpl;
import org.jboss.portletbridge.application.PortletStateHolder;
import org.jboss.portletbridge.context.PortalActionURL;

/**
 * @author asmirnov
 *
 */
public class PortalResourceBuilder extends ResourceBuilderImpl {
	
	@Override
	public String getUri(InternetResource resource, FacesContext context,
			Object storeData) {
		String uri = super.getUri(resource, context, storeData);
		if(isPortletRequest(context) && resource.requireFacesContext()){
			try {
				PortalActionURL portalUrl = new PortalActionURL(uri);
				AjaxContext ajaxContext = AjaxContext.getCurrentInstance(context);
				Map<String, Object> ajaxParameters = ajaxContext.getCommonAjaxParameters();
				if(null != ajaxParameters && ajaxParameters.size()>0){
					for (Entry<String,Object> entry : ajaxParameters.entrySet()) {
						portalUrl.addParameter(entry.getKey(), String.valueOf(entry.getValue()));
					}
					uri = portalUrl.toString();
				}
			} catch (MalformedURLException e) {
				throw new FacesException("Bad resource URL ",e);
			}
		}
		return uri;
	}
	
	public static boolean isPortletRequest(FacesContext context) {
		return BridgeUtil.isPortletRequest()
				|| context.getExternalContext().getRequestParameterMap()
						.containsKey(PortletStateHolder.STATE_ID_PARAMETER);
	}

}
