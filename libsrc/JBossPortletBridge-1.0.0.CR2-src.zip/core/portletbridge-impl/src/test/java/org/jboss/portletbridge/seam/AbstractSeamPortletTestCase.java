/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.seam;

import java.util.HashMap;

import javax.faces.context.ExternalContext;
import javax.portlet.faces.Bridge;

import org.jboss.portletbridge.AbstractAjax4jsfPortletTestCase;
import org.jboss.portletbridge.AjaxPortletBridge;
import org.jboss.seam.Component;
import org.jboss.seam.Seam;
import org.jboss.seam.contexts.ApplicationContext;
import org.jboss.seam.contexts.Context;
import org.jboss.seam.contexts.TestLifecycle;
import org.jboss.seam.core.Conversation;
import org.jboss.seam.core.ConversationEntries;
import org.jboss.seam.core.ConversationPropagation;
import org.jboss.seam.core.Events;
import org.jboss.seam.core.Init;
import org.jboss.seam.core.ResourceLoader;
import org.jboss.seam.faces.FacesManager;
import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.faces.FacesPage;
import org.jboss.seam.faces.Validation;
import org.jboss.seam.navigation.Pages;
import org.jboss.seam.web.Session;

/**
 * @author asmirnov
 *
 */
public abstract class AbstractSeamPortletTestCase extends
      AbstractAjax4jsfPortletTestCase {

   protected Bridge portletBridge;

   public AbstractSeamPortletTestCase(String name) {
      super(name);
   }

   @Override
   public void setUp() throws Exception {
      super.setUp();
        ExternalContext externalContext = setupRequest();
        facesContext.setExternalContext(externalContext);
  	  portletConfig.addInitParameter(Bridge.BRIDGE_PACKAGE_PREFIX + "defaultViewId.edit", "/foo.xhtml");
		HashMap<String, String> viewIdMap = new HashMap<String, String>();
		viewIdMap.put("edit", "/foo.xml");
		portletContext.setAttribute(Bridge.BRIDGE_PACKAGE_PREFIX + portletConfig.getPortletName() +"."+ Bridge.DEFAULT_VIEWID_MAP, viewIdMap);

        portletBridge = new AjaxPortletBridge();
        portletBridge.init(portletConfig);
         Context appContext = new ApplicationContext( externalContext.getApplicationMap() );
         installComponents(appContext);
   }

   protected abstract ExternalContext setupRequest();

   @Override
   public void tearDown() throws Exception {
      TestLifecycle.endTest();
      super.tearDown();
      portletBridge = null;
   }

      protected void installComponents(Context appContext)
      {
         Init init = new Init();
         init.setTransactionManagementEnabled(true);
         appContext.set( Seam.getComponentName(Init.class), init );
         installComponent(appContext, MockUserTransaction.class);
         installComponent(appContext, FacesManager.class);
         installComponent(appContext, ConversationEntries.class);
         installComponent(appContext, FacesPage.class);
         installComponent(appContext, Conversation.class);
         installComponent(appContext, FacesMessages.class);
         installComponent(appContext, Pages.class);
         installComponent(appContext, Events.class);
         installComponent(appContext, Validation.class);
         installComponent(appContext, Session.class);
         installComponent(appContext, ConversationPropagation.class);
         installComponent(appContext, ResourceLoader.class);
      }

      protected void installComponent(Context appContext, Class clazz)
      {
         appContext.set( Seam.getComponentName(clazz) + ".component", new Component(clazz) );
      }

}
