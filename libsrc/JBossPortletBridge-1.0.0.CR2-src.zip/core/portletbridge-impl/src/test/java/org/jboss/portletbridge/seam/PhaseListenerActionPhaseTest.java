/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.seam;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.faces.context.ExternalContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.lifecycle.Lifecycle;
import javax.portlet.PortletConfig;
import javax.portlet.faces.Bridge;

import org.jboss.portletbridge.BridgeConfig;
import org.jboss.portletbridge.ExcludedRequestAttribute;
import org.jboss.portletbridge.MockPortletContext;
import org.jboss.portletbridge.StateId;
import org.jboss.portletbridge.application.PortletStateHolder;
import org.jboss.portletbridge.application.PortletWindowState;
import org.jboss.portletbridge.context.AbstractExternalContext;
import org.jboss.portletbridge.context.PortletBridgeContext;
import org.jboss.portletbridge.context.PortletExternalContextImpl;
import org.jboss.seam.contexts.Contexts;

/**
 * @author asmirnov
 *
 */
public class PhaseListenerActionPhaseTest extends AbstractSeamPortletTestCase {

    private static final StateId STATE_ID = new StateId("1234foo:edit:12345");
private SeamPhaseListener phaseListener;
   /**
    * @param name
    */
   public PhaseListenerActionPhaseTest(String name) {
      super(name);
   }

   /* (non-Javadoc)
    * @see org.jboss.portletbridge.seam.AbstractSeamPortletTestCase#setUp()
    */
   public void setUp() throws Exception {
      super.setUp();
      phaseListener = new SeamPhaseListener();
      lifecycle.addPhaseListener(phaseListener);
   }

   /* (non-Javadoc)
    * @see org.jboss.portletbridge.seam.AbstractSeamPortletTestCase#tearDown()
    */
   public void tearDown() throws Exception {
      super.tearDown();
      phaseListener = null;
   }

   /**
    * Test method for {@link org.jboss.portletbridge.seam.SeamPhaseListener#beforePhase(javax.faces.event.PhaseEvent)}.
    */
   public void testBeforePhase() {
      assertFalse(Contexts.isEventContextActive());
      phaseListener.beforePhase(new PhaseEvent(facesContext,PhaseId.RESTORE_VIEW,lifecycle));
      assertTrue(Contexts.isEventContextActive());
   }

   /**
    * Test method for {@link org.jboss.portletbridge.seam.SeamPhaseListener#afterPhase(javax.faces.event.PhaseEvent)}.
    */
   public void testAfterPhase() {
      assertFalse(Contexts.isEventContextActive());
      phaseListener.beforePhase(new PhaseEvent(facesContext,PhaseId.RESTORE_VIEW,lifecycle));
      phaseListener.afterPhase(new PhaseEvent(facesContext,PhaseId.RESTORE_VIEW,lifecycle));
      assertTrue(Contexts.isEventContextActive());
   }

   @Override
   protected ExternalContext setupRequest() {
      setupActionRequest();
      request.setAttribute(Bridge.PORTLET_LIFECYCLE_PHASE, Bridge.PortletPhase.ActionPhase);
      request.setAttribute(AbstractExternalContext.PORTLET_CONFIG_ATTRIBUTE,
            portletConfig);
      PortletStateHolder portletStateHolder = PortletStateHolder.init(new MockPortletContext(servletContext));
      PortletWindowState portletState = new PortletWindowState(){

   	@Override
   	public BridgeConfig getBridgeConfig() {
   		return new BridgeConfig(){

   			public Map<String, String> getDefaultViewIdMap() {
				HashMap<String, String> viewIdMap = new HashMap<String,String>();
				viewIdMap.put("view", "/foo.xhtml");
				return viewIdMap;
   			}

   			public Set<ExcludedRequestAttribute> getExcludedAttributes() {
   				// TODO Auto-generated method stub
   				return null;
   			}

   			public List<String> getFacesServletMappings() {
   				// TODO Auto-generated method stub
   				return null;
   			}

   			public String getInitParameter(String name) {
   				// TODO Auto-generated method stub
   				return null;
   			}

   			public PortletConfig getPortletConfig() {
   				// TODO Auto-generated method stub
   				return null;
   			}

   			public String getPortletName() {
   				// TODO Auto-generated method stub
   				return null;
   			}

   			public boolean isPreserveActionParams() {
   				// TODO Auto-generated method stub
   				return false;
   			}

			public Map<Class<? extends Throwable>, String> getErrorPages() {
				// TODO Auto-generated method stub
				return null;
			}

            public Lifecycle getFacesLifecycle() {
               return null;
            }

         };
   	}
   	   
      };
      portletStateHolder.addWindowState(STATE_ID, portletState);
      PortletBridgeContext bridgeContext = portletState.createBridgeContext();
      actionRequest.setAttribute(PortletBridgeContext.REQUEST_PARAMETER_NAME, bridgeContext);

      return new PortletExternalContextImpl(portletContext,actionRequest,actionResponse);
   }

public Map<String, String> getErrorPages() {
	return null;
}

public Lifecycle getFacesLifecycle() {
	return null;
}

}
