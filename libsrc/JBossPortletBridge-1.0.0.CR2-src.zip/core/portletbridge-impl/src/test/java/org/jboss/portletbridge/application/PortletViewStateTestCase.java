/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.application;

import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIInput;
import javax.faces.component.UIOutput;
import javax.faces.component.UIViewRoot;

import org.jboss.portletbridge.AbstractAjax4jsfPortletTestCase;
import org.jboss.portletbridge.BridgeConfig;

public class PortletViewStateTestCase extends AbstractAjax4jsfPortletTestCase {

    private static final String STATE_ID = "foo:view:1234";
	ComponentsLoaderImpl loader;
    private UIInput input;
    private UIOutput output;
    
    public PortletViewStateTestCase(String name) {
   super(name);
    }

    public void setUp() throws Exception {
   super.setUp();
    }

    public void tearDown() throws Exception {
   super.tearDown();
    }


    /**
     * 
     */
    private void setupTree() {
   input = new UIInput();
   input.setId("in");
   UIViewRoot viewRoot = facesContext.getViewRoot();
   viewRoot.getChildren().add(input);
   output = new UIOutput();
   output.setId("out");
   viewRoot.getFacets().put("facet",output);
    }

    public final void testSaveMessages() {
   setupActionRequest();
   setupTree();
   String clientId = input.getClientId(facesContext);
   FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_ERROR,"msg","detail");
   facesContext.addMessage(clientId, facesMessage);
   PortletWindowState state = new PortletWindowState(){

	@Override
	public BridgeConfig getBridgeConfig() {
		return null;
	}
	   
   };
   state.saveMessages(facesContext);
   Map messages = state.getMessages();
   assertEquals(1, messages.size());
   List list = (List)messages.get(clientId);
   assertEquals(1, list.size());
   assertSame(facesMessage, list.get(0));
    }

    public final void testRestore() {
   // TODO - implement test
    }

    public final void testRestoreMessages() {
   // TODO - implement test
    }

    public final void testGetComponentsState() {
   // TODO - implement test
    }

    public final void testGetTreeStructure() {
   // TODO - implement test
    }

}
