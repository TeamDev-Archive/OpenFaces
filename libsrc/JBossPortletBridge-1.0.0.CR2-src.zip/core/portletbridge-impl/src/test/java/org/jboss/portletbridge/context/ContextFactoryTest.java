/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.context;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.faces.FacesException;
import javax.faces.lifecycle.Lifecycle;
import javax.faces.context.FacesContext;
import javax.portlet.PortletConfig;

import org.ajax4jsf.tests.AbstractAjax4JsfTestCase;
import org.jboss.portletbridge.BridgeConfig;
import org.jboss.portletbridge.ExcludedRequestAttribute;
import org.jboss.portletbridge.MockActionRequest;
import org.jboss.portletbridge.MockActionResponse;
import org.jboss.portletbridge.MockPortletContext;
import org.jboss.portletbridge.StateId;
import org.jboss.portletbridge.application.PortletStateHolder;
import org.jboss.portletbridge.application.PortletWindowState;

/**
 * @author asmirnov
 * 
 */
public class ContextFactoryTest extends AbstractAjax4JsfTestCase {
    private static final StateId STATE_ID = new StateId("1234foo:edit:12345");

	/**
         * @param arg0
         */
    public ContextFactoryTest(String arg0) {
   super(arg0);
    }

    /*
         * (non-Javadoc)
         * 
         * @see junit.framework.TestCase#setUp()
         */
    public void setUp() throws Exception {
   super.setUp();
    }

    /*
         * (non-Javadoc)
         * 
         * @see junit.framework.TestCase#tearDown()
         */
    public void tearDown() throws Exception {
   super.tearDown();
    }

    /**
         * Test method for
         * {@link org.jboss.portletbridge.context.FacesContextFactoryImpl#FacesContextFactoryImpl(javax.faces.context.FacesContextFactory)}.
         */
    public void testFacesContextFactoryImpl() {
   FacesContextFactoryImpl factory = new FacesContextFactoryImpl(facesContextFactory);
   FacesContext context = factory.getFacesContext(servletContext, request,
      response, lifecycle);
   assertFalse((context instanceof FacesContextImpl));
   assertFalse((context.getExternalContext() instanceof AbstractExternalContext));
    }

    /**
         * Test method for
         * {@link org.jboss.portletbridge.context.FacesContextFactoryImpl#getFacesContext(java.lang.Object, java.lang.Object, java.lang.Object, javax.faces.lifecycle.Lifecycle)}.
         */
    public void testGetFacesContextPortlet() {
   FacesContextFactoryImpl factory = new FacesContextFactoryImpl(facesContextFactory);
   MockPortletContext portletContext = new MockPortletContext(servletContext);
   MockActionRequest portletRequest = new MockActionRequest(portletContext);
   MockActionResponse portletResponse = new MockActionResponse();
   PortletStateHolder portletStateHolder = PortletStateHolder.init(new MockPortletContext(servletContext));
   PortletWindowState portletState = new PortletWindowState(){

	@Override
	public BridgeConfig getBridgeConfig() {
		return new BridgeConfig(){

			public Map<String, String> getDefaultViewIdMap() {
				HashMap<String, String> viewIdMap = new HashMap<String,String>();
				viewIdMap.put("view", "/foo.xhtml");
				return viewIdMap;
			}

			public Set<ExcludedRequestAttribute> getExcludedAttributes() {
				// TODO Auto-generated method stub
				return null;
			}

			public List<String> getFacesServletMappings() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getInitParameter(String name) {
				// TODO Auto-generated method stub
				return null;
			}

			public PortletConfig getPortletConfig() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getPortletName() {
				// TODO Auto-generated method stub
				return null;
			}

			public boolean isPreserveActionParams() {
				// TODO Auto-generated method stub
				return false;
			}

			public Map<Class<? extends Throwable>, String> getErrorPages() {
				// TODO Auto-generated method stub
				return null;
			}

         public Lifecycle getFacesLifecycle() {
            return null;
         }

      };
	}
	   
   };
   portletStateHolder.addWindowState(STATE_ID, portletState);
   PortletBridgeContext bridgeContext = portletState.createBridgeContext();
   portletRequest.setAttribute(PortletBridgeContext.REQUEST_PARAMETER_NAME, bridgeContext);
   FacesContext context = factory.getFacesContext(portletContext,
      portletRequest, portletResponse, lifecycle);
   assertTrue((context instanceof FacesContextImpl));
   assertTrue((context.getExternalContext() instanceof AbstractExternalContext));
   assertSame(FacesContext.getCurrentInstance(),context);
    }

    public void testIllegalEnvironment() throws Exception {
   FacesContextFactoryImpl factory = new FacesContextFactoryImpl(facesContextFactory);
   try {
       FacesContext context = factory.getFacesContext(null, request,
          response, lifecycle);
       assertTrue("null pointer passed", false);
   } catch (NullPointerException e) {
   }
   try {
       FacesContext context = factory.getFacesContext(facesContext,
          request, response, lifecycle);
       assertTrue("illegal context passed", false);
   } catch (FacesException e) {
       // TODO: handle exception
   }
    }

	public Map<String, String> getErrorPages() {
		return null;
	}

	public Lifecycle getFacesLifecycle() {
		return null;
	}
}
