/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.context;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.faces.application.ViewHandler;
import javax.faces.context.ExternalContext;
import javax.faces.lifecycle.Lifecycle;
import javax.portlet.PortletConfig;

import org.ajax4jsf.tests.AbstractAjax4JsfTestCase;
import org.jboss.portletbridge.BridgeConfig;
import org.jboss.portletbridge.ExcludedRequestAttribute;
import org.jboss.portletbridge.MockActionRequest;
import org.jboss.portletbridge.MockActionResponse;
import org.jboss.portletbridge.MockPortletContext;
import org.jboss.portletbridge.MockPortletRequest;
import org.jboss.portletbridge.StateId;
import org.jboss.portletbridge.application.PortletStateHolder;
import org.jboss.portletbridge.application.PortletWindowState;

/**
 * @author asmirnov
 *
 */
public class PortletExternalContextTest extends AbstractAjax4JsfTestCase {
    private static final StateId STATE_ID = new StateId("1234foo:edit:12345");
	private AbstractExternalContext portletContextImpl;
    private FacesContextImpl portalFacesContext;
    private MockPortletContext portletContext;
    private MockActionRequest portletRequest;
    private MockActionResponse portletResponse;

    /**
     * @param arg0
     */
    public PortletExternalContextTest(String arg0) {
   super(arg0);
    }

    /* (non-Javadoc)
     * @see org.ajax4jsf.tests.AbstractAjax4JsfTestCase#setUp()
     */
    public void setUp() throws Exception {
   super.setUp();
   portletContext=new MockPortletContext(servletContext);
   portletRequest = new MockActionRequest(portletContext);
   portletResponse = new MockActionResponse();
   PortletStateHolder portletStateHolder = PortletStateHolder.init(new MockPortletContext(servletContext));
   PortletWindowState portletState = new PortletWindowState(){

	@Override
	public BridgeConfig getBridgeConfig() {
		return new BridgeConfig(){

			public Map<String, String> getDefaultViewIdMap() {
				HashMap<String, String> viewIdMap = new HashMap<String,String>();
				viewIdMap.put("view", "/foo.xhtml");
				return viewIdMap;
			}

			public Set<ExcludedRequestAttribute> getExcludedAttributes() {
				// TODO Auto-generated method stub
				return null;
			}

			public List<String> getFacesServletMappings() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getInitParameter(String name) {
				// TODO Auto-generated method stub
				return null;
			}

			public PortletConfig getPortletConfig() {
				// TODO Auto-generated method stub
				return null;
			}

			public String getPortletName() {
				// TODO Auto-generated method stub
				return null;
			}

			public boolean isPreserveActionParams() {
				// TODO Auto-generated method stub
				return false;
			}

			public Map<Class<? extends Throwable>, String> getErrorPages() {
				// TODO Auto-generated method stub
				return null;
			}

         public Lifecycle getFacesLifecycle() {
            return null; 
         }

      };
	}
	   
   };
   portletStateHolder.addWindowState(STATE_ID, portletState);
   PortletBridgeContext bridgeContext = portletState.createBridgeContext();
   portletRequest.setAttribute(PortletBridgeContext.REQUEST_PARAMETER_NAME, bridgeContext);
   portletContextImpl = new PortletExternalContextImpl(portletContext,portletRequest,portletResponse);
   portalFacesContext = new FacesContextImpl(portletContextImpl,lifecycle);
   portalFacesContext.setViewRoot(facesContext.getViewRoot());
    }

    /* (non-Javadoc)
     * @see org.ajax4jsf.tests.AbstractAjax4JsfTestCase#tearDown()
     */
    public void tearDown() throws Exception {
   super.tearDown();
   portletContextImpl = null;
   portalFacesContext = null;
   portletContext = null;
   portletRequest = null;
   portletResponse = null;
    }

    /**
     * Test method for {@link org.jboss.portletbridge.context.PortletExternalContextImpl#getRequestParameterValuesMap()}.
     */
    public final void testGetRequestParameterValuesMap() {
   Map requestParameterValuesMap = portalFacesContext.getExternalContext().getRequestParameterValuesMap();
   assertNotNull(requestParameterValuesMap);
   assertSame(requestParameterValuesMap, portalFacesContext.getExternalContext().getRequestParameterValuesMap());
   assertSame(requestParameterValuesMap.get(MockPortletRequest.PARAMETER), portletRequest.getParameterValues(MockPortletRequest.PARAMETER));

    }

    /**
     * Test method for {@link org.jboss.portletbridge.context.PortletExternalContextImpl#getInitParameter(java.lang.String)}.
     */
    public final void testGetInitParameterString() {
   servletContext.addInitParameter(MockPortletContext.INIT_PARAMETER, MockPortletContext.PORTLET_INIT_VALUE);
   assertNull(portalFacesContext.getExternalContext().getInitParameter("blabla"));
   assertSame(MockPortletContext.PORTLET_INIT_VALUE, portalFacesContext.getExternalContext().getInitParameter(MockPortletContext.INIT_PARAMETER));
    }

    
    public void testCalculateServletPath() throws Exception {
		PortletExternalContextImpl extContext = (PortletExternalContextImpl) portalFacesContext.getExternalContext();
		List<String> servletMappings = new ArrayList<String>(1);
		servletMappings.add("*.jsf");
		extContext.calculateServletPath("/page/foo.jsp", servletMappings);
		assertEquals("/page/foo.jsf", extContext.getRequestServletPath());
		assertNull(extContext.getRequestPathInfo());
		assertNull(extContext.getServletMappingPrefix());
		assertEquals(".jsf", extContext.getServletMappingSuffix());
		assertEquals(".jsp", extContext.getDefaultJsfSuffix());
		String actionURL = portalFacesContext.getApplication().getViewHandler().getActionURL(portalFacesContext, "/pages/bar.jsp");
		assertEquals("/context/pages/bar.jsp", actionURL);
		PortalActionURL url = new PortalActionURL("/context/pages/bar.jsf");
		assertEquals("/pages/bar.jsp", extContext.getViewIdFromUrl(url));
		url = new PortalActionURL("/context/foo.bar?org.jboss.portletbridge.VIEWID=/pages/bar.jsp");
		assertEquals("/pages/bar.jsp", extContext.getViewIdFromUrl(url));
	}

    public void testCalculateServletPath1() throws Exception {
    	portletContext.setInitParameter(ViewHandler.DEFAULT_SUFFIX_PARAM_NAME, ".xhtml");
		PortletExternalContextImpl extContext = (PortletExternalContextImpl) portalFacesContext.getExternalContext();
		List<String> servletMappings = new ArrayList<String>(1);
		servletMappings.add("*.jsf");
		extContext.calculateServletPath("/page/foo.xhtml", servletMappings);
		assertEquals("/page/foo.jsf", extContext.getRequestServletPath());
		assertNull(extContext.getRequestPathInfo());
		assertNull(extContext.getServletMappingPrefix());
		assertEquals(".jsf", extContext.getServletMappingSuffix());
		assertEquals(".xhtml", extContext.getDefaultJsfSuffix());
		PortalActionURL url = new PortalActionURL("/context/pages/bar.jsf");
		assertEquals("/pages/bar.xhtml", extContext.getViewIdFromUrl(url));
		url = new PortalActionURL("/context/foo.bar?org.jboss.portletbridge.VIEWID=/pages/bar.jsp");
		assertEquals("/pages/bar.jsp", extContext.getViewIdFromUrl(url));
	}

    public void testCalculateServletPath2() throws Exception {
    	portletContext.setInitParameter(ViewHandler.DEFAULT_SUFFIX_PARAM_NAME, ".xhtml");
		PortletExternalContextImpl extContext = (PortletExternalContextImpl) portalFacesContext.getExternalContext();
		List<String> servletMappings = new ArrayList<String>(1);
		servletMappings.add("/faces/*");
		extContext.calculateServletPath("/page/foo.xhtml", servletMappings);
		assertEquals("/faces", extContext.getRequestServletPath());
		assertEquals("/page/foo.xhtml",extContext.getRequestPathInfo());
		assertEquals("/faces",extContext.getServletMappingPrefix());
		assertNull(extContext.getServletMappingSuffix());
		assertNull(extContext.getDefaultJsfSuffix());
		PortalActionURL url = new PortalActionURL("/context/faces/pages/bar.xhtml");
		assertEquals("/pages/bar.xhtml", extContext.getViewIdFromUrl(url));
		url = new PortalActionURL("/context/foo.bar?org.jboss.portletbridge.VIEWID=/pages/bar.jsp");
		assertEquals("/pages/bar.jsp", extContext.getViewIdFromUrl(url));
	}
    /**
     * Test method for {@link org.jboss.portletbridge.context.PortletExternalContextImpl#getRequestLocales()}.
     */
    public final void testGetRequestLocales() {
//   fail("Not yet implemented");
    }

    /**
     * Test method for {@link org.jboss.portletbridge.context.PortletExternalContextImpl#getSession(boolean)}.
     */
    public final void testGetSessionBoolean() {
//   fail("Not yet implemented");
    }

    /**
     * Test method for {@link org.jboss.portletbridge.context.AbstractExternalContext#getApplicationMap()}.
     */
    public final void testGetApplicationMap() {
   // fail("Not yet implemented");
    }

    /**
     * Test method for {@link org.jboss.portletbridge.context.AbstractExternalContext#getInitParameterMap()}.
     */
    public final void testGetInitParameterMap() {
   // fail("Not yet implemented");
    }

    /**
     * Test method for {@link org.jboss.portletbridge.context.AbstractExternalContext#setRequest(java.lang.Object)}.
     */
    public final void testSetRequestObject() {
   // fail("Not yet implemented");
    }

    /**
     * Test method for {@link org.jboss.portletbridge.context.AbstractExternalContext#getRequestCookieMap()}.
     */
    public final void testGetRequestCookieMap() {
   // fail("Not yet implemented");
    }

    /**
     * Test method for {@link org.jboss.portletbridge.context.AbstractExternalContext#getRequestHeaderMap()}.
     */
    public final void testGetRequestHeaderMap() {
   // fail("Not yet implemented");
    }

    /**
     * Test method for {@link org.jboss.portletbridge.context.AbstractExternalContext#getRequestHeaderValuesMap()}.
     */
    public final void testGetRequestHeaderValuesMap() {
   // fail("Not yet implemented");
    }

    /**
     * Test method for {@link org.jboss.portletbridge.context.AbstractExternalContext#getRequestMap()}.
     */
    public final void testGetRequestMap() {
   // fail("Not yet implemented");
    }

    /**
     * Test method for {@link org.jboss.portletbridge.context.AbstractExternalContext#getRequestParameterMap()}.
     */
    public final void testGetRequestParameterMap() {
   // fail("Not yet implemented");
    }

    /**
     * Test method for {@link org.jboss.portletbridge.context.AbstractExternalContext#getRequestParameterNames()}.
     */
    public final void testGetRequestParameterNames() {
   // fail("Not yet implemented");
    }

    /**
     * Test method for {@link org.jboss.portletbridge.context.AbstractExternalContext#setResponse(java.lang.Object)}.
     */
    public final void testSetResponseObject() {
   // fail("Not yet implemented");
    }

    /**
     * Test method for {@link org.jboss.portletbridge.context.AbstractExternalContext#getSessionMap()}.
     */
    public final void testGetSessionMap() {
   // fail("Not yet implemented");
    }

	public Map<String, String> getErrorPages() {
		return null;
	}

	public Lifecycle getFacesLifecycle() {
		return null;
	}
}
