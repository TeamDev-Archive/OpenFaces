/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package javax.portlet.faces;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.faces.lifecycle.Lifecycle;
import javax.faces.lifecycle.LifecycleFactory;
import javax.portlet.PortletContext;
import javax.portlet.PortletException;
import javax.portlet.PortletMode;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.jboss.portletbridge.AbstractAjax4jsfPortletTestCase;

/**
 * @author asmirnov
 * 
 */
public class GenericPortletTest extends AbstractAjax4jsfPortletTestCase {

   private final class GenericFacesPortletExtension extends
         GenericFacesPortlet {
      boolean editProcessed = false;
      boolean viewProcessed = false;
      boolean helpProcessed = false;

      @Override
      protected void doEdit(RenderRequest request, RenderResponse response)
            throws PortletException, IOException {
         editProcessed = true;
      }

      @Override
      protected void doView(RenderRequest request, RenderResponse response)
            throws PortletException, IOException {
         viewProcessed = true;
      }

      @Override
      protected void doHelp(RenderRequest request, RenderResponse response)
            throws PortletException, IOException {
         helpProcessed = true;
      }
   }

   /**
    * @param name
    */
   public GenericPortletTest(String name) {
      super(name);
   }

   /*
    * (non-Javadoc)
    *
    * @see junit.framework.TestCase#setUp()
    */
   public void setUp() throws Exception {
      super.setUp();
      MockBridge.actionCount = 0;
      MockBridge.destroyCount = 0;
      MockBridge.initCount = 0;
      MockBridge.responseCount = 0;
   }

   /*
    * (non-Javadoc)
    *
    * @see junit.framework.TestCase#tearDown()
    */
   public void tearDown() throws Exception {
      super.tearDown();
   }

   /**
    * Test method for {@link javax.portlet.faces.GenericFacesPortlet#destroy()}.
    *
    * @throws PortletException
    * @throws IOException
    */
   public void testDestroy() throws PortletException, IOException {
      setupActionRequest();
      GenericFacesPortlet portlet = new GenericFacesPortlet();
      portletContext.setInitParameter("javax.portlet.faces.BridgeImplClass",
            MockBridge.class.getName());
      portlet.init(portletConfig);
      MockBridge facesPortletBridge = (MockBridge) portlet
            .getFacesPortletBridge();
      assertEquals(true, facesPortletBridge.isInitialized());
      assertEquals(1, MockBridge.initCount);
      portlet.destroy();
      assertEquals(1, MockBridge.destroyCount);
      assertEquals(false, facesPortletBridge.isInitialized());

   }

   /**
    * Test method for
    * {@link javax.portlet.faces.GenericFacesPortlet#init(javax.portlet.PortletConfig)}.
    *
    * @throws PortletException
    */
   public void testInitPortletConfig() throws PortletException {
	  servletContext.addInitParameter(Bridge.LIFECYCLE_ID, "CUSTOM");
      servletContext.addInitParameter("javax.portlet.faces.renderPolicy",
              Bridge.BridgeRenderPolicy.NEVER_DELEGATE.toString());
      portletContext.setInitParameter("javax.portlet.faces.BridgeImplClass",
              MockBridge.class.getName());

      portletConfig.addInitParameter(
            "javax.portlet.faces.preserveActionParams", "true");
      portletConfig.addInitParameter(
              "javax.portlet.faces.excludedRequestAttributes", "bar,baz,boo");
      portletConfig.addInitParameter(
              "javax.portlet.faces.extension.my_package.my_attribute", "xxx");
      portletConfig.setPortletName("foo");
      GenericFacesPortlet portlet = new GenericFacesPortlet();
      portlet.init(portletConfig);
      assertEquals(Boolean.TRUE, portletContext
            .getAttribute("javax.portlet.faces.foo.preserveActionParams"));
      List<String> attrsList = (List<String>) portletContext.getAttribute("javax.portlet.faces.foo.excludedRequestAttributes");
      assertEquals(3, attrsList.size());
      assertEquals("bar", attrsList.get(0));
      assertEquals("baz", attrsList.get(1));
      assertEquals("boo", attrsList.get(2));
      assertEquals("xxx", portletContext
              .getAttribute("javax.portlet.faces.extension.my_package.foo.my_attribute"));
   }

   /**
    * Test method for
    * {@link javax.portlet.faces.GenericFacesPortlet#doDispatch(javax.portlet.RenderRequest, javax.portlet.RenderResponse)}.
    *
    * @throws PortletException
    * @throws IOException
    */
   public void testDoDispatchRenderRequestRenderResponse()
         throws PortletException, IOException {
      setupRenderRequest();
      GenericFacesPortletExtension portlet = new GenericFacesPortletExtension();
      portletContext.setInitParameter("javax.portlet.faces.BridgeImplClass",
            MockBridge.class.getName());
      portletConfig.addInitParameter(
            "javax.portlet.faces.defaultViewId.view", "index.jsf");
      portlet.init(portletConfig);
      portlet.doDispatch(renderRequest, renderResponse);
      assertEquals(0, MockBridge.responseCount);
      assertFalse(portlet.helpProcessed);
      assertFalse(portlet.editProcessed);
      assertTrue(portlet.viewProcessed);
   }

   /**
    * Test method for
    * {@link javax.portlet.faces.GenericFacesPortlet#doDispatch(javax.portlet.RenderRequest, javax.portlet.RenderResponse)}.
    *
    * @throws PortletException
    * @throws IOException
    */
   public void testDoDispatchRenderRequestRenderResponseEdit()
         throws PortletException, IOException {
      setupRenderRequest();
      GenericFacesPortletExtension portlet = new GenericFacesPortletExtension();
      portletContext.setInitParameter("javax.portlet.faces.BridgeImplClass",
            MockBridge.class.getName());
      portletConfig.addInitParameter(
            "javax.portlet.faces.defaultViewId.edit", "index.jsf");
      renderRequest.mode = PortletMode.EDIT;
      portlet.init(portletConfig);
      portlet.doDispatch(renderRequest, renderResponse);
      assertEquals(0, MockBridge.responseCount);
      assertFalse(portlet.helpProcessed);
      assertTrue(portlet.editProcessed);
      assertFalse(portlet.viewProcessed);
   }

   /**
    * Test method for
    * {@link javax.portlet.faces.GenericFacesPortlet#doDispatch(javax.portlet.RenderRequest, javax.portlet.RenderResponse)}.
    *
    * @throws PortletException
    * @throws IOException
    */
   public void testDoDispatchRenderRequestRenderResponseHelp()
         throws PortletException, IOException {
      setupRenderRequest();
      GenericFacesPortletExtension portlet = new GenericFacesPortletExtension();
      portletContext.setInitParameter("javax.portlet.faces.BridgeImplClass",
            MockBridge.class.getName());
      portletConfig.addInitParameter(
            "javax.portlet.faces.defaultViewId.view", "index.jsf");
      renderRequest.mode = PortletMode.HELP;
      portlet.init(portletConfig);
      portlet.doDispatch(renderRequest, renderResponse);
      assertEquals(0, MockBridge.responseCount);
      assertTrue(portlet.helpProcessed);
      assertFalse(portlet.editProcessed);
      assertFalse(portlet.viewProcessed);
   }

   /**
    * Test method for
    * {@link javax.portlet.faces.GenericFacesPortlet#doEdit(javax.portlet.RenderRequest, javax.portlet.RenderResponse)}.
    *
    * @throws IOException
    * @throws PortletException
    */
   public void testDoEditRenderRequestRenderResponse()
         throws PortletException, IOException {
      setupRenderRequest();
      GenericFacesPortlet portlet = new GenericFacesPortlet();
      portletContext.setInitParameter("javax.portlet.faces.BridgeImplClass",
            MockBridge.class.getName());
      portletConfig.addInitParameter(
            "javax.portlet.faces.defaultViewId.view", "index.jsf");
      renderRequest.mode = PortletMode.EDIT;
      portlet.init(portletConfig);
      portlet.doDispatch(renderRequest, renderResponse);
      assertEquals(0, MockBridge.responseCount);
   }

   /**
    * Test method for
    * {@link javax.portlet.faces.GenericFacesPortlet#doHelp(javax.portlet.RenderRequest, javax.portlet.RenderResponse)}.
    */
   public void testDoHelpRenderRequestRenderResponse() {
      // fail("Not yet implemented");
   }

   /**
    * Test method for
    * {@link javax.portlet.faces.GenericFacesPortlet#doView(javax.portlet.RenderRequest, javax.portlet.RenderResponse)}.
    *
    * @throws PortletException
    * @throws IOException
    */
   public void testDoViewRenderRequestRenderResponse()
         throws PortletException, IOException {
      setupRenderRequest();
      GenericFacesPortlet portlet = new GenericFacesPortlet();
      portletContext.setInitParameter("javax.portlet.faces.BridgeImplClass",
            MockBridge.class.getName());
      portletConfig.addInitParameter(
            "javax.portlet.faces.defaultViewId.view", "index.jsf");
      portlet.init(portletConfig);
      portlet.doDispatch(renderRequest, renderResponse);
      assertEquals(1, MockBridge.responseCount);
   }

   /**
    * Test method for
    * {@link javax.portlet.faces.GenericFacesPortlet#processAction(javax.portlet.ActionRequest, javax.portlet.ActionResponse)}.
    *
    * @throws PortletException
    * @throws IOException
    */
   public void testProcessActionActionRequestActionResponse()
         throws PortletException, IOException {
      setupActionRequest();
      GenericFacesPortlet portlet = new GenericFacesPortlet();
      portletContext.setInitParameter("javax.portlet.faces.BridgeImplClass",
            MockBridge.class.getName());
      portletConfig.addInitParameter(
            "javax.portlet.faces.defaultViewId.view", "index.jsf");
      portlet.init(portletConfig);
      portlet.processAction(actionRequest, actionResponse);
      assertEquals(1, MockBridge.actionCount);
   }

   /**
    * Test method for
    * {@link javax.portlet.faces.GenericFacesPortlet#getBridgeClassName()}.
    *
    * @throws PortletException
    */
   public void testGetBridgeClassName() throws PortletException {
      setupActionRequest();
      GenericFacesPortlet portlet = new GenericFacesPortlet();
      portletContext.setInitParameter("javax.portlet.faces.BridgeImplClass",
            MockBridge.class.getName());
      portletContext.setInitParameter(
            "javax.portlet.faces.defaultViewId.view", "index.jsf");
      portlet.init(portletConfig);
      assertEquals(MockBridge.class.getName(), portlet.getBridgeClassName());
   }

   /**
    * Test method for
    * {@link javax.portlet.faces.GenericFacesPortlet#getBridgeClassName()}.
    *
    * @throws PortletException
    */
   public void testGetBridgeClassName1() throws PortletException {
      setupActionRequest();
      GenericFacesPortlet portlet = new GenericFacesPortlet();
      try {
         portlet.init(portletConfig);

      } catch (PortletException e) {
         assertEquals("Can't detect bridge implementation class name", e
               .getMessage());
         return;
      }
      assertTrue("No exception for unknown bridge implementation", false);
   }

   /**
    * Test method for
    * {@link javax.portlet.faces.GenericFacesPortlet#getBridgeClassName()}.
    *
    * @throws PortletException
    */
   public void testGetBridgeClassName2() throws PortletException {
      ClassLoader loader = Thread.currentThread().getContextClassLoader();
      ClassLoader testLoader = new ClassLoader(loader) {
         @Override
         public InputStream getResourceAsStream(String name) {
            if ("META-INF/services/javax.portlet.faces.Bridge".equals(name)) {
               return new ByteArrayInputStream(MockBridge.class.toString().getBytes());
            }
            return super.getResourceAsStream(name);
         }
      };
      try {
         Thread.currentThread().setContextClassLoader(testLoader);
         setupActionRequest();
         GenericFacesPortlet portlet = new GenericFacesPortlet(){
        	 @Override
        	public PortletContext getPortletContext() {
        		return portletContext;
        	}
         };
//         portlet.init(portletConfig);
         assertEquals(MockBridge.class.toString(), portlet.getBridgeClassName());

      } finally {
         Thread.currentThread().setContextClassLoader(loader);
      }
   }

   /**
    * Test method for
    * {@link javax.portlet.faces.GenericFacesPortlet#getDefaultViewIdMap(javax.portlet.PortletRequest, javax.portlet.PortletMode)}.
    *
    * @throws PortletException
    */
   public void testGetDefaultViewId() throws PortletException {
      setupActionRequest();
      GenericFacesPortlet portlet = new GenericFacesPortlet();
      portletContext.setInitParameter("javax.portlet.faces.BridgeImplClass",
            MockBridge.class.getName());
      portletConfig.addInitParameter(
            "javax.portlet.faces.defaultViewId.view", "index.jsf");
      portletConfig.addInitParameter(
              "javax.portlet.faces.defaultViewId.edit", "edit/index.jsf");
      portletConfig.addInitParameter(
              "javax.portlet.faces.defaultViewId.help", "help/index.jsf");
      portlet.init(portletConfig);
      assertEquals("index.jsf", portlet.getDefaultViewIdMap().get(
            actionRequest.getPortletMode().toString()));
      assertEquals("edit/index.jsf", portlet.getDefaultViewIdMap().get(
              PortletMode.EDIT.toString()));
      assertEquals("help/index.jsf", portlet.getDefaultViewIdMap().get(
              PortletMode.HELP.toString()));
   }

   /**
    * Test method for
    * {@link javax.portlet.faces.GenericFacesPortlet#getFacesPortletBridge()}.
    *
    * @throws PortletException
    */
   public void testGetFacesPortletBridge() throws PortletException {
      setupActionRequest();
      GenericFacesPortlet portlet = new GenericFacesPortlet();
      portletContext.setInitParameter("javax.portlet.faces.BridgeImplClass",
            MockBridge.class.getName());
      portlet.init(portletConfig);
      MockBridge facesPortletBridge = (MockBridge) portlet
            .getFacesPortletBridge();
      assertEquals(true, facesPortletBridge.isInitialized());
   }

}
