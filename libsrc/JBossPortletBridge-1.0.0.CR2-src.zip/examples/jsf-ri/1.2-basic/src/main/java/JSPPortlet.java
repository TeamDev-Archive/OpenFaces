

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.GenericPortlet;
import javax.portlet.PortletException;
import javax.portlet.PortletRequestDispatcher;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

/**
 * <a href="JSPPortlet.java.html"><b><i>View Source</i></b></a>
 *
 * @author Brian Wing Shun Chan
 *
 */
public class JSPPortlet extends GenericPortlet {

	public void init() throws PortletException {
		editJSP = getInitParameter("edit-jsp");
		helpJSP = getInitParameter("help-jsp");
		viewJSP = getInitParameter("view-jsp");
		_log.info("JSP portlet initialized");
	}
	
	@Override
	public void destroy() {
		_log.info("JSP portlet destroyed");
		super.destroy();
	}


	public void doEdit(RenderRequest req, RenderResponse res)
		throws IOException, PortletException {

		if (req.getPreferences() == null) {
			super.doEdit(req, res);
		}
		else {
			include(editJSP, req, res);
		}
	}

	public void doHelp(RenderRequest req, RenderResponse res)
		throws IOException, PortletException {
		_log.fine("Debug level log");
		_log.warning("WARN level log");
		_log.severe("ERROR level log");
		_log.info("INFO level log");
		String contentType = req.getResponseContentType();
		res.setContentType(contentType);
		// set portletbridge title if its set.
		ResourceBundle bundle = getPortletConfig().getResourceBundle(req
				.getLocale());
		if (bundle != null) {
			String title = null;
			try {
				title = bundle.getString("javax.portlet.title");
				res.setTitle(title);
			} catch (Exception e) {
				// Ignore MissingResourceException
			}
		}
		PrintWriter writer = res.getWriter();
		writer.write("<div id='"+res.getNamespace()+"'>");
		writer.write("<h3><b>Hello World help mode</b></h3></div>");
		if(_log.isLoggable(Level.FINE)){
			writer.write("<p>Debug log level enabled</p>");			
		}
		if(_log.isLoggable(Level.WARNING)){
			writer.write("<p>Warn log level enabled</p>");			
		}
		if(_log.isLoggable(Level.INFO)){
			writer.write("<p>Info log level enabled</p>");			
		}
		writer.flush();
		throw new IOException("Test exception");
	}

	public void doView(RenderRequest req, RenderResponse res)
		throws IOException, PortletException {
		_log.fine("Debug level log");
		_log.warning("WARN level log");
		_log.severe("ERROR level log");
		_log.info("INFO level log");
		String contentType = req.getResponseContentType();
		res.setContentType(contentType);
		// set portletbridge title if its set.
		ResourceBundle bundle = getPortletConfig().getResourceBundle(req
				.getLocale());
		if (bundle != null) {
			String title = null;
			try {
				title = bundle.getString("javax.portlet.title");
				res.setTitle(title);
			} catch (Exception e) {
				// Ignore MissingResourceException
			}
		}
		res.setProperty(RenderResponse.EXPIRATION_CACHE, "0");
		PrintWriter writer = res.getWriter();
		writer.write("<div id='"+res.getNamespace()+"'>");
		writer.write("<h3><b>Hello World view mode</b></h3>");
		if(_log.isLoggable(Level.FINE)){
			writer.write("<p>Debug log level enabled</p>");			
		}
		if(_log.isLoggable(Level.WARNING)){
			writer.write("<p>Warn log level enabled</p>");			
		}
		if(_log.isLoggable(Level.INFO)){
			writer.write("<p>Info log level enabled</p>");			
		}
		writer.write("</div>");
		writer.flush();
//		throw new PortletException("Test exception");
	}

	public void processAction(ActionRequest req, ActionResponse res)
		throws IOException, PortletException {
	}

	protected void include(String path, RenderRequest req, RenderResponse res)
		throws IOException, PortletException {

		PortletRequestDispatcher prd =
			getPortletContext().getRequestDispatcher(path);

		if (prd == null) {
			_log.severe(path + " is not a valid include");
		}
		else {
			prd.include(req, res);
		}
	}

	protected String editJSP;
	protected String helpJSP;
	protected String viewJSP;

	private static Logger _log = Logger.getLogger("org.jboss.portletbridge.HelloPortlet");

}