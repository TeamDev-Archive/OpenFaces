/*
* JBoss, Home of Professional Open Source
* Copyright 2005, JBoss Inc., and individual contributors as indicated
* by the @authors tag. See the copyright.txt in the distribution for a
* full listing of individual contributors.
*
* This is free software; you can redistribute it and/or modify it
* under the terms of the GNU Lesser General Public License as
* published by the Free Software Foundation; either version 2.1 of
* the License, or (at your option) any later version.
*
* This software is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this software; if not, write to the Free
* Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
* 02110-1301 USA, or see the FSF site: http://www.fsf.org.
*/
package org.whatever.project;

import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.Destroy;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.log.Log;
import org.jboss.seam.security.Identity;
import static org.jboss.seam.ScopeType.SESSION;
import org.jboss.portletbridge.seam.PortletScope;
import org.jboss.portletbridge.extension.seam.PortalIdentity;
import org.jboss.portal.portlet.impl.jsr168.api.RenderRequestImpl;


import javax.ejb.Stateful;
import javax.ejb.Remove;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.portlet.RenderRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.ServletRequestWrapper;
import java.io.Serializable;
import java.util.Enumeration;

@Stateful
@Name("helloWorld")
@Scope(SESSION)
@PortletScope(PortletScope.ScopeType.APPLICATION_SCOPE)
public class HelloWorld implements Serializable, HelloWorldIF{

   @Logger
   Log log;

    private String text;

    @In(create=true)
    private TextHolderIF textHolder;

   public TextHolderIF getTextHolder()
   {
      return textHolder;
   }

   public void setTextHolder(TextHolderIF textHolder)
   {
      this.textHolder = textHolder;
   }

   public String getText() {
        return textHolder.getText();
    }

    public void setText(String text) {
       this.text=text;
       String username = "unknown user";
       if(PortalIdentity.instance().isLoggedIn()){
          username = PortalIdentity.instance().getPrincipal().getName();
       }
       String log = getText() != null ? getText() : "";
       text = log + "<b>" + username + ": </b> " + text + "<hr/>";
       if (getRenderRequest() != null){
          TextHolderIF hwif = (TextHolderIF)getRenderRequest().getAttribute("javax.portlet.p./default/seamproject/seamprojectPortletWindow?textHolder");
          hwif.setText(text);
       }
        textHolder.setText(text);
    }

   private String chatMessage;

   public String getChatMessage()
   {
      return chatMessage;
   }

   public void setChatMessage(String chatMessage)
   {
      this.chatMessage = chatMessage;
   }

   public void sendMessage(ActionEvent actionEvent){
      setText(chatMessage);
      this.chatMessage = "";
   }


   private HttpSession getRenderRequest() {
   HttpServletRequestWrapper responseObject = (HttpServletRequestWrapper)FacesContext.getCurrentInstance().getExternalContext().getRequest();
   if (responseObject instanceof HttpServletRequestWrapper) {
      //RenderRequestImpl rri = (RenderRequestImpl)responseObject;
      return responseObject.getSession(false);
   }
   return null;
   }

   @Remove
   public void destroy() {}

}