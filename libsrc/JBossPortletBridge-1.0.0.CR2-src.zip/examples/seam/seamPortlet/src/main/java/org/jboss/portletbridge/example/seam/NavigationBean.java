/**
 * 
 */
package org.jboss.portletbridge.example.seam;

import org.jboss.seam.annotations.Name;

/**
 * @author asmirnov
 *
 */
@Name("navigation")
public class NavigationBean {

	public String toHelp1() {
		return "/helpPages/help1.xhtml?javax.portlet.faces.PortletMode=help";
	}
}
