/**
 * 
 */
package org.jboss.portletbridge.example.seam;

/**
 * @author asmirnov
 *
 */
public class DistributionBean {
	
	private String utilityCodeDescription;
	
	private String description;

	/**
	 * @return the utilityCodeDescription
	 */
	public String getUtilityCodeDescription() {
		return utilityCodeDescription;
	}

	/**
	 * @param utilityCodeDescription the utilityCodeDescription to set
	 */
	public void setUtilityCodeDescription(String utilityCodeDescription) {
		this.utilityCodeDescription = utilityCodeDescription;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
	

}
