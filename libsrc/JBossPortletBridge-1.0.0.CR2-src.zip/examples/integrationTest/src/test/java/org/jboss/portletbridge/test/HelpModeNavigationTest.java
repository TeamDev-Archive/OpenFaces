/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.test;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.annotations.AfterTest;

import javax.faces.application.ViewExpiredException;

/**
 * @author <a href="mailto:whales@redhat.com">Wesley Hales</a>
 * @version $Revision: 630 $
 */
public class HelpModeNavigationTest extends AbstractSeleniumTestCase {

   @BeforeTest
   @Parameters({"browser"})
   public void setUp(String browser){
      super.startSeleniumClient(browser);
   }


   /**
    * This runs through regular navigation, then enters portlet help mode,
    * then navigates, then exits help mode and ensures the place is held
    * in previous normal navigation, then ensures help mode navigation place
    * is held by re-entering help mode
    */
   @Test
   public void testHelpModeNavigation() throws Exception {
      selenium.open("http://localhost:8080/portal/portal/default/JSFIntegrationTestPortlet");
      selenium.click("link=Ajax Link Test");
      selenium.waitForPageToLoad("30000");
      selenium.click("//div[@id='regionB']/div/table/tbody/tr[1]/td[2]/div[2]/span[1]/a");
      selenium.waitForPageToLoad("30000");
      verifyEquals("Home Page Help Main", selenium.getText("//div[@id='jbpns_2fdefault_2fJSFIntegrationTestPortlet_2fTestWindowsnpbj']/h2"));
      selenium.click("link=Home Help Step 1");
      selenium.waitForPageToLoad("30000");
      verifyTrue(selenium.isTextPresent("Step 1"));
      selenium.click("link=Home Help Step 2");
      selenium.waitForPageToLoad("30000");
      verifyTrue(selenium.isTextPresent("Step 2"));
      selenium.click("//div[@id='regionB']/div/table/tbody/tr[1]/td[2]/div[2]/span[1]/a");
      selenium.waitForPageToLoad("30000");
      verifyTrue(selenium.isTextPresent("Ajax Link Test"));
      selenium.click("//div[@id='regionB']/div/table/tbody/tr[1]/td[2]/div[2]/span[1]/a");
      selenium.waitForPageToLoad("30000");
      verifyTrue(selenium.isTextPresent("Step 2"));
   }

   @AfterTest
   public void tearDown() {
      super.stopSelenium();
   }
}

