/**
 *
 */
package org.jboss.portletbridge.test;

/**
 * @author asmirnov
 *
 */

import com.thoughtworks.selenium.DefaultSelenium;
import static org.testng.Assert.*;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class SeleniumExampleTest extends AbstractSeleniumTestCase

{
   @BeforeTest
   @Parameters({"browser"})
   public void setUp(String browser){
      super.startSeleniumClient(browser);
   }


   @Test
   public void testSomethingSimple() throws Exception {
      selenium.open("http://localhost:8080/portal/portal/default/JSFIntegrationTestPortlet");
      selenium.waitForPageToLoad("5000");
      selenium.click("link=Ajax Link Test");
      selenium.waitForPageToLoad("30000");
      //
      System.out.println("body [" + selenium.getHtmlSource() + "]");
      //
      // selenium.getEval("window.done=false;A4J.AJAX.AddListener(new
      // A4J.AJAX.Listener(function(){window.done=true}))");
      selenium.click("id=ajaxLink");
      selenium.waitForCondition(
              "selenium.browserbot.getCurrentWindow().done==true", "3000");
      System.out.println("ajax body [" + selenium.getHtmlSource() + "]");
      assertEquals("testOk", selenium.getText("id=output"));

      // Test help link
   }

   @AfterTest
   public void tearDown() {
      super.stopSelenium();
   }

   
}