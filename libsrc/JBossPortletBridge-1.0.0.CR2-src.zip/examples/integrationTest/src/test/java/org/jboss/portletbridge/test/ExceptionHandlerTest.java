/******************************************************************************
 * JBoss, a division of Red Hat                                               *
 * Copyright 2006, Red Hat Middleware, LLC, and individual                    *
 * contributors as indicated by the @authors tag. See the                     *
 * copyright.txt in the distribution for a full listing of                    *
 * individual contributors.                                                   *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it            *
 * under the terms of the GNU Lesser General Public License as                *
 * published by the Free Software Foundation; either version 2.1 of           *
 * the License, or (at your option) any later version.                        *
 *                                                                            *
 * This software is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this software; if not, write to the Free                *
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA         *
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.                   *
 ******************************************************************************/
package org.jboss.portletbridge.test;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.annotations.AfterTest;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;
import com.thoughtworks.selenium.SeleniumException;

import javax.faces.application.ViewExpiredException;

/**
 * @author <a href="mailto:whales@redhat.com">Wesley Hales</a>
 * @version $Revision: 630 $
 */
public class ExceptionHandlerTest extends AbstractSeleniumTestCase {

   @BeforeTest
   @Parameters({"browser"})
   public void setUp(String browser){
      super.startSeleniumClient(browser);
   }

   @Test
   public void testSessionTimeout() throws Exception {
      selenium.open("http://localhost:8080/portal/portal/default/JSFIntegrationTestPortlet");
      //Let the session timeout
      Thread.sleep(101000);
      selenium.click("link=Ajax Link Test");
      selenium.waitForPageToLoad("30000");
      verifyTrue(selenium.isTextPresent("Error Page"));
   }

   @Test
   public void testThrowViewExpired() throws Exception {
      selenium.open("http://localhost:8080/portal/portal/default/JSFIntegrationTestPortlet");
      try{
         throw new ViewExpiredException();
      }catch(ViewExpiredException vee){
         //swallow and render error page
      }
      selenium.waitForPageToLoad("30000");
      verifyTrue(selenium.isTextPresent("Error Page"));
   }

   @AfterTest
   public void tearDown() {
      super.stopSelenium();
   }
}
