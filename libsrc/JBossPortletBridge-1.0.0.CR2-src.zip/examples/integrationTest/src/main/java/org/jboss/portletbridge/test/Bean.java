/**
 * 
 */
package org.jboss.portletbridge.test;

import javax.faces.context.FacesContext;

/**
 * @author asmirnov
 *
 */
public class Bean {
    private int counter=0;
    
    private String text ="";

    public Bean() {
		text="start";
		counter=1;
	}
    /**
     * @return the counter
     */
    public int getCounter() {
        return counter;
    }

    /**
     * @param counter the counter to set
     */
    public void setCounter(int counter) {
        this.counter = counter;
    }

    /**
     * @return the text
     */
    public String getText() {
        return text;
    }

    public String ok() {
    	setText("testOk");
		return null;
	}
    /**
     * @param text the text to set
     */
    public void setText(String text) {
        this.text = text;
    }
    
    public String click(){
	counter++;
	return null;
    }

    public String getNamespace(){
	return FacesContext.getCurrentInstance().getExternalContext().encodeNamespace("");
    }
}
