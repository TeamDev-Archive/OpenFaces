

Profile Execution Examples:

JBoss Portal 2.6.5.SP1 + JBoss AS 4.2.2 (Bundled)
mvn install -Ptest-remote -Dportal-2.6.5.SP1

-------------------------------------------------------
Once you have downloaded the packaged JBoss AS + JBoss Portal or you already have your own custom package, you can
copy the zipped archive to a location outside of your target folder and run the following to avoid downloading the
same 100MB file everytime you use 'mvn clean...'

To use a locally configured server bundled with portal:

JBoss Portal 2.6.5.SP1:
mvn clean install -Pintegration-test-local -DJBOSS_ZIP_HOME=/Users/wesleyhales/www/portal-bundles/jboss-portal-2.7.0.GA-bundled.zip -DJBOSS_HOME_DIR=jboss-portal-2.7.0.GA-bundled/jboss-portal-2.7.0.GA

*Note - the variable for JBOSS_HOME_DIR is related to how you zip the server directory. If you zip the files
under JBOSS_HOME/* then it will only be the name of your archive. But if you zip the actual folder JBOSS_HOME then
JBOSS_HOME_DIR must be defined as 'zip file name/JBOSS_HOME folder name'.




