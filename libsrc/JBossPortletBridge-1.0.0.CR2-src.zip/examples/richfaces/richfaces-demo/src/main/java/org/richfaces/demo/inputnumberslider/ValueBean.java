package org.richfaces.demo.inputnumberslider;

public class ValueBean {
	private Integer value;

	public Integer getValue() {
		return value;
	}

	public void setValue(Integer value) {
		this.value = value;
	}

}
