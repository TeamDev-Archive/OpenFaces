/**
 * 
 */
package org.richfaces.demo.togglePanel;



/**
 * @author ishabalov
 *
 */
public class ToggleBean {
	private Object skinChooserState1;
	private Object skinChooserState2;
	private Object skinChooserState3;
	public Object getSkinChooserState1() {
		return skinChooserState1;
	}
	public void setSkinChooserState1(Object skinChooserState1) {
		this.skinChooserState1 = skinChooserState1;
	}
	public Object getSkinChooserState2() {
		return skinChooserState2;
	}
	public void setSkinChooserState2(Object skinChooserState2) {
		this.skinChooserState2 = skinChooserState2;
	}
	public Object getSkinChooserState3() {
		return skinChooserState3;
	}
	public void setSkinChooserState3(Object skinChooserState3) {
		this.skinChooserState3 = skinChooserState3;
	}

}
