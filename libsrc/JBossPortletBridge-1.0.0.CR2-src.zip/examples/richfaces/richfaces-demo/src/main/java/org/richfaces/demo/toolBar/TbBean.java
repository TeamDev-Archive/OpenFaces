package org.richfaces.demo.toolBar;

public class TbBean {
	private String groupSeparator;
	private String groupItemSeparator;
	public String getGroupItemSeparator() {
		return groupItemSeparator;
	}
	public void setGroupItemSeparator(String groupItemSeparator) {
		this.groupItemSeparator = groupItemSeparator;
	}
	public String getGroupSeparator() {
		return groupSeparator;
	}
	public void setGroupSeparator(String groupSeparator) {
		this.groupSeparator = groupSeparator;
	}
	

}
