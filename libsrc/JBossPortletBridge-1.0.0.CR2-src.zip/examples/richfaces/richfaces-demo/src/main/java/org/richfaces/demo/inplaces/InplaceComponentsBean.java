/**
 * 
 */
package org.richfaces.demo.inplaces;

/**
 * @author Ilya Shaikovsky
 *
 */
public class InplaceComponentsBean {
	
	private String inputValue;
	
	public String getInputValue() {
		return inputValue;
	}

	public void setInputValue(String inputValue) {
		this.inputValue = inputValue;
	}

	public InplaceComponentsBean() {
	}
}
