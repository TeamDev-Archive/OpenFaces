/**
 * 
 */
package org.richfaces.demo.comboBox;

/**
 * @author Ilya Shaikovsky
 *
 */
public class ComboBoxBean {

	private String value;
	
	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public ComboBoxBean() {
	}
}
